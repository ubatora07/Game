var Yt=Object.defineProperty;var Xt=(r,e,t)=>e in r?Yt(r,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):r[e]=t;var p=(r,e,t)=>Xt(r,typeof e!="symbol"?e+"":e,t);(function(){const e=document.createElement("link").relList;if(e&&e.supports&&e.supports("modulepreload"))return;for(const a of document.querySelectorAll('link[rel="modulepreload"]'))s(a);new MutationObserver(a=>{for(const i of a)if(i.type==="childList")for(const n of i.addedNodes)n.tagName==="LINK"&&n.rel==="modulepreload"&&s(n)}).observe(document,{childList:!0,subtree:!0});function t(a){const i={};return a.integrity&&(i.integrity=a.integrity),a.referrerPolicy&&(i.referrerPolicy=a.referrerPolicy),a.crossOrigin==="use-credentials"?i.credentials="include":a.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function s(a){if(a.ep)return;a.ep=!0;const i=t(a);fetch(a.href,i)}})();const be=[{id:"E",index:0,nameKey:"rank.e.name",titleKey:"rank.e.title",reqPower:0,multiplier:1,color:"#94a3b8",glowColor:"rgba(148, 163, 184, 0.4)",auraStyle:"aura-none",avatarIcon:"🥋",weaponVisual:"Wooden Blade",trailColor:"#94a3b8",descriptionKey:"rank.e.desc",avatarIndex:0},{id:"D",index:1,nameKey:"rank.d.name",titleKey:"rank.d.title",reqPower:1200,multiplier:1.15,color:"#38bdf8",glowColor:"rgba(56, 189, 248, 0.5)",auraStyle:"aura-subtle",avatarIcon:"🧘",weaponVisual:"Iron Katana",trailColor:"#38bdf8",unlockedFeature:"upgrades_tier2",descriptionKey:"rank.d.desc",avatarIndex:1},{id:"C",index:2,nameKey:"rank.c.name",titleKey:"rank.c.title",reqPower:25e3,multiplier:1.35,color:"#4ade80",glowColor:"rgba(74, 222, 128, 0.5)",auraStyle:"aura-spirit",avatarIcon:"⛩️",weaponVisual:"Spirit Blade",trailColor:"#4ade80",unlockedFeature:"tower",descriptionKey:"rank.c.desc",avatarIndex:2},{id:"B",index:3,nameKey:"rank.b.name",titleKey:"rank.b.title",reqPower:75e4,multiplier:1.65,color:"#c084fc",glowColor:"rgba(192, 132, 252, 0.6)",auraStyle:"aura-spirit",avatarIcon:"⚔️",weaponVisual:"Soul Greatsword",trailColor:"#c084fc",unlockedFeature:"heroes",descriptionKey:"rank.b.desc",avatarIndex:3},{id:"A",index:4,nameKey:"rank.a.name",titleKey:"rank.a.title",reqPower:3e7,multiplier:2,color:"#fbbf24",glowColor:"rgba(251, 191, 36, 0.6)",auraStyle:"aura-flame",avatarIcon:"🏯",weaponVisual:"Domain Glaive",trailColor:"#fbbf24",unlockedFeature:"advanced_upgrades",descriptionKey:"rank.a.desc",avatarIndex:4},{id:"S",index:5,nameKey:"rank.s.name",titleKey:"rank.s.title",reqPower:2e9,multiplier:2.5,color:"#f87171",glowColor:"rgba(248, 113, 113, 0.7)",auraStyle:"aura-flame",avatarIcon:"🔥",weaponVisual:"Dragon Flamberge",trailColor:"#f87171",unlockedFeature:"reincarnation",descriptionKey:"rank.s.desc",avatarIndex:5},{id:"SS",index:6,nameKey:"rank.ss.name",titleKey:"rank.ss.title",reqPower:25e10,multiplier:3.25,color:"#ec4899",glowColor:"rgba(236, 72, 153, 0.8)",auraStyle:"aura-void",avatarIcon:"🌌",weaponVisual:"Void Saber",trailColor:"#ec4899",unlockedFeature:"hero_stars",descriptionKey:"rank.ss.desc",avatarIndex:6},{id:"SSS",index:7,nameKey:"rank.sss.name",titleKey:"rank.sss.title",reqPower:5e13,multiplier:4.25,color:"#e11d48",glowColor:"rgba(225, 29, 72, 0.85)",auraStyle:"aura-void",avatarIcon:"🔮",weaponVisual:"Abyssal Scythe",trailColor:"#e11d48",unlockedFeature:"soul_mastery",descriptionKey:"rank.sss.desc",avatarIndex:7},{id:"AWAKENED",index:8,nameKey:"rank.awakened.name",titleKey:"rank.awakened.title",reqPower:15e15,multiplier:5.75,color:"#818cf8",glowColor:"rgba(129, 140, 248, 0.9)",auraStyle:"aura-celestial",avatarIcon:"⚡",weaponVisual:"Astral Lightning Lance",trailColor:"#818cf8",descriptionKey:"rank.awakened.desc",avatarIndex:8},{id:"TRANSCENDENT",index:9,nameKey:"rank.transcendent.name",titleKey:"rank.transcendent.title",reqPower:5e18,multiplier:8,color:"#38bdf8",glowColor:"rgba(56, 189, 248, 0.95)",auraStyle:"aura-celestial",avatarIcon:"💫",weaponVisual:"Ether Calamity",trailColor:"#38bdf8",descriptionKey:"rank.transcendent.desc",avatarIndex:9},{id:"CELESTIAL",index:10,nameKey:"rank.celestial.name",titleKey:"rank.celestial.title",reqPower:1e21,multiplier:10,color:"#facc15",glowColor:"rgba(250, 204, 21, 1)",auraStyle:"aura-godlike",avatarIcon:"👑",weaponVisual:"Celestial Sol Sovereign",trailColor:"#facc15",descriptionKey:"rank.celestial.desc",avatarIndex:10},{id:"IMMORTAL",index:11,nameKey:"rank.immortal.name",titleKey:"rank.immortal.title",reqPower:5e23,multiplier:12,color:"#f43f5e",glowColor:"rgba(244, 63, 94, 1)",auraStyle:"aura-infinite",avatarIcon:"🌟",weaponVisual:"Infinite Primordial Blade",trailColor:"#f43f5e",descriptionKey:"rank.immortal.desc",avatarIndex:11}];function O(r){return be.find(e=>e.id===r)||be[0]}function le(r){const e=O(r);return e.index<be.length-1?be[e.index+1]:null}function _t(){return{version:6,power:0,gold:0,crystals:150,essence:0,souls:0,rankId:"E",rankIndex:0,buildings:{},upgrades:{},heroes:{},soulSkills:{},relics:{},equippedRelics:[null,null,null],expeditions:[],lastDailyResetAt:0,loginStreak:0,loginRewardClaimed:!1,dailyQuests:[],towerFloor:1,towerMaxFloor:1,reincarnationCount:0,campaign:{currentWorldId:1,currentStageId:"1-1",currentEncounter:1,highestWorldReached:1,highestStageReached:"1-1",firstClears:[],campaignMode:"progress",autoAdvance:!0,farmStageId:"1-1",bossRetryState:null},completedQuests:[],claimedAchievements:[],lastFreeSummonAdAt:0,combo:{count:0,multiplier:1,timer:0},randomEvent:{active:!1,type:"instant_power",expiresAt:0,xPct:50,yPct:50},stats:{totalClicks:0,totalCrits:0,totalBuildingsOwned:0,lifetimePower:0,lifetimeGold:0,campaignGoldEarned:0,campaignPowerEarned:0,campaignCrystalsEarned:0,campaignEnemiesDefeated:0,campaignElitesDefeated:0,campaignStagesCleared:0,campaignBossesDefeated:0,campaignWorldsCleared:0,totalSummons:0,playtimeSeconds:0,firstPlayedAt:Date.now()},buffs:{celestialSurgeEndsAt:0,adPowerSurgeEndsAt:0,frenzyEndsAt:0},settings:{soundEnabled:!0,musicEnabled:!0,soundVolume:.7,musicVolume:.4,reducedMotion:!1,screenShake:!0,notation:"standard",language:"ru"},lastSeenAt:Date.now()}}class Zt{constructor(e){p(this,"state");p(this,"listeners",new Set);this.state=e?{...e}:_t()}get(){return this.state}set(e){e(this.state),this.notify()}replace(e){this.state={...e};const t=O(this.state.rankId);this.state.rankIndex=t.index,this.notify()}subscribe(e){return this.listeners.add(e),e(this.state),()=>{this.listeners.delete(e)}}notify(){this.listeners.forEach(e=>{try{e(this.state)}catch(t){console.error("Error in GameStore listener:",t)}})}}const d=new Zt;class Jt{constructor(){p(this,"isRunning",!1);p(this,"lastTime",0);p(this,"animFrameId",null);p(this,"tickCallbacks",new Set);p(this,"maxDelta",.5)}addCallback(e){return this.tickCallbacks.add(e),()=>{this.tickCallbacks.delete(e)}}start(){if(this.isRunning)return;this.isRunning=!0,this.lastTime=performance.now();const e=t=>{if(!this.isRunning)return;const s=(t-this.lastTime)/1e3;this.lastTime=t;const a=Math.min(s,this.maxDelta);if(a>0){const i=Date.now();this.tickCallbacks.forEach(n=>{try{n(a,i)}catch(o){console.error("Error in GameLoop tick:",o)}})}this.animFrameId=requestAnimationFrame(e)};this.animFrameId=requestAnimationFrame(e)}stop(){this.isRunning=!1,this.animFrameId!==null&&(cancelAnimationFrame(this.animFrameId),this.animFrameId=null)}get running(){return this.isRunning}}const je=new Jt;class es{constructor(){p(this,"listeners",new Map)}on(e,t){return this.listeners.has(e)||this.listeners.set(e,new Set),this.listeners.get(e).add(t),()=>{this.off(e,t)}}off(e,t){const s=this.listeners.get(e);s&&(s.delete(t),s.size===0&&this.listeners.delete(e))}emit(e,t){const s=this.listeners.get(e);s&&s.forEach(a=>{try{a(t)}catch(i){console.error(`Error in event listener for ${String(e)}:`,i)}})}clear(){this.listeners.clear()}}const f=new es;class ts{constructor(){p(this,"ready",!1)}async init(){this.ready=!0,console.log("[MockPlatform] Initialized standalone mock platform.")}isReady(){return this.ready}getLanguage(){return(navigator.language||navigator.userLanguage||"ru").startsWith("ru")?"ru":"en"}async showFullscreenAd(){return console.log("[MockPlatform] Fullscreen Ad requested (Simulated success)."),!0}async showRewardedAd(e){return console.log(`[MockPlatform] Rewarded Ad shown for "${e}" (Simulated reward success).`),!0}async loadCloudSave(){return null}async saveCloudSave(e){return console.log("[MockPlatform] saveCloudSave",e),!0}async setLeaderboardScore(e,t){console.log(`[MockPlatform] setLeaderboardScore: ${e} = ${t}`)}notifyGameReady(){console.log("[MockPlatform] notifyGameReady called.")}notifyGameplayStart(){console.log("[MockPlatform] notifyGameplayStart.")}notifyGameplayStop(){console.log("[MockPlatform] notifyGameplayStop.")}}const kt=6,Oe="ANIME_ASCENSION_SAVE_V6";function ct(r){const e=_t();if(!r||typeof r!="object")return e;const t=(s,a)=>{const i=Number(s);return isNaN(i)||!isFinite(i)||i<0?a:i};return{version:kt,power:t(r.power,0),gold:t(r.gold,0),crystals:t(r.crystals,150),essence:t(r.essence,0),souls:t(r.souls,0),rankId:typeof r.rankId=="string"?r.rankId:"E",rankIndex:t(r.rankIndex,0),buildings:typeof r.buildings=="object"&&r.buildings!==null?r.buildings:{},upgrades:typeof r.upgrades=="object"&&r.upgrades!==null?r.upgrades:{},heroes:typeof r.heroes=="object"&&r.heroes!==null?r.heroes:{},soulSkills:typeof r.soulSkills=="object"&&r.soulSkills!==null?r.soulSkills:{},relics:typeof r.relics=="object"&&r.relics!==null?r.relics:{},equippedRelics:Array.isArray(r.equippedRelics)?r.equippedRelics.slice(0,3):[null,null,null],expeditions:Array.isArray(r.expeditions)?r.expeditions:[],lastDailyResetAt:t(r.lastDailyResetAt,0),lastFreeSummonAdAt:t(r.lastFreeSummonAdAt,0),loginStreak:t(r.loginStreak,0),loginRewardClaimed:!!r.loginRewardClaimed,dailyQuests:Array.isArray(r.dailyQuests)?r.dailyQuests:[],towerFloor:Math.max(1,t(r.towerFloor,1)),towerMaxFloor:Math.max(1,t(r.towerMaxFloor,1)),reincarnationCount:t(r.reincarnationCount,0),campaign:{currentWorldId:Math.max(1,t(r.campaign?.currentWorldId,1)),currentStageId:typeof r.campaign?.currentStageId=="string"?r.campaign.currentStageId:"1-1",currentEncounter:Math.max(1,t(r.campaign?.currentEncounter,1)),highestWorldReached:Math.max(1,t(r.campaign?.highestWorldReached,1)),highestStageReached:typeof r.campaign?.highestStageReached=="string"?r.campaign.highestStageReached:"1-1",firstClears:Array.isArray(r.campaign?.firstClears)?r.campaign.firstClears:[],campaignMode:["progress","farm","boss_blocked","rush"].includes(r.campaign?.campaignMode)?r.campaign.campaignMode:"progress",autoAdvance:typeof r.campaign?.autoAdvance=="boolean"?r.campaign.autoAdvance:!0,farmStageId:typeof r.campaign?.farmStageId=="string"?r.campaign.farmStageId:"1-1",bossRetryState:typeof r.campaign?.bossRetryState=="object"&&r.campaign.bossRetryState!==null?r.campaign.bossRetryState:null},completedQuests:Array.isArray(r.completedQuests)?r.completedQuests:[],claimedAchievements:Array.isArray(r.claimedAchievements)?r.claimedAchievements:[],combo:{count:0,multiplier:1,timer:0},randomEvent:{active:!1,type:"instant_power",expiresAt:0,xPct:50,yPct:50},stats:{totalClicks:t(r.stats?.totalClicks,0),totalCrits:t(r.stats?.totalCrits,0),totalBuildingsOwned:t(r.stats?.totalBuildingsOwned,0),lifetimePower:t(r.stats?.lifetimePower,0),lifetimeGold:t(r.stats?.lifetimeGold,0),campaignGoldEarned:t(r.stats?.campaignGoldEarned,0),campaignPowerEarned:t(r.stats?.campaignPowerEarned,0),campaignCrystalsEarned:t(r.stats?.campaignCrystalsEarned,0),campaignEnemiesDefeated:t(r.stats?.campaignEnemiesDefeated,0),campaignElitesDefeated:t(r.stats?.campaignElitesDefeated,0),campaignStagesCleared:t(r.stats?.campaignStagesCleared,0),campaignBossesDefeated:t(r.stats?.campaignBossesDefeated,0),campaignWorldsCleared:t(r.stats?.campaignWorldsCleared,0),totalSummons:t(r.stats?.totalSummons,0),playtimeSeconds:t(r.stats?.playtimeSeconds,0),firstPlayedAt:t(r.stats?.firstPlayedAt,Date.now())},buffs:{celestialSurgeEndsAt:t(r.buffs?.celestialSurgeEndsAt,0),adPowerSurgeEndsAt:t(r.buffs?.adPowerSurgeEndsAt,0),frenzyEndsAt:t(r.buffs?.frenzyEndsAt,0)},settings:{soundEnabled:typeof r.settings?.soundEnabled=="boolean"?r.settings.soundEnabled:!0,musicEnabled:typeof r.settings?.musicEnabled=="boolean"?r.settings.musicEnabled:!0,soundVolume:t(r.settings?.soundVolume,.7),musicVolume:t(r.settings?.musicVolume,.4),reducedMotion:!!r.settings?.reducedMotion,screenShake:typeof r.settings?.screenShake=="boolean"?r.settings.screenShake:!0,notation:r.settings?.notation==="scientific"?"scientific":"standard",language:r.settings?.language==="en"?"en":"ru"},lastSeenAt:Math.min(Date.now(),t(r.lastSeenAt,Date.now()))}}class We{static migrate(e){if(!e||typeof e!="object")return ct(e);const t=Number(e.version)||0;if(t<1&&(e.version=1),t<2){if(e.rankId){const s=O(e.rankId);e.rankIndex=s.index}e.version=2}if(t<3&&(e.relics||(e.relics={}),Array.isArray(e.equippedRelics)||(e.equippedRelics=[null,null,null]),e.version=3),t<4&&(Array.isArray(e.expeditions)||(e.expeditions=[]),e.version=4),t<5&&(e.lastDailyResetAt=0,e.loginStreak=0,e.loginRewardClaimed=!1,e.dailyQuests=[],e.version=5),t<6){if(!e.campaign||typeof e.campaign!="object"){const s=Number(e.rankIndex)||0;let a=1;s>=5?a=5:s>=4?a=4:s>=3?a=3:s>=2?a=2:a=1;const i=`${a}-1`;e.campaign={currentWorldId:a,currentStageId:i,currentEncounter:1,highestWorldReached:a,highestStageReached:i,firstClears:[],campaignMode:"progress",autoAdvance:!0,farmStageId:i,bossRetryState:null}}e.version=kt}return ct(e)}}class St{constructor(){p(this,"ysdk",null);p(this,"player",null);p(this,"ready",!1)}async init(){try{if(typeof window<"u"&&window.YaGames){this.ysdk=await window.YaGames.init(),window.ysdk=this.ysdk,this.ready=!0;try{this.player=await this.ysdk.getPlayer({scopes:!1})}catch(e){console.warn("[YandexSDK] Player initialization fallback to guest:",e)}console.log("[YandexSDK] Successfully initialized Yandex Games SDK.")}else console.warn("[YandexSDK] YaGames global not detected. Using fallback.")}catch(e){console.error("[YandexSDK] Init error:",e)}}isReady(){return this.ready&&this.ysdk!==null}getLanguage(){return this.ysdk?.environment?.i18n?.lang?this.ysdk.environment.i18n.lang.startsWith("ru")?"ru":"en":"ru"}async showFullscreenAd(){return this.isReady()?new Promise(e=>{this.ysdk.adv.showFullscreenAdv({callbacks:{onOpen:()=>{this.notifyGameplayStop()},onClose:t=>{this.notifyGameplayStart(),e(!0)},onError:t=>{console.warn("[YandexSDK] Fullscreen ad error:",t),this.notifyGameplayStart(),e(!1)}}})}):!0}async showRewardedAd(e){return this.isReady()?new Promise(t=>{let s=!1;this.ysdk.adv.showRewardedVideo({callbacks:{onOpen:()=>{this.notifyGameplayStop()},onRewarded:()=>{s=!0},onClose:()=>{this.notifyGameplayStart(),t(s)},onError:a=>{console.warn(`[YandexSDK] Rewarded ad error for "${e}":`,a),this.notifyGameplayStart(),t(!1)}}})}):!0}async loadCloudSave(){if(!this.player)return null;try{const e=await this.player.getData(["ANIME_ASCENSION_DATA"]);if(e&&e.ANIME_ASCENSION_DATA)return We.migrate(e.ANIME_ASCENSION_DATA)}catch(e){console.warn("[YandexSDK] Failed to load cloud data:",e)}return null}async saveCloudSave(e){if(!this.player)return!1;try{return await this.player.setData({ANIME_ASCENSION_DATA:e}),!0}catch(t){return console.warn("[YandexSDK] Failed to save cloud data:",t),!1}}async setLeaderboardScore(e,t){if(!(!this.isReady()||!this.ysdk.isAvailableMethod("leaderboards.setLeaderboardScore")))try{await(await this.ysdk.getLeaderboards()).setLeaderboardScore(e,t),console.log(`[YandexSDK] Set score ${t} to leaderboard ${e}`)}catch(s){console.warn("[YandexSDK] Failed to set leaderboard score:",s)}}notifyGameReady(){if(this.ysdk?.features?.LoadingAPI)try{this.ysdk.features.LoadingAPI.ready(),console.log("[YandexSDK] LoadingAPI.ready() fired.")}catch(e){console.warn("[YandexSDK] Error notifying ready:",e)}}notifyGameplayStart(){if(this.ysdk?.features?.GameplayAPI)try{this.ysdk.features.GameplayAPI.start()}catch{}}notifyGameplayStop(){if(this.ysdk?.features?.GameplayAPI)try{this.ysdk.features.GameplayAPI.stop()}catch{}}}function Ct(){return typeof window<"u"&&window.YaGames?new St:new ts}const V=Ct(),ss=Object.freeze(Object.defineProperty({__proto__:null,YandexGamesService:St,createPlatformService:Ct,platform:V},Symbol.toStringTag,{value:"Module"})),ee=class ee{constructor(){p(this,"autoSaveTimer",null);p(this,"isSaving",!1);this.setupListeners()}static getInstance(){return ee.instance||(ee.instance=new ee),ee.instance}stopAutoSave(){this.autoSaveTimer!==null&&(clearInterval(this.autoSaveTimer),this.autoSaveTimer=null)}setupListeners(){this.autoSaveTimer=window.setInterval(()=>{this.saveLocal()},15e3),document.addEventListener("visibilitychange",()=>{document.visibilityState==="hidden"&&this.saveLocal()}),window.addEventListener("beforeunload",()=>{window.__DISABLE_SAVE__||this.saveLocal()})}saveLocal(){if(!(this.isSaving||window.__DISABLE_SAVE__)){this.isSaving=!0;try{d.set(t=>{t.lastSeenAt=Date.now()});const e=JSON.stringify(d.get());localStorage.setItem(Oe,e),f.emit("save:saved",{timestamp:Date.now()}),V.saveCloudSave(d.get()).catch(()=>{})}catch(e){console.warn("Failed to save to localStorage:",e)}finally{this.isSaving=!1}}}loadLocal(){try{const e=[Oe,"ANIME_ASCENSION_SAVE_V5","ANIME_ASCENSION_SAVE_V4","ANIME_ASCENSION_SAVE_V3","ANIME_ASCENSION_SAVE_V2","ANIME_ASCENSION_SAVE_V1","ANIME_ASCENSION_SAVE"];let t=null;for(const a of e)if(t=localStorage.getItem(a),t)break;if(!t)return null;const s=JSON.parse(t);return We.migrate(s)}catch(e){return console.error("Failed to parse save from localStorage:",e),null}}clearSave(){try{const e=[Oe,"ANIME_ASCENSION_SAVE_V5","ANIME_ASCENSION_SAVE_V4","ANIME_ASCENSION_SAVE_V3","ANIME_ASCENSION_SAVE_V2","ANIME_ASCENSION_SAVE_V1","ANIME_ASCENSION_SAVE"];for(const s of e)localStorage.removeItem(s);const t=We.migrate(null);d.replace(t),this.saveLocal()}catch(e){console.error("Failed to clear save:",e)}}};p(ee,"instance");let Qe=ee;const Et=Qe.getInstance(),as={"app.title":"ANIME INFINITE ASCENSION","app.subtitle":"From Nobody to Cosmic Sovereign","currency.power":"Power","currency.gold":"Gold","currency.crystals":"Crystals","currency.essence":"Essence","currency.souls":"Souls","btn.claim":"Claim","btn.claim_ad":"Claim x3 (AD)","btn.confirm":"Confirm","btn.cancel":"Cancel","btn.close":"Close","btn.train":"TRAIN","btn.ascend":"ASCEND NOW","btn.summon_1":"Summon x1","btn.summon_10":"Summon x10","btn.skip":"Skip","btn.reincarnate":"Reincarnate","btn.upgrade":"Upgrade","btn.max":"MAX","btn.buy":"Buy","btn.locked":"Locked","btn.stats":"Statistics","btn.breakdown":"Breakdown","nav.home":"Battle","nav.battle":"Battle","nav.hero":"Hero","nav.sect":"Sect","nav.ascension":"Ascension","nav.tower":"Tower","nav.heroes":"Heroes","nav.summon":"Summon","nav.souls":"Soul Tree","nav.quests":"Quests","nav.dailies":"Dailies","nav.expeditions":"Expeditions","nav.relics":"Relics","nav.more":"More","nav.settings":"Settings","modal.more.title":"MORE & MODES","building.title":"Sect","sect.title":"Sect","sect.subtitle":"Sanctuary and domains of your cultivation school","sect.best_value":"⭐ BEST VALUE","sect.milestone_next":"Milestone","sect.unlocked_rank":"Unlocks at Rank","sect.synergy":"Synergy","building.dojo.name":"Novice Dojo","building.dojo.desc":"Initial physical tempering ground (+1/sec)","building.chamber.name":"Meditation Chamber","building.chamber.desc":"Quiet sanctum for deep Qi accumulation (+8/sec)","building.shrine.name":"Spirit Shrine","building.shrine.desc":"Altar of ancestral spirits and primal energy (+47/sec)","building.academy.name":"Warrior Academy","building.academy.desc":"Advanced training citadel of martial masters (+260/sec)","building.forge.name":"Arcane Forge","building.forge.desc":"Forges soul relics and temper spirit blades (+1.4K/sec)","building.reactor.name":"Mana Reactor","building.reactor.desc":"Condenses celestial ether into pure power (+8K/sec)","building.temple.name":"Celestial Temple","building.temple.desc":"Sanctuary of stellar radiance and divine harmony (+47K/sec)","building.gate.name":"Dimensional Gate","building.gate.desc":"Portal channeling boundless alternate dimensions (+260K/sec)","building.fortress.name":"Star Fortress","building.fortress.desc":"Cosmic citadel orbiting the prime origin (+1.5M/sec)","building.core.name":"Infinite Core","building.core.desc":"Supermassive generator of godlike energy (+10M/sec)","upgrade.title":"Upgrades & Perks","upgrade.iron_fist.name":"Iron Fist","upgrade.iron_fist.desc":"Manual click power is doubled (×2)","upgrade.chi_flow.name":"Chi Flow","upgrade.chi_flow.desc":"+3 Flat Training Base Power per level","upgrade.eagle_eye.name":"Eagle Eye","upgrade.eagle_eye.desc":"+4% Critical training strike chance","upgrade.lethal_strike.name":"Lethal Strike","upgrade.lethal_strike.desc":"+1.0x Critical strike damage multiplier","upgrade.dojo_mastery.name":"Dojo Discipline","upgrade.dojo_mastery.desc":"Dojo production is doubled (×2)","upgrade.chamber_zen.name":"Chamber Zen","upgrade.chamber_zen.desc":"Meditation Chamber production is doubled (×2)","upgrade.shrine_blessing.name":"Shrine Blessing","upgrade.shrine_blessing.desc":"Spirit Shrine production is doubled (×2)","upgrade.academy_drills.name":"Academy Drills","upgrade.academy_drills.desc":"Warrior Academy production is doubled (×2)","upgrade.forge_pyro.name":"Arcane Pyre","upgrade.forge_pyro.desc":"Arcane Forge production is doubled (×2)","upgrade.reactor_overcharge.name":"Reactor Overcharge","upgrade.reactor_overcharge.desc":"Mana Reactor production is doubled (×2)","upgrade.temple_sanctity.name":"Temple Sanctity","upgrade.temple_sanctity.desc":"Celestial Temple production is doubled (×2)","upgrade.gate_expansion.name":"Gate Expansion","upgrade.gate_expansion.desc":"Dimensional Gate production is doubled (×2)","upgrade.spirit_education.name":"Spirit Education","upgrade.spirit_education.desc":"Each Warrior Academy boosts Meditation Chambers by +3%","upgrade.celestial_discipline.name":"Celestial Discipline","upgrade.celestial_discipline.desc":"Each Celestial Temple boosts Dojos by +5%","upgrade.dimensional_training.name":"Dimensional Training","upgrade.dimensional_training.desc":"Each Dimensional Gate boosts Warrior Academies by +4%","upgrade.golden_fortune.name":"Golden Fortune","upgrade.golden_fortune.desc":"+20% Gold production per level","upgrade.architect_wisdom.name":"Architect Wisdom","upgrade.architect_wisdom.desc":"-3% Building purchase costs per level","upgrade.spirit_resonance.name":"Spirit Resonance","upgrade.spirit_resonance.desc":"+25% Global Power production","upgrade.cosmic_flow.name":"Cosmic Flow","upgrade.cosmic_flow.desc":"+50% Global Power production","upgrade.god_domain.name":"God Domain","upgrade.god_domain.desc":"+100% Global Power production","upgrade.astral_slumber.name":"Astral Slumber","upgrade.astral_slumber.desc":"+2 Hours maximum offline progression cap","upgrade.tower_conqueror.name":"Tower Conqueror","upgrade.tower_conqueror.desc":"+35% Tower Combat Power","rank.current":"Current Realm","rank.next":"Next Ascension","rank.req":"Required Power","rank.multiplier":"Power Multiplier","rank.e.name":"Mortal Novice","rank.e.title":"Rank E: Novice Disciple","rank.e.desc":"A mortal who has just touched the boundaries of spiritual energy.","rank.d.name":"Qi Initiate","rank.d.title":"Rank D: Qi Initiate","rank.d.desc":"Spiritual energy flows steadily through your meridians.","rank.c.name":"Spirit Adept","rank.c.title":"Rank C: Spirit Adept","rank.c.desc":"Aura materializes into pure force. Infinite Tower unlocked!","rank.b.name":"Soul Master","rank.b.title":"Rank B: Soul Master","rank.b.desc":"Can manifest spirit blades and summon allied heroes.","rank.a.name":"Domain Lord","rank.a.title":"Rank A: Domain Lord","rank.a.desc":"Command over elemental realms and ancient summoning portals.","rank.s.name":"Celestial Champion","rank.s.title":"Rank S: Celestial Champion","rank.s.desc":"Achieved near-immortality. Unlocks Reincarnation!","rank.ss.name":"Void Sovereign","rank.ss.title":"Rank SS: Void Sovereign","rank.ss.desc":"Dominates spacetime and commands the Soul Tree.","rank.sss.name":"Cosmic Monarch","rank.sss.title":"Rank SSS: Cosmic Monarch","rank.sss.desc":"A presence capable of reshaping entire stellar clusters.","rank.awakened.name":"Awakened Deity","rank.awakened.title":"Rank Awakened: Deity","rank.awakened.desc":"Transcended the physical laws of existence.","rank.transcendent.name":"Transcendent God","rank.transcendent.title":"Rank Transcendent: God","rank.transcendent.desc":"The universe bows before your boundless aura.","rank.celestial.name":"Celestial Origin","rank.celestial.title":"Rank Celestial Origin","rank.celestial.desc":"The primordial spark of creation resides within you.","rank.immortal.name":"Infinite Sovereign","rank.immortal.title":"Rank Immortal: Infinite","rank.immortal.desc":"Eternal, infinite, and omnipotent.","rarity.common":"Common","rarity.rare":"Rare","rarity.epic":"Epic","rarity.legendary":"Legendary","rarity.mythic":"Mythic","hero.hiro.name":"Hiro","hero.hiro.title":"Swift Wind Disciple","hero.hiro.desc":"A fast young swordsman dedicated to honing his blade.","hero.lin.name":"Lin","hero.lin.title":"Herbalist of Water","hero.lin.desc":"Harvests mystical herbs that bring abundant wealth.","hero.tatsu.name":"Tatsu","hero.tatsu.title":"Iron Fist Monk","hero.tatsu.desc":"Maintains ceaseless training even while sleeping.","hero.mei.name":"Mei","hero.mei.title":"Spirit Archer","hero.mei.desc":"Never misses a vital point with her spirit arrows.","hero.kael.name":"Kael","hero.kael.title":"Shadow Assassin","hero.kael.desc":"Strikes from the void with devastating critical blows.","hero.yuna.name":"Yuna","hero.yuna.title":"Astral Priestess","hero.yuna.desc":"Channels the stars to gather immense energy during rest.","hero.shin.name":"Shin","hero.shin.title":"Lightning Blade","hero.shin.desc":"Cleaves through tower beasts with thunder speed.","hero.hana.name":"Hana","hero.hana.title":"Sakura Witch","hero.hana.desc":"Enchants the surroundings with overflowing mana blossoms.","hero.ren.name":"Ren","hero.ren.title":"Void Reaper","hero.ren.desc":"Commands the spectral scythe of nether dimensions.","hero.ayaka.name":"Ayaka","hero.ayaka.title":"Crimson Valkyrie","hero.ayaka.desc":"Fierce dragon slayer with unyielding martial spirit.","hero.daiki.name":"Daiki","hero.daiki.title":"Thunder Guardian","hero.daiki.desc":"Forges astral relics that multiply all golden treasures.","hero.sora.name":"Sora","hero.sora.title":"Wind Sovereign","hero.sora.desc":"Flies among cosmic storms, enhancing critical precision.","hero.akari.name":"Akari","hero.akari.title":"Solar Empress","hero.akari.desc":"Radiates the incandescent power of a thousand suns.","hero.ryu.name":"Ryu","hero.ryu.title":"Dragon God Scion","hero.ryu.desc":"Possesses the primordial breath and ferocity of true dragons.","hero.tsukiko.name":"Tsukiko","hero.tsukiko.title":"Moon Goddess","hero.tsukiko.desc":"Goddess of lunar mysteries and celestial essence.","hero.kuro.name":"Kuro","hero.kuro.title":"Sovereign of the Void","hero.kuro.desc":"The supreme existence of the infinite dimensional expanse.","hero.amaterasu.name":"Amaterasu","hero.amaterasu.title":"Sun Goddess","hero.amaterasu.desc":"The primordial deity illuminating all existence with holy fire.","hero.hiro.skill_name":"Gale Slash","hero.hiro.skill_desc":"Strikes with 2.5x wind blade damage.","hero.lin.skill_name":"Lotus Blessing","hero.lin.skill_desc":"Summons a 3.0x surge of gold.","hero.tatsu.skill_name":"Flame Fist","hero.tatsu.skill_desc":"Deals 2.8x explosive fire damage.","hero.mei.skill_name":"Eagle Mark","hero.mei.skill_desc":"Focuses a 2.5x critical strike.","hero.kael.skill_name":"Shadow Step","hero.kael.skill_desc":"Strikes from stealth for 3.2x damage.","hero.yuna.skill_name":"Astral Ward","hero.yuna.skill_desc":"Grants a 3.5x burst of cultivation power.","hero.shin.skill_name":"Thunderstrike","hero.shin.skill_desc":"Strikes with lightning for 3.5x damage.","hero.hana.skill_name":"Blossom Dance","hero.hana.skill_desc":"Grants a 3.2x burst of cultivation power.","hero.ren.skill_name":"Soul Harvest","hero.ren.skill_desc":"Reaps target soul for 4.0x damage.","hero.ayaka.skill_name":"Crimson Lance","hero.ayaka.skill_desc":"Deals 4.2x fierce dragon flame damage.","hero.daiki.skill_name":"Earth Tremor","hero.daiki.skill_desc":"Smashes target with hammer for 4.5x damage.","hero.sora.skill_name":"Sky Tempest","hero.sora.skill_desc":"Applies storm mark for 4.0x crit damage.","hero.akari.skill_name":"Solar Flare","hero.akari.skill_desc":"Channels 5.5x monumental power.","hero.ryu.skill_name":"Dragon Roar","hero.ryu.skill_desc":"Incinerates target with 6.0x dragon breath.","hero.tsukiko.skill_name":"Lunar Eclipse","hero.tsukiko.skill_desc":"Summons 6.0x wealth and cosmic essence.","hero.kuro.skill_name":"Void Annihilation","hero.kuro.skill_desc":"Annihilates target for 8.0x void damage.","hero.amaterasu.skill_name":"Heavenly Radiance","hero.amaterasu.skill_desc":"Channels 8.5x supreme solar burst.","tower.title":"Infinite Tower","tower.floor":"Floor","tower.boss":"BOSS ENCOUNTER","tower.auto_climb":"Auto-Climbing","tower.defeat":"DEFEATED - Retrying floor...","tower.victory":"FLOOR CLEARED!","world.forest.name":"World 1: Forest of Whispers","world.sakura.name":"World 2: Sakura Empire","world.abyss.name":"World 3: Crimson Demon Abyss","world.frozen.name":"World 4: Frozen Peak of Despair","world.void.name":"World 5: Sanctuary of the Void","monster.goblin":"Forest Goblin","monster.goblin.desc":"A mischievous forest imp.","monster.shadow_wolf":"Shadow Wolf","monster.shadow_wolf.desc":"A beast infused with twilight energy.","monster.treant":"Ancient Treant","monster.treant.desc":"A giant animated bark guardian.","boss.forest_king":"Forest Demon King","boss.forest_king.desc":"Ruler of the dark woodland.","monster.ronin":"Corrupted Ronin","monster.ronin.desc":"A wanderer seduced by forbidden blades.","monster.kitsune":"Trickster Kitsune","monster.kitsune.desc":"Nine-tailed fox with spirit fire.","monster.monk":"Shadow Monk","monster.monk.desc":"Chants sinister invocations.","boss.shogun":"Shadow Shogun","boss.shogun.desc":"Warlord clad in cursed armor.","monster.hellhound":"Infernal Hellhound","monster.hellhound.desc":"Born from molten rock and malice.","monster.fire_demon":"Abyssal Fiend","monster.fire_demon.desc":"Throws devastating magma bolts.","monster.lava_golem":"Molten Colossus","monster.lava_golem.desc":"Impervious rock animated by fire core.","boss.dragon":"Infernal Sovereign Dragon","boss.dragon.desc":"Emperor of volcanic wrath.","monster.frost_golem":"Glacial Golem","monster.frost_golem.desc":"Carved from unbreakable ancient ice.","monster.ice_specter":"Frost Specter","monster.ice_specter.desc":"Freezes the soul upon touch.","monster.blizzard_hawk":"Blizzard Hawk","monster.blizzard_hawk.desc":"Darts through sub-zero hurricanes.","boss.frost_monarch":"Monarch of Perpetual Winter","boss.frost_monarch.desc":"Turns whole galaxies to absolute zero.","monster.void_phantom":"Void Phantom","monster.void_phantom.desc":"A shadowy manifestation of nothingness.","monster.astral_knight":"Astral Knight","monster.astral_knight.desc":"Guardian of the cosmic perimeter.","monster.chaos_orb":"Chaos Energy Orb","monster.chaos_orb.desc":"Distorts reality and dimension.","boss.cosmic_sovereign":"Cosmic Overlord of the Void","boss.cosmic_sovereign.desc":"The supreme entity beyond the stars.","soul.title":"Altar of Reincarnation","soul.desc":"Transcend mortality. Reset Power and Buildings to gain Souls and permanent cosmic powers.","soul.power.name":"Soul Surge","soul.power.desc":"+15% Total Power multiplier per level","soul.train.name":"Soul Tempering","soul.train.desc":"+25% Manual training power per level","soul.building.name":"Spirit Sanctuary","soul.building.desc":"+15% Building production per level","soul.gold.name":"Midas Spirit","soul.gold.desc":"+20% Gold production per level","soul.cost.name":"Ethereal Architecture","soul.cost.desc":"-2% Building costs per level (up to -30%)","soul.quest.name":"Karmic Fortune","soul.quest.desc":"+15% Quest rewards per level","soul.offline.name":"Astral Trance","soul.offline.desc":"+15% Offline earnings & +1 hour max offline per level","soul.crit.name":"Divine Smite","soul.crit.desc":"+2% Crit Chance & +25% Crit Damage per level","soul.essence.name":"Astral Resonance","soul.essence.desc":"+30% Hero Essence gain per level","soul.tower.name":"Tower Vanguard","soul.tower.desc":"+25% Tower Combat Power & +20% Tower Drops per level","soul.rank.name":"Ascension Blessing","soul.rank.desc":"+10% Rank multiplier effectiveness per level","soul.rebirth.name":"Eternal Rebirth","soul.rebirth.desc":"+15% Souls gained on Reincarnation per level","quest.title":"Trial Quests","quest.train_10.name":"First Warm-up","quest.train_10.desc":"Perform 10 active training taps","quest.campaign_kill_5.name":"First Hunt","quest.campaign_kill_5.desc":"Defeat 5 enemies in Campaign","quest.reach_stage_1_3.name":"Into the Thicket","quest.reach_stage_1_3.desc":"Reach Stage 1-3 in Campaign","quest.defeat_elite_1.name":"Elite Hunter","quest.defeat_elite_1.desc":"Defeat 1 Elite monster in Campaign","quest.reach_stage_1_5.name":"Beast Path","quest.reach_stage_1_5.desc":"Reach Stage 1-5 (Forest Boss)","quest.defeat_boss_1.name":"Boss Slayer","quest.defeat_boss_1.desc":"Defeat 1 Boss in Campaign","quest.reach_stage_1_10.name":"Heart of the Forest","quest.reach_stage_1_10.desc":"Reach Stage 1-10 (Forest Overlord)","quest.clear_world_1.name":"Conqueror of the Forest","quest.clear_world_1.desc":"Fully clear World 1: Whispering Forest","quest.reach_stage_2_5.name":"Sakura Bloom","quest.reach_stage_2_5.desc":"Reach Stage 2-5 in Sakura Empire","quest.defeat_boss_5.name":"Slayer of Sovereigns","quest.defeat_boss_5.desc":"Defeat 5 Bosses in Campaign","quest.train_50.name":"Diligent Trainee","quest.train_50.desc":"Perform 50 active training taps","quest.train_250.name":"Meridian Tempering","quest.train_250.desc":"Perform 250 active training taps","quest.train_1000.name":"Unshakable Will","quest.train_1000.desc":"Perform 1,000 active training taps","quest.build_1.name":"First Sanctum","quest.build_1.desc":"Construct your first cultivation building","quest.dojo_10.name":"Dojo Order","quest.dojo_10.desc":"Recruit 10 Dojo disciples","quest.chamber_10.name":"Deep Trance","quest.chamber_10.desc":"Construct 10 Meditation Chambers","quest.shrine_10.name":"Spirit Worship","quest.shrine_10.desc":"Construct 10 Spirit Shrines","quest.build_25.name":"Sect Expansion","quest.build_25.desc":"Own 25 total cultivation buildings","quest.build_50.name":"Grand Abode","quest.build_50.desc":"Own 50 total cultivation buildings","quest.build_100.name":"Cultivator Empire","quest.build_100.desc":"Own 100 total cultivation buildings","quest.power_1k.name":"One Thousand Ki","quest.power_1k.desc":"Accumulate 1,000 lifetime Power","quest.power_50k.name":"Power Surge","quest.power_50k.desc":"Accumulate 50,000 lifetime Power","quest.power_1m.name":"Millionaire Breakthrough","quest.power_1m.desc":"Accumulate 1,000,000 lifetime Power","quest.power_100m.name":"Hundred Million Force","quest.power_100m.desc":"Accumulate 100,000,000 lifetime Power","quest.tower_5.name":"Tower Pioneer","quest.tower_5.desc":"Conquer Floor 5 in the Infinite Tower","quest.tower_10.name":"Forest Vanquisher","quest.tower_10.desc":"Conquer Floor 10 and defeat the first Boss","quest.tower_25.name":"Dungeon Crusher","quest.tower_25.desc":"Conquer Floor 25 in the Infinite Tower","quest.tower_50.name":"Fifty Floors Champion","quest.tower_50.desc":"Clear Floor 50","quest.tower_100.name":"Tower Legend","quest.tower_100.desc":"Clear Floor 100","quest.summon_1.name":"Calling of Allies","quest.summon_1.desc":"Perform 1 Hero Summon","quest.summon_5.name":"Pact of Legends","quest.summon_5.desc":"Perform 5 Hero Summons","quest.heroes_3.name":"Three Warriors","quest.heroes_3.desc":"Collect 3 different heroes","quest.heroes_8.name":"Elite Vanguard","quest.heroes_8.desc":"Collect 8 different heroes","quest.rank_d.name":"Breakthrough","quest.rank_d.desc":"Ascend to Rank D","quest.rank_b.name":"Renowned Cultivator","quest.rank_b.desc":"Ascend to Rank B","quest.rank_s.name":"Apex Mortal","quest.rank_s.desc":"Ascend to Rank S","quest.reincarnate_1.name":"Reborn from Ashes","quest.reincarnate_1.desc":"Perform your first Reincarnation","quest.daily.train.500":"Perform 500 training clicks","quest.daily.summon.1":"Summon 1 hero","quest.daily.tower.3":"Clear 3 tower floors","quest.daily.upgrade.10":"Buy 10 upgrades",expedition_scout_forest:"Whispering Forest Recon",expedition_explore_ruins:"Ancient Ruins Exploration",expedition_abyssal_dive:"Abyssal Descent","achieve.title":"Achievements","achieve.first_train.name":"First Step on the Path","achieve.first_train.desc":"Perform your first training tap","achieve.train_100.name":"Martial Dedication","achieve.train_100.desc":"Perform 100 training taps","achieve.train_1000.name":"Unshakable Will","achieve.train_1000.desc":"Perform 1,000 training taps","achieve.crit_50.name":"Critical Focus","achieve.crit_50.desc":"Land 50 critical strikes","achieve.first_building.name":"First Foundation","achieve.first_building.desc":"Acquire your first cultivation building","achieve.buildings_50.name":"Grand Construction","achieve.buildings_50.desc":"Own 50 total buildings","achieve.buildings_150.name":"Colossal Complex","achieve.buildings_150.desc":"Own 150 total buildings","achieve.rank_d.name":"Qi Initiate","achieve.rank_d.desc":"Achieve Rank D","achieve.rank_c.name":"Spirit Adept Awakening","achieve.rank_c.desc":"Achieve Rank C","achieve.rank_b.name":"Soul Master","achieve.rank_b.desc":"Achieve Rank B","achieve.rank_a.name":"Domain of Might","achieve.rank_a.desc":"Achieve Rank A","achieve.rank_s.name":"Apex Mortal","achieve.rank_s.desc":"Achieve Rank S","achieve.rank_trans.name":"Godhood Achieved","achieve.rank_trans.desc":"Achieve Transcendent Rank","achieve.power_1m.name":"One Million Ki","achieve.power_1m.desc":"Reach 1,000,000 Power","achieve.power_1b.name":"Billion Strong","achieve.power_1b.desc":"Reach 1,000,000,000 Power","achieve.tower_10.name":"Forest Vanquisher","achieve.tower_10.desc":"Defeat the Boss on Floor 10","achieve.tower_50.name":"Master of the Woods","achieve.tower_50.desc":"Clear Floor 50","achieve.tower_100.name":"Sakura Champion","achieve.tower_100.desc":"Clear Floor 100","achieve.heroes_3.name":"Fellowship","achieve.heroes_3.desc":"Collect 3 different heroes","achieve.heroes_10.name":"Grand Army","achieve.heroes_10.desc":"Collect 10 different heroes","achieve.reincarnate_1.name":"Reborn from Ashes","achieve.reincarnate_1.desc":"Perform your first Reincarnation","achieve.world_1.name":"Forest Liberator","achieve.world_1.desc":"Fully clear World 1: Whispering Forest","achieve.world_3.name":"Abyss Tamer","achieve.world_3.desc":"Fully clear World 3: Crimson Abyss","achieve.world_5.name":"Void Sovereign","achieve.world_5.desc":"Fully clear World 5: Void Sanctuary","achieve.bosses_10.name":"Sovereign Slayer","achieve.bosses_10.desc":"Defeat 10 Campaign Bosses","achieve.bosses_25.name":"World Scourge","achieve.bosses_25.desc":"Defeat 25 Campaign Bosses","achieve.bosses_50.name":"Invincible Conqueror","achieve.bosses_50.desc":"Defeat 50 Campaign Bosses","achieve.kills_100.name":"First Hundred","achieve.kills_100.desc":"Defeat 100 Campaign enemies","achieve.kills_500.name":"Blade Tempest","achieve.kills_500.desc":"Defeat 500 Campaign enemies","achieve.kills_2500.name":"Ultimate Harvest","achieve.kills_2500.desc":"Defeat 2,500 Campaign enemies","achieve.crits_100.name":"Precise Slasher","achieve.crits_100.desc":"Land 100 critical strikes","achieve.crits_1000.name":"Deadly Storm","achieve.crits_1000.desc":"Land 1,000 critical strikes","achieve.combo_50.name":"Combo Vortex","achieve.combo_50.desc":"Reach a 50x combo streak","achieve.hero_star_5.name":"Five-Star Legend","achieve.hero_star_5.desc":"Promote any Hero to 5 Stars","achieve.synergy_active.name":"Faction Harmony","achieve.synergy_active.desc":"Activate an elemental synergy in your party","achieve.reincarnate_5.name":"Immortal Samsara","achieve.reincarnate_5.desc":"Perform 5 Reincarnations","achieve.souls_100.name":"Soul Vault","achieve.souls_100.desc":"Accumulate 100 Reincarnation Souls","modal.offline.title":"WELCOME BACK, WARRIOR!","modal.offline.time":"Time spent in deep meditation:","modal.offline.earned":"Accumulated Gains:","modal.ascension.title":"ASCENSION ACHIEVED!","modal.ascension.congrats":"You have broken through your mortal limits!","modal.summon.title":"HERO SUMMON","modal.summon.duplicate":"Duplicate Hero converted into Hero Essence!","modal.reincarnate.title":"CONFIRM REINCARNATION","modal.reincarnate.warning":"Your current Power and Buildings will be reset. You will retain all Heroes, Essence, Achievements, and receive Souls.","modal.reincarnate.souls_awarded":"Souls Awarded:","modal.stats.title":"PROFILE & COMBAT POWER","rpg.protagonist":"Cultivator","rpg.combat_power":"Combat Power","rpg.tap_power":"Strike Power","rpg.crit_rate":"Crit Chance","rpg.crit_dmg":"Crit Damage","rpg.atk_speed":"Attack Speed","rpg.sources_title":"Power Sources","rpg.sect_output":"Sect Buildings","rpg.rank_mult":"Ascension Realm","rpg.heroes_party":"Allied Heroes","rpg.soul_mastery":"Soul Tree","rpg.relics_boost":"Relics","rpg.surge_buffs":"Qi Surge","rpg.next_ascension":"Ascension","rpg.ready_to_ascend":"Ready to Ascend!","rpg.reach_power":"Required","settings.sound":"Sound Effects","settings.music":"Background Music","settings.volume":"Volume","settings.reduced_motion":"Reduced Motion","settings.screen_shake":"Screen Shake","settings.notation":"Number Format","settings.notation_standard":"Standard (1.25M)","settings.notation_scientific":"Scientific (1.25e6)","settings.language":"Language","settings.reset":"Reset Progress","settings.reset_confirm":"Are you sure you want to completely erase all save data? This cannot be undone!","campaign.title":"Campaign","campaign.world":"World","campaign.stage":"Stage","campaign.boss":"Boss","campaign.mini_boss":"Mini-Boss","campaign.auto_advance_on":"AUTO ON","campaign.auto_advance_off":"AUTO OFF","campaign.mode_progress":"PROGRESS","campaign.mode_farm":"FARM","campaign.mode_rush":"RUSH","campaign.mode_boss_blocked":"BLOCKED","campaign.retry_boss":"RETRY BOSS","campaign.boosted_retry":"BOOSTED RETRY","campaign.attack":"ATTACK","campaign.ascend":"ASCEND","campaign.victory":"VICTORY","campaign.defeat":"DEFEAT","campaign.world_cleared":"WORLD CLEARED!","campaign.party_synergy":"Party Synergy","campaign.solo_cultivator":"Solo Cultivator","ad.offline.title":"Double Offline Gains","ad.boss_boost.title":"Boss Combat Surge","ad.boss_chest.title":"Bonus Boss Treasure","ad.battle_surge.title":"Battle Power Surge","ad.free_summon.title":"Free Hero Summon"},is={"app.title":"ANIME INFINITE ASCENSION","app.subtitle":"От безвестного смертного к Космическому Владыке","currency.power":"Сила","currency.gold":"Золото","currency.crystals":"Кристаллы","currency.essence":"Эссенция","currency.souls":"Души","btn.claim":"Забрать","btn.claim_ad":"Забрать x3 (РЕКЛАМА)","btn.confirm":"Подтвердить","btn.cancel":"Отмена","btn.close":"Закрыть","btn.train":"ТРЕНИРОВКА","btn.ascend":"ВОЗВЫСИТЬСЯ","btn.summon_1":"Призыв x1","btn.summon_10":"Призыв x10","btn.skip":"Пропустить","btn.reincarnate":"Перерождение","btn.upgrade":"Улучшить","btn.max":"МАКС","btn.buy":"Купить","btn.locked":"Заблокировано","btn.stats":"Статистика","btn.breakdown":"Доход","nav.home":"Битва","nav.battle":"Битва","nav.hero":"Герой","nav.sect":"Секта","nav.ascension":"Возвышение","nav.tower":"Башня","nav.heroes":"Герои","nav.summon":"Призыв","nav.souls":"Древо Душ","nav.quests":"Задания","nav.dailies":"Ежедневные","nav.expeditions":"Экспедиции","nav.relics":"Реликвии","nav.more":"Ещё","nav.settings":"Настройки","modal.more.title":"МЕНЮ И РЕЖИМЫ","building.title":"Секта","sect.title":"Секта","sect.subtitle":"Обитель и постройки вашей школы культивации","sect.best_value":"⭐ ВЫГОДНО","sect.milestone_next":"Веха","sect.unlocked_rank":"Открывается на ранге","sect.synergy":"Синергия","building.dojo.name":"Додзё Учеников","building.dojo.desc":"Тренировочный зал начальной закалки тела (+1/сек)","building.chamber.name":"Покои Медитации Ци","building.chamber.desc":"Изолированная комната накопления духовной энергии (+8/сек)","building.shrine.name":"Святилище Духа","building.shrine.desc":"Алтарь духовных предков и стихийной мощи (+47/сек)","building.academy.name":"Академия Воинов","building.academy.desc":"Школа высшего боевого мастерства (+260/сек)","building.forge.name":"Тайная Кузня Духа","building.forge.desc":"Ковка артефактов и закалка духовных клинков (+1.4K/сек)","building.reactor.name":"Реактор Маны","building.reactor.desc":"Конденсация эфирных потоков реальности (+8K/сек)","building.temple.name":"Небесный Храм","building.temple.desc":"Храм звездного сияния и высшей гармонии (+47K/сек)","building.gate.name":"Пространственные Врата","building.gate.desc":"Врата в иные измерения первозданной силы (+260K/сек)","building.fortress.name":"Звездная Цитадель","building.fortress.desc":"Крепость на орбите космического истока (+1.5M/сек)","building.core.name":"Ядро Бесконечности","building.core.desc":"Сверхмассивный генератор божественной энергии (+10M/сек)","upgrade.title":"Улучшения и Навыки","upgrade.iron_fist.name":"Железный Кулак","upgrade.iron_fist.desc":"Сила клика удваивается (×2)","upgrade.chi_flow.name":"Поток Ци","upgrade.chi_flow.desc":"+3 к базовой силе тренировки за уровень","upgrade.eagle_eye.name":"Орлиный Взор","upgrade.eagle_eye.desc":"+4% к шансу критического удара","upgrade.lethal_strike.name":"Смертоносный Удар","upgrade.lethal_strike.desc":"+1.0x к урону критического удара","upgrade.dojo_mastery.name":"Дисциплина Додзё","upgrade.dojo_mastery.desc":"Производство Додзё удваивается (×2)","upgrade.chamber_zen.name":"Дзен Покоев","upgrade.chamber_zen.desc":"Производство Покоев Медитации удваивается (×2)","upgrade.shrine_blessing.name":"Благословение Святилища","upgrade.shrine_blessing.desc":"Производство Святилищ Духа удваивается (×2)","upgrade.academy_drills.name":"Учения Академии","upgrade.academy_drills.desc":"Производство Академий Воинов удваивается (×2)","upgrade.forge_pyro.name":"Огонь Тайной Кузни","upgrade.forge_pyro.desc":"Производство Тайных Кузен удваивается (×2)","upgrade.reactor_overcharge.name":"Перегрузка Реактора","upgrade.reactor_overcharge.desc":"Производство Реакторов Маны удваивается (×2)","upgrade.temple_sanctity.name":"Святость Храма","upgrade.temple_sanctity.desc":"Производство Небесных Храмов удваивается (×2)","upgrade.gate_expansion.name":"Расширение Врат","upgrade.gate_expansion.desc":"Производство Пространственных Врат удваивается (×2)","upgrade.spirit_education.name":"Духовное Обучение","upgrade.spirit_education.desc":"Каждая Академия Воинов увеличивает производство Покоев Медитации на +3%","upgrade.celestial_discipline.name":"Небесная Дисциплина","upgrade.celestial_discipline.desc":"Каждый Небесный Храм увеличивает производство Додзё на +5%","upgrade.dimensional_training.name":"Пространственные Учения","upgrade.dimensional_training.desc":"Каждые Пространственные Врата увеличивают производство Академий на +4%","upgrade.golden_fortune.name":"Золотая Фортуна","upgrade.golden_fortune.desc":"+20% к добыче золота за уровень","upgrade.architect_wisdom.name":"Мудрость Архитектора","upgrade.architect_wisdom.desc":"-3% к стоимости всех строений за уровень","upgrade.spirit_resonance.name":"Духовный Резонанс","upgrade.spirit_resonance.desc":"+25% к общему производству Силы","upgrade.cosmic_flow.name":"Космический Поток","upgrade.cosmic_flow.desc":"+50% к общему производству Силы","upgrade.god_domain.name":"Домен Божества","upgrade.god_domain.desc":"+100% к общему производству Силы","upgrade.astral_slumber.name":"Астральный Сон","upgrade.astral_slumber.desc":"+2 часа к лимиту офлайн-прогресса","upgrade.tower_conqueror.name":"Завоеватель Башни","upgrade.tower_conqueror.desc":"+35% к боевой мощи в Башне","rank.current":"Текущий ранг","rank.next":"Следующее Возвышение","rank.req":"Требуется Силы","rank.multiplier":"Множитель Силы","rank.e.name":"Смертный Ученик","rank.e.title":"Ранг E: Ученик","rank.e.desc":"Смертный, едва начавший ощущать потоки духовной энергии.","rank.d.name":"Адепт Ци","rank.d.title":"Ранг D: Адепт Ци","rank.d.desc":"Духовная энергия стабильно течет по вашим меридианам.","rank.c.name":"Мастер Духа","rank.c.title":"Ранг C: Мастер Духа","rank.c.desc":"Аура материализуется в чистую силу. Бесконечная Башня открыта!","rank.b.name":"Повелитель Душ","rank.b.title":"Ранг B: Повелитель Душ","rank.b.desc":"Способен призывать союзных аниме-героев и клинки духа.","rank.a.name":"Владыка Домена","rank.a.title":"Ранг A: Владыка Домена","rank.a.desc":"Власть над стихиями и открытие врат Высшего Призыва.","rank.s.name":"Небесный Чемпион","rank.s.title":"Ранг S: Небесный Чемпион","rank.s.desc":"Достиг бессмертия. Открывается Великое Перерождение!","rank.ss.name":"Владыка Бездны","rank.ss.title":"Ранг SS: Владыка Бездны","rank.ss.desc":"Управляет пространством-временем и Древом Душ.","rank.sss.name":"Космический Монарх","rank.sss.title":"Ранг SSS: Космический Монарх","rank.sss.desc":"Одно присутствие способно менять звездные скопления.","rank.awakened.name":"Пробужденное Божество","rank.awakened.title":"Ранг: Пробужденное Божество","rank.awakened.desc":"Вы превзошли физические законы реальности.","rank.transcendent.name":"Трансцендентный Бог","rank.transcendent.title":"Ранг: Трансцендентный Бог","rank.transcendent.desc":"Вселенная преклоняется перед вашей безграничной аурой.","rank.celestial.name":"Небесный Исток","rank.celestial.title":"Ранг: Небесный Исток","rank.celestial.desc":"Первозданная искра творения горит внутри вас.","rank.immortal.name":"Бесконечный Владыка","rank.immortal.title":"Ранг: Бесконечный Владыка","rank.immortal.desc":"Вечный, всемогущий и бесконечный.","rarity.common":"Обычный","rarity.rare":"Редкий","rarity.epic":"Эпический","rarity.legendary":"Легендарный","rarity.mythic":"Мифический","hero.hiro.name":"Хиро","hero.hiro.title":"Ученик Быстрого Ветра","hero.hiro.desc":"Молодой мечник, посвятивший жизнь оттачиванию клинка.","hero.lin.name":"Лин","hero.lin.title":"Травница Водных Истоков","hero.lin.desc":"Собирает редкие травы, приносящие изобилие золота.","hero.tatsu.name":"Тацу","hero.tatsu.title":"Монах Железного Кулака","hero.tatsu.desc":"Продолжает духовную закалку даже во время отдыха.","hero.mei.name":"Мэй","hero.mei.title":"Призрачная Лучница","hero.mei.desc":"Никогда не промахивается по уязвимым точкам врагов.","hero.kael.name":"Каэль","hero.kael.title":"Теневой Ассасин","hero.kael.desc":"Наносит сокрушительные критические удары из тени.","hero.yuna.name":"Юна","hero.yuna.title":"Астральная Жрица","hero.yuna.desc":"Направляет энергию созвездий во время сна.","hero.shin.name":"Шин","hero.shin.title":"Клинок Молнии","hero.shin.desc":"Разрубает монстров Башни со скоростью грома.","hero.hana.name":"Хана","hero.hana.title":"Сакура-Ведьма","hero.hana.desc":"Очаровывает лепестками маны, увеличивая приток силы.","hero.ren.name":"Рен","hero.ren.title":"Жнец Бездны","hero.ren.desc":"Управляет спектральной косой потусторонних миров.","hero.ayaka.name":"Аяка","hero.ayaka.title":"Багровая Валькирия","hero.ayaka.desc":"Яростная укротительница драконов с несгибаемым духом.","hero.daiki.name":"Дайки","hero.daiki.title":"Страж Грома","hero.daiki.desc":"Создает астральные артефакты, умножающие всё золото.","hero.sora.name":"Сора","hero.sora.title":"Повелитель Ветров","hero.sora.desc":"Парит в вихрях бури, увеличивая шанс критического удара.","hero.akari.name":"Акари","hero.akari.title":"Солнечная Императрица","hero.akari.desc":"Излучает тепло и мощь тысячи пылающих солнц.","hero.ryu.name":"Рю","hero.ryu.title":"Потомок Бога Драконов","hero.ryu.desc":"Владеет первородным пламенем и силой древних драконов.","hero.tsukiko.name":"Цукико","hero.tsukiko.title":"Лунная Богиня","hero.tsukiko.desc":"Хранительница тайн ночи и астральной эссенции.","hero.kuro.name":"Куро","hero.kuro.title":"Владыка Бесконечной Бездны","hero.kuro.desc":"Верховная сущность бесконечного межпространства.","hero.amaterasu.name":"Аматэрасу","hero.amaterasu.title":"Богиня Солнца","hero.amaterasu.desc":"Первородная богиня, озаряющая всё сущее священным пламенем.","hero.hiro.skill_name":"Рассекающий Вихрь","hero.hiro.skill_desc":"Наносит 2.5x урона клинком ветра.","hero.lin.skill_name":"Благословение Лотоса","hero.lin.skill_desc":"Призывает 3.0x всплеск золота.","hero.tatsu.skill_name":"Пламенный Удар","hero.tatsu.skill_desc":"Наносит 2.8x взрывного урона.","hero.mei.skill_name":"Метка Орла","hero.mei.skill_desc":"Фокусирует крит с множителем 2.5x.","hero.kael.skill_name":"Шаг Тени","hero.kael.skill_desc":"Наносит 3.2x скрытного урона.","hero.yuna.skill_name":"Астральный Барьер","hero.yuna.skill_desc":"Дарует 3.5x всплеск духовной силы.","hero.shin.skill_name":"Раскат Грома","hero.shin.skill_desc":"Поражает молнией на 3.5x урона.","hero.hana.skill_name":"Танец Сакуры","hero.hana.skill_desc":"Дарует 3.2x всплеск духовной силы.","hero.ren.skill_name":"Жатва Душ","hero.ren.skill_desc":"Рассекает врага косой на 4.0x урона.","hero.ayaka.skill_name":"Багровое Копье","hero.ayaka.skill_desc":"Наносит 4.2x яростного огненного урона.","hero.daiki.skill_name":"Удар Земли","hero.daiki.skill_desc":"Сокрушает врага молотом на 4.5x урона.","hero.sora.skill_name":"Буря Небес","hero.sora.skill_desc":"Накладывает штормовую метку на 4.0x крит.","hero.akari.skill_name":"Солнечное Сияние","hero.akari.skill_desc":"Дарует 5.5x мощнейший всплеск силы.","hero.ryu.skill_name":"Рев Дракона","hero.ryu.skill_desc":"Испепеляет врага на 6.0x урона.","hero.tsukiko.skill_name":"Лунное Затмение","hero.tsukiko.skill_desc":"Призывает 6.0x поток золота и эссенции.","hero.kuro.skill_name":"Глас Бездны","hero.kuro.skill_desc":"Аннигилирует цель на 8.0x урона.","hero.amaterasu.skill_name":"Небесное Сияние","hero.amaterasu.skill_desc":"Направляет 8.5x священный поток солнечной мощи.","tower.title":"Бесконечная Башня","tower.floor":"Этаж","tower.boss":"БИТВА С БОССОМ","tower.auto_climb":"Авто-восхождение","tower.defeat":"ПОРАЖЕНИЕ - Повтор этажа...","tower.victory":"ЭТАЖ ЗАЧИЩЕН!","world.forest.name":"Мир 1: Лес Шепотов","world.sakura.name":"Мир 2: Сакура-Империя","world.abyss.name":"Мир 3: Багровая Бездна Демонов","world.frozen.name":"Мир 4: Ледяной Пик Отчаяния","world.void.name":"Мир 5: Святилище Бездны","monster.goblin":"Лесной Гоблин","monster.goblin.desc":"Проворный лесной бес.","monster.shadow_wolf":"Теневой Волк","monster.shadow_wolf.desc":"Хищник, наполненный энергией сумерек.","monster.treant":"Древний Энт","monster.treant.desc":"Гигантский оживший древесный страж.","boss.forest_king":"Король Лесных Демонов","boss.forest_king.desc":"Владыка темной чащи.","monster.ronin":"Падший Ронин","monster.ronin.desc":"Бродяга, искушенный запретными клинками.","monster.kitsune":"Лукавая Кицунэ","monster.kitsune.desc":"Девятихвостая лисица с призрачным огнем.","monster.monk":"Темный Монах","monster.monk.desc":"Читает зловещие заклинания.","boss.shogun":"Теневой Сёгун","boss.shogun.desc":"Полководец в проклятых доспехах.","monster.hellhound":"Адская Гончая","monster.hellhound.desc":"Рождена из лавы и злобы.","monster.fire_demon":"Демон Бездны","monster.fire_demon.desc":"Метает сокрушительные сгустки магмы.","monster.lava_golem":"Лавовый Колосс","monster.lava_golem.desc":"Непробиваемая скала с пылающим ядром.","boss.dragon":"Императорский Дракон Бездны","boss.dragon.desc":"Повелитель вулканического гнева.","monster.frost_golem":"Ледяной Голем","monster.frost_golem.desc":"Высечен из вечного арктического льда.","monster.ice_specter":"Морозный Призрак","monster.ice_specter.desc":"Замораживает душу одним касанием.","monster.blizzard_hawk":"Буревестник Метели","monster.blizzard_hawk.desc":"Рассекает ледяные ураганы.","boss.frost_monarch":"Монарх Вечной Зимы","boss.frost_monarch.desc":"Охлаждает целые галактики до абсолютного нуля.","monster.void_phantom":"Фантом Бездны","monster.void_phantom.desc":"Воплощение первозданной тьмы.","monster.astral_knight":"Астральный Рыцарь","monster.astral_knight.desc":"Страж космических границ.","monster.chaos_orb":"Сфера Хаоса","monster.chaos_orb.desc":"Искажает ткань пространства.","boss.cosmic_sovereign":"Космический Владыка Бездны","boss.cosmic_sovereign.desc":"Верховная сущность за гранью звезд.","soul.title":"Алтарь Перерождения","soul.desc":"Преодолейте смертную оболочку. Сбросьте Силу и Здания, чтобы получить Души и вечные космические силы.","soul.power.name":"Всплеск Души","soul.power.desc":"+15% к общему множителю Силы за уровень","soul.train.name":"Духовная Закалка","soul.train.desc":"+25% к силе активной тренировки за уровень","soul.building.name":"Обитель Духа","soul.building.desc":"+15% к производству строений за уровень","soul.gold.name":"Дух Мидаса","soul.gold.desc":"+20% к добыче Золота за уровень","soul.cost.name":"Эфирное Зодчество","soul.cost.desc":"-2% к стоимости строений за уровень (до -30%)","soul.quest.name":"Кармическое Воздаяние","soul.quest.desc":"+15% к наградам за задания за уровень","soul.offline.name":"Астральный Транс","soul.offline.desc":"+15% к офлайн доходу и +1 час к лимиту за уровень","soul.crit.name":"Божественная Кара","soul.crit.desc":"+2% к шансу крита и +25% к урону крита за уровень","soul.essence.name":"Астральный Резонанс","soul.essence.desc":"+30% к получению Эссенции Героев за уровень","soul.tower.name":"Авангард Башни","soul.tower.desc":"+25% к боевой мощи Башни и +20% к наградам за уровень","soul.rank.name":"Благословение Рангов","soul.rank.desc":"+10% к силе множителей Возвышения за уровень","soul.rebirth.name":"Вечный Круговорот","soul.rebirth.desc":"+15% к получению Душ при Перерождении за уровень","quest.title":"Испытания Пути","quest.train_10.name":"Первая Разминка","quest.train_10.desc":"Совершите 10 активных тренировок","quest.campaign_kill_5.name":"Первая Охота","quest.campaign_kill_5.desc":"Победите 5 монстров в Кампании","quest.reach_stage_1_3.name":"Вглубь Чащи","quest.reach_stage_1_3.desc":"Достигните Этапа 1-3 в Кампании","quest.defeat_elite_1.name":"Охотник на Элиту","quest.defeat_elite_1.desc":"Победите 1 элитного монстра в Кампании","quest.reach_stage_1_5.name":"Тропа Чудовищ","quest.reach_stage_1_5.desc":"Достигните Этапа 1-5 (Босс Чащи)","quest.defeat_boss_1.name":"Убийца Боссов","quest.defeat_boss_1.desc":"Победите 1 Босса в Кампании","quest.reach_stage_1_10.name":"Сердце Леса","quest.reach_stage_1_10.desc":"Достигните Этапа 1-10 (Повелитель Леса)","quest.clear_world_1.name":"Покоритель Леса","quest.clear_world_1.desc":"Полностью зачистите Мир 1: Лес Шепотов","quest.reach_stage_2_5.name":"Цветущая Империя","quest.reach_stage_2_5.desc":"Достигните Этапа 2-5 в Империи Сакуры","quest.defeat_boss_5.name":"Гроза Владык","quest.defeat_boss_5.desc":"Победите 5 Боссов в Кампании","quest.train_50.name":"Усердный Ученик","quest.train_50.desc":"Провести 50 активных тренировок","quest.train_250.name":"Закалка Меридианов","quest.train_250.desc":"Провести 250 активных тренировок","quest.train_1000.name":"Несгибаемый Мастер","quest.train_1000.desc":"Провести 1 000 активных тренировок","quest.build_1.name":"Первое Строение","quest.build_1.desc":"Постройте свое первое строение культивации","quest.dojo_10.name":"Порядок в Додзё","quest.dojo_10.desc":"Наймите 10 учеников Додзё","quest.chamber_10.name":"Глубокий Транс","quest.chamber_10.desc":"Постройте 10 Покоев Медитации","quest.shrine_10.name":"Служение Духу","quest.shrine_10.desc":"Постройте 10 Святилищ Духа","quest.build_25.name":"Развитие Секты","quest.build_25.desc":"Постройте 25 строений любого типа","quest.build_50.name":"Великий Обитель","quest.build_50.desc":"Постройте 50 строений любого типа","quest.build_100.name":"Империя Культиваторов","quest.build_100.desc":"Постройте 100 строений любого типа","quest.power_1k.name":"Тысяча Ки","quest.power_1k.desc":"Накопите 1 000 Силы за все время","quest.power_50k.name":"Мощь Потока","quest.power_50k.desc":"Накопите 50 000 Силы за все время","quest.power_1m.name":"Миллионный Прорыв","quest.power_1m.desc":"Накопите 1 000 000 Силы за все время","quest.power_100m.name":"Сила Ста Миллионов","quest.power_100m.desc":"Накопите 100 000 000 Силы за все время","quest.tower_5.name":"Первопроходец Башни","quest.tower_5.desc":"Пройти 5-й этаж Бесконечной Башни","quest.tower_10.name":"Покоритель Леса","quest.tower_10.desc":"Пройти 10-й этаж и победить первого Босса","quest.tower_25.name":"Глубины Подземелий","quest.tower_25.desc":"Пройти 25-й этаж Бесконечной Башни","quest.tower_50.name":"Чемпион 50 Этажей","quest.tower_50.desc":"Зачистить 50-й этаж","quest.tower_100.name":"Легенда Башни","quest.tower_100.desc":"Зачистить 100-й этаж","quest.summon_1.name":"Зов Союзников","quest.summon_1.desc":"Совершить 1 призыв героя","quest.summon_5.name":"Клятва Легенд","quest.summon_5.desc":"Совершить 5 призывов героев","quest.heroes_3.name":"Три Воина","quest.heroes_3.desc":"Соберите 3 различных героев","quest.heroes_8.name":"Элитный Отряд","quest.heroes_8.desc":"Соберите 8 различных героев","quest.rank_d.name":"Прорыв Меридианов","quest.rank_d.desc":"Возвыситься до Ранга D","quest.rank_b.name":"Знаменитый Мастер","quest.rank_b.desc":"Возвыситься до Ранга B","quest.rank_s.name":"Пик Смертных","quest.rank_s.desc":"Возвыситься до Ранга S","quest.reincarnate_1.name":"Новая Жизнь","quest.reincarnate_1.desc":"Совершите первое Перерождение","quest.daily.train.500":"Провести 500 тренировок","quest.daily.summon.1":"Призвать 1 героя","quest.daily.tower.3":"Пройти 3 этажа в Башне","quest.daily.upgrade.10":"Купить 10 улучшений",expedition_scout_forest:"Разведка Леса Шепотов",expedition_explore_ruins:"Исследование Древних Руин",expedition_abyssal_dive:"Погружение в Бездну","achieve.title":"Достижения","achieve.first_train.name":"Первый шаг на Пути","achieve.first_train.desc":"Совершите первое тренировочное нажатие","achieve.train_100.name":"Боевое Усердие","achieve.train_100.desc":"Совершите 100 тренировок","achieve.train_1000.name":"Несгибаемая Воля","achieve.train_1000.desc":"Совершите 1 000 тренировок","achieve.crit_50.name":"Критический Фокус","achieve.crit_50.desc":"Совершите 50 критических ударов","achieve.first_building.name":"Первый Камень","achieve.first_building.desc":"Приобретите первое строение","achieve.buildings_50.name":"Великое Строительство","achieve.buildings_50.desc":"Владейте 50 строениями одновременно","achieve.buildings_150.name":"Колоссальный Комплекс","achieve.buildings_150.desc":"Владейте 150 строениями одновременно","achieve.rank_d.name":"Адепт Ци","achieve.rank_d.desc":"Достигните Ранга D","achieve.rank_c.name":"Пробуждение Духа","achieve.rank_c.desc":"Достигните Ранга C","achieve.rank_b.name":"Мастер Душ","achieve.rank_b.desc":"Достигните Ранга B","achieve.rank_a.name":"Власть и Мощь","achieve.rank_a.desc":"Достигните Ранга A","achieve.rank_s.name":"Вершина Смертных","achieve.rank_s.desc":"Достигните Ранга S","achieve.rank_trans.name":"Божественный Статус","achieve.rank_trans.desc":"Достигните Трансцендентного Ранга","achieve.power_1m.name":"Миллион Ки","achieve.power_1m.desc":"Наберите 1 000 000 Силы","achieve.power_1b.name":"Миллиардная Мощь","achieve.power_1b.desc":"Наберите 1 000 000 000 Силы","achieve.tower_10.name":"Победитель Леса","achieve.tower_10.desc":"Победите Босса на 10-м этаже","achieve.tower_50.name":"Хозяин Чащи","achieve.tower_50.desc":"Зачистите 50-й этаж","achieve.tower_100.name":"Чемпион Сакуры","achieve.tower_100.desc":"Зачистите 100-й этаж","achieve.heroes_3.name":"Боевой Отряд","achieve.heroes_3.desc":"Соберите 3 различных героев","achieve.heroes_10.name":"Великая Армия","achieve.heroes_10.desc":"Соберите 10 различных героев","achieve.reincarnate_1.name":"Перерожденный из Пепла","achieve.reincarnate_1.desc":"Совершите свое первое Перерождение","achieve.world_1.name":"Освободитель Леса","achieve.world_1.desc":"Полностью зачистите Мир 1: Лес Шепотов","achieve.world_3.name":"Укротитель Бездны","achieve.world_3.desc":"Полностью зачистите Мир 3: Багровая Бездна","achieve.world_5.name":"Владыка Пустоты","achieve.world_5.desc":"Полностью зачистите Мир 5: Святилище Пустоты","achieve.bosses_10.name":"Истребитель Владык","achieve.bosses_10.desc":"Победите 10 Боссов Кампании","achieve.bosses_25.name":"Гроза Миров","achieve.bosses_25.desc":"Победите 25 Боссов Кампании","achieve.bosses_50.name":"Непобедимый Завоеватель","achieve.bosses_50.desc":"Победите 50 Боссов Кампании","achieve.kills_100.name":"Первая Сотня","achieve.kills_100.desc":"Победите 100 врагов в Кампании","achieve.kills_500.name":"Буря Клинков","achieve.kills_500.desc":"Победите 500 врагов в Кампании","achieve.kills_2500.name":"Абсолютная Жатва","achieve.kills_2500.desc":"Победите 2 500 врагов в Кампании","achieve.crits_100.name":"Точный Рассекатель","achieve.crits_100.desc":"Нанесите 100 критических ударов","achieve.crits_1000.name":"Смертоносный Шторм","achieve.crits_1000.desc":"Нанесите 1 000 критических ударов","achieve.combo_50.name":"Вихрь Комбо","achieve.combo_50.desc":"Достигните 50x серии комбо","achieve.hero_star_5.name":"Пятизвездная Легенда","achieve.hero_star_5.desc":"Возвысьте любого героя до 5 звезд","achieve.synergy_active.name":"Гармония Фракции","achieve.synergy_active.desc":"Активируйте синергию стихий в отряде","achieve.reincarnate_5.name":"Бессмертная Сансара","achieve.reincarnate_5.desc":"Совершите 5 Перерождений","achieve.souls_100.name":"Хранилище Душ","achieve.souls_100.desc":"Накопите 100 Душ Перерождения","modal.offline.title":"С ВОЗВРАЩЕНИЕМ, ВОИН!","modal.offline.time":"Время глубокой медитации:","modal.offline.earned":"Накопленные богатства:","modal.ascension.title":"ВОЗВЫШЕНИЕ ДОСТИГНУТО!","modal.ascension.congrats":"Вы прорвали смертные оковы и вышли на новый уровень!","modal.summon.title":"ПРИЗЫВ ГЕРОЯ","modal.summon.duplicate":"Повторный герой преобразован в Эссенцию!","modal.reincarnate.title":"ПОДТВЕРЖДЕНИЕ ПЕРЕРОЖДЕНИЯ","modal.reincarnate.warning":"Текущая Сила и обычные Строения будут сброшены. Вы сохраните Героев, Эссенцию, Достижения и получите Души.","modal.reincarnate.souls_awarded":"Будет получено Душ:","modal.stats.title":"ПРОФИЛЬ И БОЕВАЯ МОЩЬ","rpg.protagonist":"Культиватор","rpg.combat_power":"Боевая Мощь","rpg.tap_power":"Сила Удара","rpg.crit_rate":"Крит. Шанс","rpg.crit_dmg":"Крит. Урон","rpg.atk_speed":"Скорость Атаки","rpg.sources_title":"Источники Силы","rpg.sect_output":"Секта (Строения)","rpg.rank_mult":"Ранг Возвышения","rpg.heroes_party":"Отряд Героев","rpg.soul_mastery":"Древо Душ","rpg.relics_boost":"Реликвии","rpg.surge_buffs":"Всплеск Ци","rpg.next_ascension":"Возвышение","rpg.ready_to_ascend":"Готов к прорыву!","rpg.reach_power":"Требуется","settings.sound":"Звуковые эффекты","settings.music":"Фоновая музыка","settings.volume":"Громкость","settings.reduced_motion":"Уменьшенная анимация","settings.screen_shake":"Тряска экрана","settings.notation":"Формат чисел","settings.notation_standard":"Стандартный (1.25M)","settings.notation_scientific":"Научный (1.25e6)","settings.language":"Язык / Language","settings.reset":"Сбросить весь прогресс","settings.reset_confirm":"Вы уверены, что хотите стереть всё сохранение? Это действие необратимо!","campaign.title":"Кампания","campaign.world":"Мир","campaign.stage":"Этап","campaign.boss":"Босс","campaign.mini_boss":"Мини-босс","campaign.auto_advance_on":"АВТО ВКЛ","campaign.auto_advance_off":"АВТО ВЫКЛ","campaign.mode_progress":"ПРОГРЕСС","campaign.mode_farm":"ФАРМ","campaign.mode_rush":"РАШ","campaign.mode_boss_blocked":"БЛОКИРОВКА","campaign.retry_boss":"ПОВТОРИТЬ БОССА","campaign.boosted_retry":"УСИЛЕННЫЙ ПОВТОР","campaign.attack":"АТАКА","campaign.ascend":"ВОЗВЫСИТЬСЯ","campaign.victory":"ПОБЕДА","campaign.defeat":"ПОРАЖЕНИЕ","campaign.world_cleared":"МИР ПРОЙДЕН!","campaign.party_synergy":"Синергия отряда","campaign.solo_cultivator":"Одиночный культиватор","ad.offline.title":"Удвоить оффлайн-награду","ad.boss_boost.title":"Боевой прилив на босса","ad.boss_chest.title":"Бонусный сундук босса","ad.battle_surge.title":"Прилив боевой мощи","ad.free_summon.title":"Бесплатный призыв героя"},te=class te{constructor(){p(this,"currentLang","ru");p(this,"dictionaries",{ru:is,en:as});this.currentLang=d.get().settings.language||"ru"}static getInstance(){return te.instance||(te.instance=new te),te.instance}setLanguage(e){e!==this.currentLang&&(e==="ru"||e==="en")&&(this.currentLang=e,d.set(t=>{t.settings.language=e}),typeof document<"u"&&document.dispatchEvent(new CustomEvent("i18n:change",{detail:{lang:e}})))}getLanguage(){return this.currentLang}t(e,t){let a=(this.dictionaries[this.currentLang]||this.dictionaries.ru)[e]||this.dictionaries.en[e]||e;return t&&Object.entries(t).forEach(([i,n])=>{a=a.replace(new RegExp(`{${i}}`,"g"),String(n))}),a}};p(te,"instance");let Ue=te;const st=Ue.getInstance(),u=(r,e)=>st.t(r,e),Mt=[{count:10,multiplier:2},{count:25,multiplier:2},{count:50,multiplier:2},{count:100,multiplier:2},{count:150,multiplier:1.5},{count:200,multiplier:2},{count:300,multiplier:1.5},{count:400,multiplier:1.5},{count:500,multiplier:2},{count:750,multiplier:2},{count:1e3,multiplier:3}],oe=[{id:"dojo",nameKey:"building.dojo.name",descKey:"building.dojo.desc",icon:"🥋",baseCost:10,costGrowth:1.15,baseProduction:1,baseGoldProduction:1,requiredRankIndex:0},{id:"meditation_chamber",nameKey:"building.chamber.name",descKey:"building.chamber.desc",icon:"🧘",baseCost:100,costGrowth:1.15,baseProduction:8,baseGoldProduction:4,requiredRankIndex:0},{id:"spirit_shrine",nameKey:"building.shrine.name",descKey:"building.shrine.desc",icon:"⛩️",baseCost:1e3,costGrowth:1.15,baseProduction:60,baseGoldProduction:25,requiredRankIndex:1},{id:"warrior_academy",nameKey:"building.academy.name",descKey:"building.academy.desc",icon:"🏯",baseCost:12e3,costGrowth:1.15,baseProduction:450,baseGoldProduction:160,requiredRankIndex:1},{id:"arcane_forge",nameKey:"building.forge.name",descKey:"building.forge.desc",icon:"⚒️",baseCost:15e4,costGrowth:1.15,baseProduction:3500,baseGoldProduction:1100,requiredRankIndex:2},{id:"mana_reactor",nameKey:"building.reactor.name",descKey:"building.reactor.desc",icon:"🌀",baseCost:2e6,costGrowth:1.15,baseProduction:3e4,baseGoldProduction:8500,requiredRankIndex:3},{id:"celestial_temple",nameKey:"building.temple.name",descKey:"building.temple.desc",icon:"✨",baseCost:3e7,costGrowth:1.15,baseProduction:275e3,baseGoldProduction:7e4,requiredRankIndex:4},{id:"dimensional_gate",nameKey:"building.gate.name",descKey:"building.gate.desc",icon:"🌌",baseCost:5e8,costGrowth:1.15,baseProduction:27e5,baseGoldProduction:6e5,requiredRankIndex:5},{id:"star_fortress",nameKey:"building.fortress.name",descKey:"building.fortress.desc",icon:"🪐",baseCost:1e10,costGrowth:1.15,baseProduction:3e7,baseGoldProduction:6e6,requiredRankIndex:6},{id:"infinite_core",nameKey:"building.core.name",descKey:"building.core.desc",icon:"🔮",baseCost:25e10,costGrowth:1.15,baseProduction:38e7,baseGoldProduction:7e7,requiredRankIndex:7}];function Re(r){let e=1;for(const t of Mt)r>=t.count&&(e*=t.multiplier);return e}function rs(r){for(const e of Mt)if(r<e.count)return{target:e.count,multiplier:e.multiplier};return null}function G(r,e,t=1,s=0){if(t<=0)return 0;const a=Math.max(.1,1-s);if(t===1)return Math.max(1,Math.floor(r.baseCost*Math.pow(r.costGrowth,e)*a));const i=r.baseCost*Math.pow(r.costGrowth,e)*a,n=r.costGrowth,o=i*(Math.pow(n,t)-1)/(n-1);return Math.max(t,Math.floor(o))}function ut(r,e,t,s=0){if(t<G(r,e,1,s))return{count:0,totalCost:0};let a=1,i=5e3,n=0,o=0;for(;a<=i;){const l=Math.floor((a+i)/2),c=G(r,e,l,s);c<=t?(n=l,o=c,a=l+1):i=l-1}return{count:n,totalCost:o}}const qe=[{id:"iron_fist",nameKey:"upgrade.iron_fist.name",descKey:"upgrade.iron_fist.desc",icon:"👊",category:"click",baseCost:25,costGrowth:2.5,effectType:"click_power_mult",effectValue:2,maxLevel:10,requiredRankIndex:0},{id:"chi_flow",nameKey:"upgrade.chi_flow.name",descKey:"upgrade.chi_flow.desc",icon:"⚡",category:"click",baseCost:80,costGrowth:2.8,effectType:"click_power_flat",effectValue:3,maxLevel:10,requiredRankIndex:0},{id:"eagle_eye",nameKey:"upgrade.eagle_eye.name",descKey:"upgrade.eagle_eye.desc",icon:"🎯",category:"click",baseCost:250,costGrowth:3,effectType:"crit_chance",effectValue:.04,maxLevel:5,requiredRankIndex:0},{id:"lethal_strike",nameKey:"upgrade.lethal_strike.name",descKey:"upgrade.lethal_strike.desc",icon:"💥",category:"click",baseCost:1500,costGrowth:3,effectType:"crit_mult",effectValue:1,maxLevel:5,requiredRankIndex:1},{id:"dojo_mastery",nameKey:"upgrade.dojo_mastery.name",descKey:"upgrade.dojo_mastery.desc",icon:"🥋",category:"building",targetBuildingId:"dojo",baseCost:100,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:0,unlockCheck:r=>(r.buildings?.dojo||0)>=5},{id:"chamber_zen",nameKey:"upgrade.chamber_zen.name",descKey:"upgrade.chamber_zen.desc",icon:"🧘",category:"building",targetBuildingId:"meditation_chamber",baseCost:800,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:0,unlockCheck:r=>(r.buildings?.meditation_chamber||0)>=5},{id:"shrine_blessing",nameKey:"upgrade.shrine_blessing.name",descKey:"upgrade.shrine_blessing.desc",icon:"⛩️",category:"building",targetBuildingId:"spirit_shrine",baseCost:8e3,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:1,unlockCheck:r=>(r.buildings?.spirit_shrine||0)>=5},{id:"academy_drills",nameKey:"upgrade.academy_drills.name",descKey:"upgrade.academy_drills.desc",icon:"🏯",category:"building",targetBuildingId:"warrior_academy",baseCost:9e4,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:1,unlockCheck:r=>(r.buildings?.warrior_academy||0)>=5},{id:"forge_pyro",nameKey:"upgrade.forge_pyro.name",descKey:"upgrade.forge_pyro.desc",icon:"⚒️",category:"building",targetBuildingId:"arcane_forge",baseCost:1e6,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:2,unlockCheck:r=>(r.buildings?.arcane_forge||0)>=5},{id:"reactor_overcharge",nameKey:"upgrade.reactor_overcharge.name",descKey:"upgrade.reactor_overcharge.desc",icon:"🌀",category:"building",targetBuildingId:"mana_reactor",baseCost:15e6,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:3,unlockCheck:r=>(r.buildings?.mana_reactor||0)>=5},{id:"temple_sanctity",nameKey:"upgrade.temple_sanctity.name",descKey:"upgrade.temple_sanctity.desc",icon:"✨",category:"building",targetBuildingId:"celestial_temple",baseCost:25e7,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:4,unlockCheck:r=>(r.buildings?.celestial_temple||0)>=5},{id:"gate_expansion",nameKey:"upgrade.gate_expansion.name",descKey:"upgrade.gate_expansion.desc",icon:"🌌",category:"building",targetBuildingId:"dimensional_gate",baseCost:4e9,costGrowth:3,effectType:"building_mult",effectValue:2,maxLevel:5,requiredRankIndex:5,unlockCheck:r=>(r.buildings?.dimensional_gate||0)>=5},{id:"spirit_education",nameKey:"upgrade.spirit_education.name",descKey:"upgrade.spirit_education.desc",icon:"📜",category:"synergy",targetBuildingId:"meditation_chamber",sourceBuildingId:"warrior_academy",baseCost:15e4,costGrowth:3.5,effectType:"synergy_boost",effectValue:.03,maxLevel:5,requiredRankIndex:2},{id:"celestial_discipline",nameKey:"upgrade.celestial_discipline.name",descKey:"upgrade.celestial_discipline.desc",icon:"🌟",category:"synergy",targetBuildingId:"dojo",sourceBuildingId:"celestial_temple",baseCost:5e7,costGrowth:3.5,effectType:"synergy_boost",effectValue:.05,maxLevel:5,requiredRankIndex:4},{id:"dimensional_training",nameKey:"upgrade.dimensional_training.name",descKey:"upgrade.dimensional_training.desc",icon:"🌀",category:"synergy",targetBuildingId:"warrior_academy",sourceBuildingId:"dimensional_gate",baseCost:8e8,costGrowth:3.5,effectType:"synergy_boost",effectValue:.04,maxLevel:5,requiredRankIndex:5},{id:"golden_fortune",nameKey:"upgrade.golden_fortune.name",descKey:"upgrade.golden_fortune.desc",icon:"💰",category:"economy",baseCost:1e3,costGrowth:2.8,effectType:"global_gold_mult",effectValue:.2,maxLevel:5,requiredRankIndex:1},{id:"architect_wisdom",nameKey:"upgrade.architect_wisdom.name",descKey:"upgrade.architect_wisdom.desc",icon:"📐",category:"economy",baseCost:15e3,costGrowth:3.2,effectType:"building_cost_reduction",effectValue:.03,maxLevel:5,requiredRankIndex:1},{id:"spirit_resonance",nameKey:"upgrade.spirit_resonance.name",descKey:"upgrade.spirit_resonance.desc",icon:"✨",category:"global",baseCost:5e3,costGrowth:3.5,effectType:"global_power_mult",effectValue:.25,maxLevel:5,requiredRankIndex:1},{id:"cosmic_flow",nameKey:"upgrade.cosmic_flow.name",descKey:"upgrade.cosmic_flow.desc",icon:"🌌",category:"global",baseCost:15e4,costGrowth:4,effectType:"global_power_mult",effectValue:.5,maxLevel:5,requiredRankIndex:2},{id:"god_domain_expansion",nameKey:"upgrade.god_domain.name",descKey:"upgrade.god_domain.desc",icon:"👑",category:"global",baseCost:5e7,costGrowth:5,effectType:"global_power_mult",effectValue:1,maxLevel:5,requiredRankIndex:4},{id:"astral_slumber",nameKey:"upgrade.astral_slumber.name",descKey:"upgrade.astral_slumber.desc",icon:"⏳",category:"special",baseCost:2e4,costGrowth:3,effectType:"offline_cap_hours",effectValue:2,maxLevel:4,requiredRankIndex:1},{id:"tower_conqueror",nameKey:"upgrade.tower_conqueror.name",descKey:"upgrade.tower_conqueror.desc",icon:"🏰",category:"special",baseCost:1e5,costGrowth:3,effectType:"tower_dps_mult",effectValue:.35,maxLevel:5,requiredRankIndex:2}];function mt(r,e){return e>=r.maxLevel?1/0:Math.floor(r.baseCost*Math.pow(r.costGrowth,e))}const K={common:{color:"#94a3b8",glow:"rgba(148, 163, 184, 0.4)",nameKey:"rarity.common",pullRate:55,duplicateEssence:10},rare:{color:"#38bdf8",glow:"rgba(56, 189, 248, 0.5)",nameKey:"rarity.rare",pullRate:28,duplicateEssence:25},epic:{color:"#c084fc",glow:"rgba(192, 132, 252, 0.6)",nameKey:"rarity.epic",pullRate:12,duplicateEssence:75},legendary:{color:"#fbbf24",glow:"rgba(251, 191, 36, 0.7)",nameKey:"rarity.legendary",pullRate:4,duplicateEssence:250},mythic:{color:"#f43f5e",glow:"rgba(244, 63, 94, 0.85)",nameKey:"rarity.mythic",pullRate:1,duplicateEssence:1e3}},he=[{id:"hiro",nameKey:"hero.hiro.name",titleKey:"hero.hiro.title",rarity:"common",descriptionKey:"hero.hiro.desc",element:"wind",modifier:{type:"power_pct",baseValue:.1},avatarSeed:"hiro-blade",icon:"🗡️",skill:{nameKey:"hero.hiro.skill_name",descKey:"hero.hiro.skill_desc",icon:"🌪️",type:"direct_damage",cooldownSeconds:8,multiplier:2.5}},{id:"lin",nameKey:"hero.lin.name",titleKey:"hero.lin.title",rarity:"common",descriptionKey:"hero.lin.desc",element:"water",modifier:{type:"gold_pct",baseValue:.15},avatarSeed:"lin-staff",icon:"🌸",skill:{nameKey:"hero.lin.skill_name",descKey:"hero.lin.skill_desc",icon:"🌊",type:"gold_burst",cooldownSeconds:10,multiplier:3}},{id:"tatsu",nameKey:"hero.tatsu.name",titleKey:"hero.tatsu.title",rarity:"common",descriptionKey:"hero.tatsu.desc",element:"fire",modifier:{type:"offline_pct",baseValue:.15},avatarSeed:"tatsu-fist",icon:"🥊",skill:{nameKey:"hero.tatsu.skill_name",descKey:"hero.tatsu.skill_desc",icon:"🔥",type:"direct_damage",cooldownSeconds:8,multiplier:2.8}},{id:"mei",nameKey:"hero.mei.name",titleKey:"hero.mei.title",rarity:"common",descriptionKey:"hero.mei.desc",element:"wind",modifier:{type:"crit_chance",baseValue:.03},avatarSeed:"mei-bow",icon:"🏹",skill:{nameKey:"hero.mei.skill_name",descKey:"hero.mei.skill_desc",icon:"🎯",type:"crit_mark",cooldownSeconds:9,multiplier:2.5}},{id:"kael",nameKey:"hero.kael.name",titleKey:"hero.kael.title",rarity:"rare",descriptionKey:"hero.kael.desc",element:"void",modifier:{type:"crit_mult",baseValue:.35},avatarSeed:"kael-daggers",icon:"🗡️",skill:{nameKey:"hero.kael.skill_name",descKey:"hero.kael.skill_desc",icon:"🌑",type:"direct_damage",cooldownSeconds:8,multiplier:3.2}},{id:"yuna",nameKey:"hero.yuna.name",titleKey:"hero.yuna.title",rarity:"rare",descriptionKey:"hero.yuna.desc",element:"light",modifier:{type:"offline_pct",baseValue:.2},avatarSeed:"yuna-orb",icon:"🔮",skill:{nameKey:"hero.yuna.skill_name",descKey:"hero.yuna.skill_desc",icon:"✨",type:"power_burst",cooldownSeconds:10,multiplier:3.5}},{id:"shin",nameKey:"hero.shin.name",titleKey:"hero.shin.title",rarity:"rare",descriptionKey:"hero.shin.desc",element:"lightning",modifier:{type:"tower_atk_pct",baseValue:.2},avatarSeed:"shin-katana",icon:"⚡",skill:{nameKey:"hero.shin.skill_name",descKey:"hero.shin.skill_desc",icon:"⚡",type:"direct_damage",cooldownSeconds:7,multiplier:3.5}},{id:"hana",nameKey:"hero.hana.name",titleKey:"hero.hana.title",rarity:"rare",descriptionKey:"hero.hana.desc",element:"water",modifier:{type:"power_pct",baseValue:.18},avatarSeed:"hana-bloom",icon:"🌺",skill:{nameKey:"hero.hana.skill_name",descKey:"hero.hana.skill_desc",icon:"🌸",type:"power_burst",cooldownSeconds:9,multiplier:3.2}},{id:"ren",nameKey:"hero.ren.name",titleKey:"hero.ren.title",rarity:"epic",descriptionKey:"hero.ren.desc",element:"void",modifier:{type:"power_pct",baseValue:.25},avatarSeed:"ren-reaper",icon:"🌑",skill:{nameKey:"hero.ren.skill_name",descKey:"hero.ren.skill_desc",icon:"💀",type:"direct_damage",cooldownSeconds:8,multiplier:4}},{id:"ayaka",nameKey:"hero.ayaka.name",titleKey:"hero.ayaka.title",rarity:"epic",descriptionKey:"hero.ayaka.desc",element:"fire",modifier:{type:"tower_atk_pct",baseValue:.3},avatarSeed:"ayaka-spear",icon:"🔥",skill:{nameKey:"hero.ayaka.skill_name",descKey:"hero.ayaka.skill_desc",icon:"💥",type:"direct_damage",cooldownSeconds:8,multiplier:4.2}},{id:"daiki",nameKey:"hero.daiki.name",titleKey:"hero.daiki.title",rarity:"epic",descriptionKey:"hero.daiki.desc",element:"lightning",modifier:{type:"gold_pct",baseValue:.3},avatarSeed:"daiki-hammer",icon:"🔨",skill:{nameKey:"hero.daiki.skill_name",descKey:"hero.daiki.skill_desc",icon:"⚡",type:"direct_damage",cooldownSeconds:9,multiplier:4.5}},{id:"sora",nameKey:"hero.sora.name",titleKey:"hero.sora.title",rarity:"epic",descriptionKey:"hero.sora.desc",element:"wind",modifier:{type:"crit_chance",baseValue:.05},avatarSeed:"sora-feathers",icon:"🦅",skill:{nameKey:"hero.sora.skill_name",descKey:"hero.sora.skill_desc",icon:"🌪️",type:"crit_mark",cooldownSeconds:8,multiplier:4}},{id:"akari",nameKey:"hero.akari.name",titleKey:"hero.akari.title",rarity:"legendary",descriptionKey:"hero.akari.desc",element:"light",modifier:{type:"all_pct",baseValue:.25},avatarSeed:"akari-sun",icon:"☀️",skill:{nameKey:"hero.akari.skill_name",descKey:"hero.akari.skill_desc",icon:"☀️",type:"power_burst",cooldownSeconds:10,multiplier:5.5}},{id:"ryu",nameKey:"hero.ryu.name",titleKey:"hero.ryu.title",rarity:"legendary",descriptionKey:"hero.ryu.desc",element:"fire",modifier:{type:"power_pct",baseValue:.4},avatarSeed:"ryu-dragon",icon:"🐉",skill:{nameKey:"hero.ryu.skill_name",descKey:"hero.ryu.skill_desc",icon:"🐲",type:"direct_damage",cooldownSeconds:8,multiplier:6}},{id:"tsukiko",nameKey:"hero.tsukiko.name",titleKey:"hero.tsukiko.title",rarity:"legendary",descriptionKey:"hero.tsukiko.desc",element:"void",modifier:{type:"essence_pct",baseValue:.35},avatarSeed:"tsukiko-moon",icon:"🌙",skill:{nameKey:"hero.tsukiko.skill_name",descKey:"hero.tsukiko.skill_desc",icon:"🌙",type:"gold_burst",cooldownSeconds:10,multiplier:6}},{id:"kuro",nameKey:"hero.kuro.name",titleKey:"hero.kuro.title",rarity:"mythic",descriptionKey:"hero.kuro.desc",element:"void",modifier:{type:"all_pct",baseValue:.45},avatarSeed:"kuro-sovereign",icon:"👑",skill:{nameKey:"hero.kuro.skill_name",descKey:"hero.kuro.skill_desc",icon:"🌌",type:"direct_damage",cooldownSeconds:8,multiplier:8}},{id:"amaterasu",nameKey:"hero.amaterasu.name",titleKey:"hero.amaterasu.title",rarity:"mythic",descriptionKey:"hero.amaterasu.desc",element:"light",modifier:{type:"power_pct",baseValue:.5},avatarSeed:"amaterasu-sun",icon:"☀️",skill:{nameKey:"hero.amaterasu.skill_name",descKey:"hero.amaterasu.skill_desc",icon:"✨",type:"power_burst",cooldownSeconds:10,multiplier:8.5}}];function ve(r){return he.find(e=>e.id===r)}function at(r){switch(r){case 1:return 1;case 2:return 1.3;case 3:return 1.6;case 4:return 1.9;case 5:return 2.2;default:return 1}}function At(r,e){const t=K[e].duplicateEssence;return Math.floor(t*Math.pow(2,r-1))}const $e=[{id:"soul_power",branch:"strength",nameKey:"soul.power.name",descKey:"soul.power.desc",icon:"⚡",baseCost:1,costGrowth:1.45,maxLevel:50,baseEffect:.15},{id:"soul_train",branch:"strength",nameKey:"soul.train.name",descKey:"soul.train.desc",icon:"👊",baseCost:1,costGrowth:1.45,maxLevel:50,baseEffect:.25},{id:"soul_building",branch:"strength",nameKey:"soul.building.name",descKey:"soul.building.desc",icon:"🏯",baseCost:2,costGrowth:1.55,maxLevel:50,baseEffect:.15},{id:"soul_gold",branch:"wealth",nameKey:"soul.gold.name",descKey:"soul.gold.desc",icon:"💰",baseCost:1,costGrowth:1.45,maxLevel:50,baseEffect:.2},{id:"soul_cost",branch:"wealth",nameKey:"soul.cost.name",descKey:"soul.cost.desc",icon:"📐",baseCost:3,costGrowth:1.75,maxLevel:15,baseEffect:.02},{id:"soul_quest",branch:"wealth",nameKey:"soul.quest.name",descKey:"soul.quest.desc",icon:"📜",baseCost:2,costGrowth:1.6,maxLevel:30,baseEffect:.15},{id:"soul_offline",branch:"spirit",nameKey:"soul.offline.name",descKey:"soul.offline.desc",icon:"⏳",baseCost:2,costGrowth:1.65,maxLevel:25,baseEffect:.15},{id:"soul_crit",branch:"spirit",nameKey:"soul.crit.name",descKey:"soul.crit.desc",icon:"💥",baseCost:3,costGrowth:1.8,maxLevel:20,baseEffect:.02},{id:"soul_essence",branch:"spirit",nameKey:"soul.essence.name",descKey:"soul.essence.desc",icon:"✨",baseCost:4,costGrowth:1.85,maxLevel:20,baseEffect:.3},{id:"soul_tower",branch:"ascension",nameKey:"soul.tower.name",descKey:"soul.tower.desc",icon:"🏰",baseCost:2,costGrowth:1.65,maxLevel:30,baseEffect:.25},{id:"soul_rank",branch:"ascension",nameKey:"soul.rank.name",descKey:"soul.rank.desc",icon:"👑",baseCost:5,costGrowth:1.95,maxLevel:20,baseEffect:.1},{id:"soul_rebirth",branch:"ascension",nameKey:"soul.rebirth.name",descKey:"soul.rebirth.desc",icon:"🔄",baseCost:5,costGrowth:1.95,maxLevel:15,baseEffect:.15}];function ns(r){return $e.find(e=>e.id===r)}function Tt(r,e){return e>=r.maxLevel?1/0:Math.floor(r.baseCost*Math.pow(r.costGrowth,e))}function os(r,e=1,t=0){if(r<1e9)return 0;const a=Math.pow(r/15e6,.45),i=1+Math.min(3,(e-1)*.03),n=1+t*.15;return Math.max(1,Math.floor(a*i*n))}class I{static calculateMetrics(e,t=Date.now()){const s=O(e.rankId),i=1+(e.soulSkills.soul_rank||0)*.1,n=1+(s.multiplier-1)*i;let o=1,l=1,c=1,m=1,g=0,h=0,y=0,v=0,w=0,S=1;for(const b of $e){const k=e.soulSkills[b.id]||0;if(k>0)switch(b.id){case"soul_power":o+=k*b.baseEffect;break;case"soul_train":l+=k*b.baseEffect;break;case"soul_building":c+=k*b.baseEffect;break;case"soul_gold":m+=k*b.baseEffect;break;case"soul_cost":g+=k*b.baseEffect;break;case"soul_offline":h+=k*b.baseEffect,y+=k*1;break;case"soul_crit":v+=k*b.baseEffect,w+=k*.25;break;case"soul_tower":S+=k*b.baseEffect;break}}g=Math.min(.35,g);let $=0,M=0,A=0,q=0,j=0,P=0;for(const[b,k]of Object.entries(e.heroes||{})){const Q=ve(b);if(Q&&k.stars>0){const J=at(k.stars),z=Q.modifier.baseValue*J;switch(Q.modifier.type){case"power_pct":$+=z;break;case"gold_pct":M+=z;break;case"crit_chance":A+=z;break;case"crit_mult":q+=z;break;case"offline_pct":j+=z;break;case"tower_atk_pct":P+=z;break;case"all_pct":$+=z,M+=z,P+=z,j+=z;break}}}const L=1+$,X=1+M,ce=1+P;let B=1;e.buffs.celestialSurgeEndsAt>t&&(B*=2),e.buffs.adPowerSurgeEndsAt>t&&(B*=2),e.buffs.frenzyEndsAt>t&&(B*=3);let T=1,_e=1,ke=0,Z=0,W=1,ue=1,me=0,N=1,Se=0;const F={};for(const b of qe){const k=e.upgrades[b.id]||0;if(k>0)if(b.effectType==="click_power_flat")T+=k*b.effectValue;else if(b.effectType==="click_power_mult")_e*=Math.pow(b.effectValue,k);else if(b.effectType==="crit_chance")ke+=k*b.effectValue;else if(b.effectType==="crit_mult")Z+=k*b.effectValue;else if(b.effectType==="building_mult"&&b.targetBuildingId)F[b.targetBuildingId]=(F[b.targetBuildingId]||1)*Math.pow(b.effectValue,k);else if(b.effectType==="synergy_boost"&&b.targetBuildingId&&b.sourceBuildingId){const J=1+(e.buildings[b.sourceBuildingId]||0)*(k*b.effectValue);F[b.targetBuildingId]=(F[b.targetBuildingId]||1)*J}else b.effectType==="global_power_mult"?W+=k*b.effectValue:b.effectType==="global_gold_mult"?ue+=k*b.effectValue:b.effectType==="building_cost_reduction"?me+=k*b.effectValue:b.effectType==="tower_dps_mult"?N+=k*b.effectValue:b.effectType==="offline_cap_hours"&&(Se+=k*b.effectValue)}const zt=Math.min(.5,g+me);let pe=0,Ge=0;const Ie={};for(const b of oe){const k=e.buildings[b.id]||0,Q=Re(k),J=F[b.id]||1,z=b.baseProduction*Q*J*c,Ut=b.baseGoldProduction*Q*J,lt=k*z,dt=k*Ut;pe+=lt,Ge+=dt,Ie[b.id]={buildingId:b.id,owned:k,basePowerPerSec:b.baseProduction,baseGoldPerSec:b.baseGoldProduction,milestoneMultiplier:Q,upgradeMultiplier:J,totalBuildingPowerPerSec:lt,totalBuildingGoldPerSec:dt,contributionPct:0}}if(pe>0)for(const b of oe)Ie[b.id].contributionPct=Math.floor(Ie[b.id].totalBuildingPowerPerSec/pe*100);const Ht=n*L*o*W*B,Nt=X*m*ue*B,Fe=pe*Ht,rt=Ge*Nt,nt=e.combo?.multiplier||1,ot=Math.max(1,Math.floor(T*_e*n*L*l*nt*(B>1?2:1))),Gt=Math.max(1,Math.floor(1*(1+(T-1)*.5)*X*m*(B>1?2:1))),Ft=Math.min(.75,.05+A+v+ke),Ot=5+q+w+Z,Vt=Math.max(10,Math.floor(Fe*.75+ot*3)),jt=Math.floor(Vt*ce*S*N),Wt=(8+y+Se)*3600,Qt=Math.min(1,.5+j+h);return{clickPower:ot,clickGold:Gt,critChance:Ft,critMultiplier:Ot,baseBuildingsPowerPerSec:pe,baseBuildingsGoldPerSec:Ge,passivePowerPerSec:Fe,passiveGoldPerSec:rt,towerCombatPower:jt,rankMultiplier:n,globalUpgradesMultiplier:W,heroPowerMultiplier:L,heroGoldMultiplier:X,heroTowerMultiplier:ce,soulPowerMultiplier:o,soulGoldMultiplier:m,activeSurgeMultiplier:B,comboMultiplier:nt,maxOfflineSeconds:Wt,offlineEfficiency:Qt,buildingCostDiscount:zt,breakdown:{rawBuildingsPower:pe,rankMultiplier:n,heroPowerMultiplier:L,soulPowerMultiplier:o,globalUpgradesMultiplier:W,activeSurgeMultiplier:B,totalPowerPerSec:Fe,totalGoldPerSec:rt},buildingDetails:Ie}}}class It{static calculateOfflineGains(e,t=Date.now()){const s=Math.floor((t-e.lastSeenAt)/1e3);if(s<30)return null;const a=I.calculateMetrics(e,e.lastSeenAt),i=Math.min(s,a.maxOfflineSeconds),n=a.passivePowerPerSec*i*a.offlineEfficiency,o=a.passiveGoldPerSec*i*a.offlineEfficiency;return{seconds:s,cappedSeconds:i,powerGained:Math.floor(n),goldGained:Math.floor(o)}}}const Ke=[{id:"first_training",nameKey:"achieve.first_train.name",descKey:"achieve.first_train.desc",icon:"👊",rewardCrystals:20,check:r=>r.stats.totalClicks>=1},{id:"train_100",nameKey:"achieve.train_100.name",descKey:"achieve.train_100.desc",icon:"🥋",rewardCrystals:50,check:r=>r.stats.totalClicks>=100},{id:"train_1000",nameKey:"achieve.train_1000.name",descKey:"achieve.train_1000.desc",icon:"⚡",rewardCrystals:150,check:r=>r.stats.totalClicks>=1e3},{id:"crit_50",nameKey:"achieve.crit_50.name",descKey:"achieve.crit_50.desc",icon:"💥",rewardCrystals:75,check:r=>r.stats.totalCrits>=50},{id:"achieve_crits_100",nameKey:"achieve.crits_100.name",descKey:"achieve.crits_100.desc",icon:"💥",rewardCrystals:100,check:r=>(r.stats.totalCrits||0)>=100},{id:"achieve_crits_1000",nameKey:"achieve.crits_1000.name",descKey:"achieve.crits_1000.desc",icon:"⚡",rewardCrystals:300,check:r=>(r.stats.totalCrits||0)>=1e3},{id:"achieve_combo_50",nameKey:"achieve.combo_50.name",descKey:"achieve.combo_50.desc",icon:"🌪️",rewardCrystals:150,check:r=>(r.combo?.count||0)>=50},{id:"achieve_kills_100",nameKey:"achieve.kills_100.name",descKey:"achieve.kills_100.desc",icon:"💀",rewardCrystals:75,check:r=>(r.stats.campaignEnemiesDefeated||0)>=100},{id:"achieve_kills_500",nameKey:"achieve.kills_500.name",descKey:"achieve.kills_500.desc",icon:"🩸",rewardCrystals:200,check:r=>(r.stats.campaignEnemiesDefeated||0)>=500},{id:"achieve_kills_2500",nameKey:"achieve.kills_2500.name",descKey:"achieve.kills_2500.desc",icon:"☠️",rewardCrystals:500,check:r=>(r.stats.campaignEnemiesDefeated||0)>=2500},{id:"achieve_bosses_10",nameKey:"achieve.bosses_10.name",descKey:"achieve.bosses_10.desc",icon:"⚔️",rewardCrystals:200,check:r=>(r.stats.campaignBossesDefeated||0)>=10},{id:"achieve_bosses_25",nameKey:"achieve.bosses_25.name",descKey:"achieve.bosses_25.desc",icon:"🗡️",rewardCrystals:400,check:r=>(r.stats.campaignBossesDefeated||0)>=25},{id:"achieve_bosses_50",nameKey:"achieve.bosses_50.name",descKey:"achieve.bosses_50.desc",icon:"👑",rewardCrystals:800,check:r=>(r.stats.campaignBossesDefeated||0)>=50},{id:"achieve_world_1",nameKey:"achieve.world_1.name",descKey:"achieve.world_1.desc",icon:"🌲",rewardCrystals:150,check:r=>(r.stats.campaignWorldsCleared||0)>=1},{id:"achieve_world_3",nameKey:"achieve.world_3.name",descKey:"achieve.world_3.desc",icon:"🌋",rewardCrystals:350,check:r=>(r.stats.campaignWorldsCleared||0)>=3},{id:"achieve_world_5",nameKey:"achieve.world_5.name",descKey:"achieve.world_5.desc",icon:"🌌",rewardCrystals:750,check:r=>(r.stats.campaignWorldsCleared||0)>=5},{id:"first_building",nameKey:"achieve.first_building.name",descKey:"achieve.first_building.desc",icon:"🏗️",rewardCrystals:30,check:r=>Object.values(r.buildings||{}).some(e=>e>0)},{id:"buildings_50",nameKey:"achieve.buildings_50.name",descKey:"achieve.buildings_50.desc",icon:"🏯",rewardCrystals:100,check:r=>Object.values(r.buildings||{}).reduce((e,t)=>e+t,0)>=50},{id:"buildings_150",nameKey:"achieve.buildings_150.name",descKey:"achieve.buildings_150.desc",icon:"🌆",rewardCrystals:250,check:r=>Object.values(r.buildings||{}).reduce((e,t)=>e+t,0)>=150},{id:"rank_d",nameKey:"achieve.rank_d.name",descKey:"achieve.rank_d.desc",icon:"🌀",rewardCrystals:50,check:r=>r.rankIndex>=1},{id:"rank_c",nameKey:"achieve.rank_c.name",descKey:"achieve.rank_c.desc",icon:"🥉",rewardCrystals:100,check:r=>r.rankIndex>=2},{id:"rank_b",nameKey:"achieve.rank_b.name",descKey:"achieve.rank_b.desc",icon:"🥈",rewardCrystals:150,check:r=>r.rankIndex>=3},{id:"rank_a",nameKey:"achieve.rank_a.name",descKey:"achieve.rank_a.desc",icon:"🥇",rewardCrystals:250,check:r=>r.rankIndex>=4},{id:"rank_s",nameKey:"achieve.rank_s.name",descKey:"achieve.rank_s.desc",icon:"👑",rewardCrystals:500,check:r=>r.rankIndex>=5},{id:"rank_transcendent",nameKey:"achieve.rank_trans.name",descKey:"achieve.rank_trans.desc",icon:"🌌",rewardCrystals:1500,check:r=>r.rankIndex>=9},{id:"power_1m",nameKey:"achieve.power_1m.name",descKey:"achieve.power_1m.desc",icon:"🔥",rewardCrystals:150,check:r=>r.stats.lifetimePower>=1e6},{id:"power_1b",nameKey:"achieve.power_1b.name",descKey:"achieve.power_1b.desc",icon:"💫",rewardCrystals:500,check:r=>r.stats.lifetimePower>=1e9},{id:"tower_10",nameKey:"achieve.tower_10.name",descKey:"achieve.tower_10.desc",icon:"🏰",rewardCrystals:100,check:r=>r.towerFloor>=10},{id:"tower_50",nameKey:"achieve.tower_50.name",descKey:"achieve.tower_50.desc",icon:"🌸",rewardCrystals:300,check:r=>r.towerFloor>=50},{id:"tower_100",nameKey:"achieve.tower_100.name",descKey:"achieve.tower_100.desc",icon:"👹",rewardCrystals:750,check:r=>r.towerFloor>=100},{id:"heroes_3",nameKey:"achieve.heroes_3.name",descKey:"achieve.heroes_3.desc",icon:"👥",rewardCrystals:100,check:r=>Object.keys(r.heroes||{}).length>=3},{id:"heroes_10",nameKey:"achieve.heroes_10.name",descKey:"achieve.heroes_10.desc",icon:"🌟",rewardCrystals:500,check:r=>Object.keys(r.heroes||{}).length>=10},{id:"achieve_hero_star_5",nameKey:"achieve.hero_star_5.name",descKey:"achieve.hero_star_5.desc",icon:"⭐",rewardCrystals:600,check:r=>Object.values(r.heroes||{}).some(e=>e.stars>=5)},{id:"first_reincarnation",nameKey:"achieve.reincarnate_1.name",descKey:"achieve.reincarnate_1.desc",icon:"🔄",rewardCrystals:300,check:r=>r.reincarnationCount>=1},{id:"achieve_reincarnate_5",nameKey:"achieve.reincarnate_5.name",descKey:"achieve.reincarnate_5.desc",icon:"🌀",rewardCrystals:600,check:r=>r.reincarnationCount>=5},{id:"achieve_souls_100",nameKey:"achieve.souls_100.name",descKey:"achieve.souls_100.desc",icon:"💎",rewardCrystals:400,check:r=>(r.souls||0)>=100}],Ee=[{id:1,nameKey:"world.forest.name",defaultName:"Whispering Forest",descriptionKey:"world.forest.desc",theme:"forest",emoji:"🌲",accentColor:"#4ade80",bgGradient:"radial-gradient(circle at 50% 30%, rgba(20, 83, 45, 0.45), rgba(15, 23, 42, 0.98))",stageCount:10,minRankIndex:0,bgAsset:"bg_forest",musicTrack:"bgm_world_1",worldModifier:{type:"gold",bonusPct:.1,label:"+10% Gold"}},{id:2,nameKey:"world.sakura.name",defaultName:"Sakura Empire",descriptionKey:"world.sakura.desc",theme:"sakura",emoji:"🌸",accentColor:"#f472b6",bgGradient:"radial-gradient(circle at 50% 30%, rgba(190, 24, 93, 0.40), rgba(15, 23, 42, 0.98))",stageCount:10,minRankIndex:2,bgAsset:"bg_sakura",musicTrack:"bgm_world_2",worldModifier:{type:"power",bonusPct:.15,label:"+15% Power"}},{id:3,nameKey:"world.abyss.name",defaultName:"Crimson Abyss",descriptionKey:"world.abyss.desc",theme:"volcano",emoji:"🌋",accentColor:"#f87171",bgGradient:"radial-gradient(circle at 50% 30%, rgba(185, 28, 28, 0.45), rgba(15, 23, 42, 0.98))",stageCount:10,minRankIndex:4,bgAsset:"bg_abyss",musicTrack:"bgm_world_3",worldModifier:{type:"crit",bonusPct:.05,label:"+5% Crit Rate"}},{id:4,nameKey:"world.frozen.name",defaultName:"Frozen Peak",descriptionKey:"world.frozen.desc",theme:"ice",emoji:"❄️",accentColor:"#38bdf8",bgGradient:"radial-gradient(circle at 50% 30%, rgba(14, 116, 144, 0.45), rgba(15, 23, 42, 0.98))",stageCount:10,minRankIndex:6,bgAsset:"bg_frozen",musicTrack:"bgm_world_4",worldModifier:{type:"essence",bonusPct:.2,label:"+20% Essence"}},{id:5,nameKey:"world.void.name",defaultName:"Void Sanctuary",descriptionKey:"world.void.desc",theme:"void",emoji:"🌌",accentColor:"#c084fc",bgGradient:"radial-gradient(circle at 50% 30%, rgba(88, 28, 135, 0.50), rgba(15, 23, 42, 0.98))",stageCount:10,minRankIndex:8,bgAsset:"bg_void",musicTrack:"bgm_world_5",worldModifier:{type:"power",bonusPct:.25,label:"+25% Power"}}];function Me(r){return Ee.find(e=>e.id===r)}const ls={boss_1_5:{id:"boss_1_5",worldId:1,stageId:"1-5",nameKey:"boss_1_5_name",defaultName:"Grimbark the Corrupted",titleKey:"boss_1_5_title",defaultTitle:"Awakened Ancient",baseHpMultiplier:2.5,timerSeconds:30,spriteId:"boss_treant",specialMechanic:"shield",firstClearRewards:{gold:500,power:800,crystals:50,essence:10}},boss_1_10:{id:"boss_1_10",worldId:1,stageId:"1-10",nameKey:"boss_1_10_name",defaultName:"Demon Sovereign Malgok",titleKey:"boss_1_10_title",defaultTitle:"Scourge of the Whispering Forest",baseHpMultiplier:4,timerSeconds:40,spriteId:"boss_forest_demon",specialMechanic:"enrage",firstClearRewards:{gold:2500,power:4e3,crystals:150,essence:30,souls:5}},boss_2_5:{id:"boss_2_5",worldId:2,stageId:"2-5",nameKey:"boss_2_5_name",defaultName:"Shadowblade Hanzo",titleKey:"boss_2_5_title",defaultTitle:"Master of Nine Shadows",baseHpMultiplier:2.8,timerSeconds:30,spriteId:"boss_shadow_ninja",specialMechanic:"shield",firstClearRewards:{gold:15e3,power:25e3,crystals:75,essence:25}},boss_2_10:{id:"boss_2_10",worldId:2,stageId:"2-10",nameKey:"boss_2_10_name",defaultName:"Shogun Ghost Nobunaga",titleKey:"boss_2_10_title",defaultTitle:"Immortal Sovereign of Blades",baseHpMultiplier:4.5,timerSeconds:45,spriteId:"boss_ghost_shogun",specialMechanic:"damage_reduction",firstClearRewards:{gold:1e5,power:18e4,crystals:250,essence:60,souls:15}},boss_3_5:{id:"boss_3_5",worldId:3,stageId:"3-5",nameKey:"boss_3_5_name",defaultName:"Magma Core Ignis",titleKey:"boss_3_5_title",defaultTitle:"Living Crucible",baseHpMultiplier:3,timerSeconds:30,spriteId:"boss_magma_core",specialMechanic:"shield",firstClearRewards:{gold:6e5,power:12e5,crystals:100,essence:40}},boss_3_10:{id:"boss_3_10",worldId:3,stageId:"3-10",nameKey:"boss_3_10_name",defaultName:"Abyssal Overlord Bael",titleKey:"boss_3_10_title",defaultTitle:"Monarch of Eternal Flame",baseHpMultiplier:5,timerSeconds:45,spriteId:"boss_infernal_lord",specialMechanic:"enrage",firstClearRewards:{gold:5e6,power:1e7,crystals:400,essence:100,souls:35}},boss_4_5:{id:"boss_4_5",worldId:4,stageId:"4-5",nameKey:"boss_4_5_name",defaultName:"Frost Queen Ymir",titleKey:"boss_4_5_title",defaultTitle:"Goddess of Absolute Zero",baseHpMultiplier:3.2,timerSeconds:30,spriteId:"boss_frost_queen",specialMechanic:"damage_reduction",firstClearRewards:{gold:3e7,power:7e7,crystals:150,essence:60}},boss_4_10:{id:"boss_4_10",worldId:4,stageId:"4-10",nameKey:"boss_4_10_name",defaultName:"Glacial Dragon Nidhogg",titleKey:"boss_4_10_title",defaultTitle:"Terror of the Frozen Peak",baseHpMultiplier:5.5,timerSeconds:50,spriteId:"boss_frost_dragon",specialMechanic:"shield",firstClearRewards:{gold:25e7,power:6e8,crystals:600,essence:150,souls:75}},boss_5_5:{id:"boss_5_5",worldId:5,stageId:"5-5",nameKey:"boss_5_5_name",defaultName:"Cosmic Devourer",titleKey:"boss_5_5_title",defaultTitle:"Eater of Realities",baseHpMultiplier:3.5,timerSeconds:30,spriteId:"boss_void_eater",specialMechanic:"enrage",firstClearRewards:{gold:2e9,power:5e9,crystals:250,essence:100}},boss_5_10:{id:"boss_5_10",worldId:5,stageId:"5-10",nameKey:"boss_5_10_name",defaultName:"Void Supreme Sovereign",titleKey:"boss_5_10_title",defaultTitle:"The Infinite Zero",baseHpMultiplier:6,timerSeconds:60,spriteId:"boss_void_god",specialMechanic:"damage_reduction",firstClearRewards:{gold:2e10,power:5e10,crystals:1500,essence:300,souls:200}}};function qt(r){return ls[r]}const Kt={},it=[],pt={1:{normal:["forest_goblin","dire_wolf","corrupted_treant","forest_spirit"],elite:["forest_alpha"]},2:{normal:["rogue_ninja","bamboo_ronin","temple_guardian","kitsune_shade"],elite:["corrupted_samurai"]},3:{normal:["flame_imp","magma_beast","obsidian_golem","infernal_sorcerer"],elite:["abyss_executioner"]},4:{normal:["frost_wolf","ice_archer","glacier_elemental","blizzard_specter"],elite:["frost_wyrm"]},5:{normal:["void_crawler","cosmic_ray","astral_colossus","singularity_cultist"],elite:["void_harbinger"]}};function ds(r,e,t){const s=40*Math.pow(1.26,r-1);return Math.floor(e?s*4.5:t?s*2.5:s)}function Rt(r,e){const t=Math.floor(8*Math.pow(1.22,r-1)),s=Math.floor(12*Math.pow(1.24,r-1));return e?{gold:t*3,power:s*3,crystals:Math.min(25,2+Math.floor(r/2)),essence:Math.min(10,1+Math.floor(r/5))}:{gold:t,power:s}}function cs(r,e,t,s){const a=Rt(r,s),i=qt(`boss_${e}_${t}`);return i?i.firstClearRewards:{gold:a.gold*5,power:a.power*5,crystals:s?50:5,essence:s?10:0}}let ge=1;for(const r of Ee){const e=pt[r.id]||pt[1];for(let t=1;t<=r.stageCount;t++){const s=`${r.id}-${t}`,a=t===r.stageCount,i=t===Math.floor(r.stageCount/2),n=a||i?`boss_${r.id}_${t}`:void 0,o=a||i?[n]:t%3===0?[...e.normal,...e.elite]:e.normal,l=ds(ge,a,i),c=Rt(ge,a),m=cs(ge,r.id,t,a),g={id:s,worldId:r.id,stageNumber:t,globalIndex:ge,isBoss:a||i,bossId:n,bossTimerSeconds:a?45:i?30:void 0,enemyCount:a||i?1:3+t%3,enemyPool:o,difficulty:ge,baseHp:l,baseRewards:c,firstClearRewards:m};Kt[s]=g,it.push(g),ge++}}function D(r){return Kt[r]}function gt(r){const e=D(r);if(!e)return;const t=e.globalIndex+1;return it.find(a=>a.globalIndex===t)?.id}function us(r){const e=D(r);if(!e||e.globalIndex<=1)return;const t=e.globalIndex-1;return it.find(a=>a.globalIndex===t)?.id}const xe=[{id:"quest_train_10",nameKey:"quest.train_10.name",descKey:"quest.train_10.desc",targetCount:10,reward:{gold:15,crystals:10},getProgress:r=>r.stats?.totalClicks||0},{id:"quest_campaign_kill_5",nameKey:"quest.campaign_kill_5.name",descKey:"quest.campaign_kill_5.desc",targetCount:5,reward:{gold:25,crystals:15},getProgress:r=>r.stats?.campaignEnemiesDefeated||0},{id:"quest_build_1",nameKey:"quest.build_1.name",descKey:"quest.build_1.desc",targetCount:1,reward:{gold:50,crystals:20},getProgress:r=>Object.values(r.buildings||{}).reduce((e,t)=>e+(Number(t)||0),0)},{id:"quest_reach_stage_1_3",nameKey:"quest.reach_stage_1_3.name",descKey:"quest.reach_stage_1_3.desc",targetCount:3,reward:{gold:80,crystals:25},getProgress:r=>D(r.campaign?.highestStageReached)?.globalIndex||1},{id:"quest_build_10_dojo",nameKey:"quest.dojo_10.name",descKey:"quest.dojo_10.desc",targetCount:10,reward:{gold:150,crystals:30},getProgress:r=>r.buildings?.dojo||0},{id:"quest_rank_d",nameKey:"quest.rank_d.name",descKey:"quest.rank_d.desc",targetCount:1,reward:{gold:300,crystals:40},getProgress:r=>r.rankIndex||0},{id:"quest_defeat_elite_1",nameKey:"quest.defeat_elite_1.name",descKey:"quest.defeat_elite_1.desc",targetCount:1,reward:{gold:250,crystals:35},getProgress:r=>r.stats?.campaignElitesDefeated||0},{id:"quest_build_10_chamber",nameKey:"quest.chamber_10.name",descKey:"quest.chamber_10.desc",targetCount:10,reward:{goldSeconds:60,crystals:40},getProgress:r=>r.buildings?.meditation_chamber||0},{id:"quest_reach_stage_1_5",nameKey:"quest.reach_stage_1_5.name",descKey:"quest.reach_stage_1_5.desc",targetCount:5,reward:{gold:500,crystals:50},getProgress:r=>D(r.campaign?.highestStageReached)?.globalIndex||1},{id:"quest_defeat_boss_1",nameKey:"quest.defeat_boss_1.name",descKey:"quest.defeat_boss_1.desc",targetCount:1,reward:{gold:1e3,crystals:75,essence:25},getProgress:r=>r.stats?.campaignBossesDefeated||0},{id:"quest_reach_stage_1_10",nameKey:"quest.reach_stage_1_10.name",descKey:"quest.reach_stage_1_10.desc",targetCount:10,reward:{gold:2e3,crystals:100,essence:50},getProgress:r=>D(r.campaign?.highestStageReached)?.globalIndex||1},{id:"quest_clear_world_1",nameKey:"quest.clear_world_1.name",descKey:"quest.clear_world_1.desc",targetCount:1,reward:{crystals:500,essence:150},getProgress:r=>r.stats?.campaignWorldsCleared||0},{id:"quest_tower_5",nameKey:"quest.tower_5.name",descKey:"quest.tower_5.desc",targetCount:5,reward:{crystals:50,essence:25},getProgress:r=>r.towerFloor||1},{id:"quest_tower_10",nameKey:"quest.tower_10.name",descKey:"quest.tower_10.desc",targetCount:10,reward:{crystals:100,essence:50},getProgress:r=>r.towerFloor||1},{id:"quest_summon_1",nameKey:"quest.summon_1.name",descKey:"quest.summon_1.desc",targetCount:1,reward:{crystals:100,essence:30},getProgress:r=>r.stats?.totalSummons||0},{id:"quest_heroes_3",nameKey:"quest.heroes_3.name",descKey:"quest.heroes_3.desc",targetCount:3,reward:{essence:60,crystals:150},getProgress:r=>Object.keys(r.heroes||{}).length},{id:"quest_reach_stage_2_5",nameKey:"quest.reach_stage_2_5.name",descKey:"quest.reach_stage_2_5.desc",targetCount:15,reward:{crystals:300,essence:100},getProgress:r=>D(r.campaign?.highestStageReached)?.globalIndex||1},{id:"quest_defeat_boss_5",nameKey:"quest.defeat_boss_5.name",descKey:"quest.defeat_boss_5.desc",targetCount:5,reward:{crystals:600,essence:200},getProgress:r=>r.stats?.campaignBossesDefeated||0},{id:"quest_rank_b",nameKey:"quest.rank_b.name",descKey:"quest.rank_b.desc",targetCount:3,reward:{crystals:400,essence:150},getProgress:r=>r.rankIndex||0},{id:"quest_build_total_50",nameKey:"quest.build_50.name",descKey:"quest.build_50.desc",targetCount:50,reward:{goldSeconds:90,crystals:200,essence:100},getProgress:r=>Object.values(r.buildings||{}).reduce((e,t)=>e+(Number(t)||0),0)},{id:"quest_rank_s",nameKey:"quest.rank_s.name",descKey:"quest.rank_s.desc",targetCount:5,reward:{crystals:800,essence:300},getProgress:r=>r.rankIndex||0},{id:"quest_reincarnate_1",nameKey:"quest.reincarnate_1.name",descKey:"quest.reincarnate_1.desc",targetCount:1,reward:{crystals:1e3,essence:500,souls:5},getProgress:r=>r.reincarnationCount||0}],se=class se{constructor(){p(this,"ctx",null);p(this,"masterGain",null);p(this,"sfxGain",null);p(this,"musicGain",null);p(this,"isBgmPlaying",!1);p(this,"bgmIntervalId",null);p(this,"currentBgmTheme","world_1");p(this,"activeVoicesCount",0);p(this,"MAX_CONCURRENT_VOICES",8);p(this,"lastSoundTimes",{});const e=()=>{this.initContext(),this.ctx&&this.ctx.state==="suspended"&&this.ctx.resume(),typeof window<"u"&&(window.removeEventListener("pointerdown",e),window.removeEventListener("keydown",e),window.removeEventListener("touchstart",e))};typeof window<"u"&&(window.addEventListener("pointerdown",e),window.addEventListener("keydown",e),window.addEventListener("touchstart",e),document.addEventListener("visibilitychange",()=>{document.hidden?this.ctx&&this.ctx.state==="running"&&this.ctx.suspend():this.ctx&&this.ctx.state==="suspended"&&d.get().settings.soundEnabled&&this.ctx.resume()}))}static getInstance(){return se.instance||(se.instance=new se),se.instance}initContext(){if(!(typeof window>"u")&&!this.ctx){const e=window.AudioContext||window.webkitAudioContext;e&&(this.ctx=new e,this.masterGain=this.ctx.createGain(),this.sfxGain=this.ctx.createGain(),this.musicGain=this.ctx.createGain(),this.sfxGain.connect(this.masterGain),this.musicGain.connect(this.masterGain),this.masterGain.connect(this.ctx.destination),this.updateVolumes())}}updateVolumes(){if(typeof window>"u")return;const e=d.get().settings;this.sfxGain&&this.ctx&&this.sfxGain.gain.setValueAtTime(e.soundEnabled?e.soundVolume:0,this.ctx.currentTime),this.musicGain&&this.ctx&&this.musicGain.gain.setValueAtTime(e.musicEnabled?e.musicVolume*.35:0,this.ctx.currentTime)}checkCooldown(e,t){const s=Date.now(),a=this.lastSoundTimes[e]||0;return s-a<t?!1:(this.lastSoundTimes[e]=s,!0)}createSafeVoice(e,t,s,a,i){if(this.initContext(),!(!this.ctx||!this.sfxGain||!d.get().settings.soundEnabled)&&!(this.activeVoicesCount>=this.MAX_CONCURRENT_VOICES))try{this.activeVoicesCount++;const n=this.ctx.createOscillator(),o=this.ctx.createGain(),l=this.ctx.currentTime;n.type=e,n.frequency.setValueAtTime(t,l),i&&n.frequency.exponentialRampToValueAtTime(Math.max(10,i),l+s),o.gain.setValueAtTime(a,l),o.gain.exponentialRampToValueAtTime(1e-4,l+s),n.connect(o),o.connect(this.sfxGain),n.start(l),n.stop(l+s),n.onended=()=>{this.activeVoicesCount=Math.max(0,this.activeVoicesCount-1)}}catch{this.activeVoicesCount=Math.max(0,this.activeVoicesCount-1)}}playSlash(){this.checkCooldown("slash",70)&&this.createSafeVoice("sawtooth",180,.09,.2,40)}playHeavySlash(){this.checkCooldown("heavy_slash",120)&&this.createSafeVoice("sawtooth",120,.16,.35,30)}playEnemyHit(){this.checkCooldown("hit",140)&&this.createSafeVoice("triangle",220,.08,.25,60)}playEnemyDeath(){this.checkCooldown("death",100)&&this.createSafeVoice("square",150,.18,.3,30)}playCrit(){this.checkCooldown("crit",90)&&this.createSafeVoice("triangle",600,.15,.45,1200)}playCoin(){this.checkCooldown("coin",60)&&this.createSafeVoice("sine",987.77,.08,.18,1318.51)}playClick(){this.checkCooldown("click",50)&&this.createSafeVoice("sine",440,.06,.25,120)}playTap(){this.checkCooldown("tap",50)&&this.createSafeVoice("triangle",800,.05,.1,100)}playBuy(){this.playUpgrade()}playUpgrade(){if(!this.checkCooldown("upgrade",120))return;[523.25,659.25,783.99,1046.5].forEach((t,s)=>{setTimeout(()=>{this.createSafeVoice("sine",t,.12,.2)},s*45)})}playAscension(){[[261.63,329.63,392],[349.23,440,523.25],[392,493.88,587.33],[523.25,659.25,783.99,1046.5]].forEach((t,s)=>{setTimeout(()=>{t.forEach(a=>this.createSafeVoice("sawtooth",a,.35,.1))},s*160)})}playSummon(){this.createSafeVoice("sine",220,.6,.3,880)}playVictory(){[440,554.37,659.25,880].forEach((t,s)=>{setTimeout(()=>{this.createSafeVoice("triangle",t,.22,.22)},s*75)})}playDefeat(){[400,350,300,220].forEach((t,s)=>{setTimeout(()=>{this.createSafeVoice("sawtooth",t,.25,.2)},s*90)})}playBossWarning(){this.createSafeVoice("square",110,.65,.35,55)}playClaim(){[659.25,880,1046.5].forEach((t,s)=>{setTimeout(()=>{this.createSafeVoice("sine",t,.18,.18)},s*70)})}playReincarnation(){[220,330,440,660,880,1320].forEach((t,s)=>{setTimeout(()=>{this.createSafeVoice("sine",t,.5,.25)},s*100)})}setWorldTheme(e){this.currentBgmTheme===e&&this.isBgmPlaying||(this.currentBgmTheme=e,this.isBgmPlaying&&(this.stopAmbientBgm(),this.startAmbientBgm(e)))}startAmbientBgm(e=this.currentBgmTheme){if(this.isBgmPlaying&&this.stopAmbientBgm(),this.initContext(),!this.ctx||!this.musicGain)return;this.isBgmPlaying=!0,this.currentBgmTheme=e;let t,s=4e3;switch(e){case"boss":t=[[73.42,110,146.83],[65.41,98,130.81],[55,82.41,110],[82.41,123.47,164.81]],s=2400;break;case"world_2":t=[[146.83,220,261.63],[164.81,246.94,293.66],[130.81,196,220],[110,164.81,196]],s=3800;break;case"world_3":t=[[87.31,130.81,174.61],[98,146.83,196],[73.42,110,146.83],[65.41,98,130.81]],s=3500;break;case"world_4":t=[[220,329.63,440],[246.94,370,493.88],[196,293.66,392],[164.81,246.94,329.63]],s=4200;break;case"world_5":t=[[65.41,130.81,196],[55,110,164.81],[73.42,146.83,220],[49,98,146.83]],s=4500;break;case"world_1":default:t=[[130.81,196,261.63],[146.83,220,293.66],[110,164.81,220],[174.61,261.63,349.23]],s=4e3;break}let a=0;const i=()=>{if(!this.isBgmPlaying||!this.ctx||!this.musicGain||!d.get().settings.musicEnabled)return;const n=t[a];a=(a+1)%t.length,n.forEach(o=>{try{const l=this.ctx.createOscillator(),c=this.ctx.createGain(),m=this.ctx.createBiquadFilter();l.type=e==="boss"?"sawtooth":"sine",l.frequency.setValueAtTime(o,this.ctx.currentTime),m.type="lowpass",m.frequency.setValueAtTime(e==="boss"?800:500,this.ctx.currentTime);const g=s/1e3;c.gain.setValueAtTime(.001,this.ctx.currentTime),c.gain.linearRampToValueAtTime(.06,this.ctx.currentTime+g*.35),c.gain.linearRampToValueAtTime(.001,this.ctx.currentTime+g),l.connect(m),m.connect(c),c.connect(this.musicGain),l.start(),l.stop(this.ctx.currentTime+g)}catch{}})};i(),this.bgmIntervalId=window.setInterval(i,s)}stopAmbientBgm(){this.isBgmPlaying=!1,this.bgmIntervalId!==null&&(clearInterval(this.bgmIntervalId),this.bgmIntervalId=null)}};p(se,"instance");let Be=se;const _=Be.getInstance(),ht=Object.freeze(Object.defineProperty({__proto__:null,SoundService:Be,sound:_},Symbol.toStringTag,{value:"Module"}));class Ne{static checkAchievements(){const e=d.get(),t=new Set(e.claimedAchievements);for(const s of Ke)!t.has(s.id)&&s.check(e)&&(d.set(a=>{a.claimedAchievements.push(s.id),a.crystals+=s.rewardCrystals}),_.playVictory(),f.emit("achievement:unlocked",{achievementId:s.id,title:s.nameKey,rewardCrystals:s.rewardCrystals}),f.emit("toast:show",{message:`Achievement: ${s.rewardCrystals} 💎`,type:"gold"}))}static isQuestReadyToClaim(e){const t=d.get(),s=xe.find(a=>a.id===e);return!s||t.completedQuests.includes(e)?!1:s.getProgress(t)>=s.targetCount}static claimQuest(e){const t=d.get(),s=xe.find(y=>y.id===e);if(!s||t.completedQuests.includes(e)||s.getProgress(t)<s.targetCount)return!1;const i=I.calculateMetrics(t),o=1+(t.soulSkills.soul_quest||0)*.15;let l=s.reward.gold?Math.floor(s.reward.gold*o):0;if(s.reward.goldSeconds){const y=Math.max(50,Math.floor(i.passiveGoldPerSec*s.reward.goldSeconds*o));l+=y}let c=0;if(s.reward.powerSeconds){const y=Math.max(100,Math.floor(i.passivePowerPerSec*s.reward.powerSeconds*o));c+=y}const m=s.reward.crystals?Math.floor(s.reward.crystals*o):0,g=s.reward.essence?Math.floor(s.reward.essence*o):0,h=s.reward.souls||0;return d.set(y=>{y.completedQuests.push(e),l>0&&(y.gold+=l,y.stats.lifetimeGold+=l),c>0&&(y.power+=c,y.stats.lifetimePower+=c),m>0&&(y.crystals+=m),g>0&&(y.essence+=g),h>0&&(y.souls+=h)}),_.playUpgrade(),f.emit("quest:completed",{questId:e,reward:{gold:l,crystals:m,essence:g,souls:h}}),!0}}const ms="modulepreload",ps=function(r,e){return new URL(r,e).href},ft={},ye=function(e,t,s){let a=Promise.resolve();if(t&&t.length>0){const n=document.getElementsByTagName("link"),o=document.querySelector("meta[property=csp-nonce]"),l=o?.nonce||o?.getAttribute("nonce");a=Promise.allSettled(t.map(c=>{if(c=ps(c,s),c in ft)return;ft[c]=!0;const m=c.endsWith(".css"),g=m?'[rel="stylesheet"]':"";if(!!s)for(let v=n.length-1;v>=0;v--){const w=n[v];if(w.href===c&&(!m||w.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${c}"]${g}`))return;const y=document.createElement("link");if(y.rel=m?"stylesheet":ms,m||(y.as="script"),y.crossOrigin="",y.href=c,l&&y.setAttribute("nonce",l),document.head.appendChild(y),m)return new Promise((v,w)=>{y.addEventListener("load",v),y.addEventListener("error",()=>w(new Error(`Unable to preload CSS for ${c}`)))})}))}function i(n){const o=new Event("vite:preloadError",{cancelable:!0});if(o.payload=n,window.dispatchEvent(o),!o.defaultPrevented)throw n}return a.then(n=>{for(const o of n||[])o.status==="rejected"&&i(o.reason);return e().catch(i)})},Ve=[{worldIndex:1,minFloor:1,maxFloor:50,nameKey:"world.forest.name",bgGradient:"radial-gradient(ellipse at bottom, #064e3b 0%, #022c22 70%, #030712 100%)",accentColor:"#10b981",ambientParticles:"leaves",monsterTypes:[{nameKey:"monster.goblin",icon:"👺",descriptionKey:"monster.goblin.desc"},{nameKey:"monster.shadow_wolf",icon:"🐺",descriptionKey:"monster.shadow_wolf.desc"},{nameKey:"monster.treant",icon:"🪵",descriptionKey:"monster.treant.desc"}],bosses:[{nameKey:"boss.forest_king",icon:"🧌",descriptionKey:"boss.forest_king.desc"}]},{worldIndex:2,minFloor:51,maxFloor:100,nameKey:"world.sakura.name",bgGradient:"radial-gradient(ellipse at bottom, #831843 0%, #4c0519 70%, #030712 100%)",accentColor:"#f43f5e",ambientParticles:"petals",monsterTypes:[{nameKey:"monster.ronin",icon:"⚔️",descriptionKey:"monster.ronin.desc"},{nameKey:"monster.kitsune",icon:"🦊",descriptionKey:"monster.kitsune.desc"},{nameKey:"monster.monk",icon:"📿",descriptionKey:"monster.monk.desc"}],bosses:[{nameKey:"boss.shogun",icon:"👹",descriptionKey:"boss.shogun.desc"}]},{worldIndex:3,minFloor:101,maxFloor:150,nameKey:"world.abyss.name",bgGradient:"radial-gradient(ellipse at bottom, #7f1d1d 0%, #450a0a 70%, #030712 100%)",accentColor:"#ef4444",ambientParticles:"embers",monsterTypes:[{nameKey:"monster.hellhound",icon:"🐕‍🦺",descriptionKey:"monster.hellhound.desc"},{nameKey:"monster.fire_demon",icon:"👿",descriptionKey:"monster.fire_demon.desc"},{nameKey:"monster.lava_golem",icon:"🌋",descriptionKey:"monster.lava_golem.desc"}],bosses:[{nameKey:"boss.dragon",icon:"🐉",descriptionKey:"boss.dragon.desc"}]},{worldIndex:4,minFloor:151,maxFloor:200,nameKey:"world.frozen.name",bgGradient:"radial-gradient(ellipse at bottom, #0c4a6e 0%, #082f49 70%, #030712 100%)",accentColor:"#38bdf8",ambientParticles:"snow",monsterTypes:[{nameKey:"monster.frost_golem",icon:"🧊",descriptionKey:"monster.frost_golem.desc"},{nameKey:"monster.ice_specter",icon:"👻",descriptionKey:"monster.ice_specter.desc"},{nameKey:"monster.blizzard_hawk",icon:"🦅",descriptionKey:"monster.blizzard_hawk.desc"}],bosses:[{nameKey:"boss.frost_monarch",icon:"❄️",descriptionKey:"boss.frost_monarch.desc"}]},{worldIndex:5,minFloor:201,maxFloor:1/0,nameKey:"world.void.name",bgGradient:"radial-gradient(ellipse at bottom, #4c1d95 0%, #2e1065 70%, #030712 100%)",accentColor:"#a855f7",ambientParticles:"void-stars",monsterTypes:[{nameKey:"monster.void_phantom",icon:"👤",descriptionKey:"monster.void_phantom.desc"},{nameKey:"monster.astral_knight",icon:"🛡️",descriptionKey:"monster.astral_knight.desc"},{nameKey:"monster.chaos_orb",icon:"🔮",descriptionKey:"monster.chaos_orb.desc"}],bosses:[{nameKey:"boss.cosmic_sovereign",icon:"👁️",descriptionKey:"boss.cosmic_sovereign.desc"}]}];function Ye(r){return Ve.find(e=>r>=e.minFloor&&r<=e.maxFloor)||Ve[Ve.length-1]}function gs(r){return r>0&&r%10===0}function yt(r){const e=gs(r),t=Ye(r),s=120*Math.pow(1.105,r-1),a=Math.floor(s*(e?4:1)),i=20*Math.pow(1.095,r-1),n=Math.floor(i*(e?2.5:1));let o,l;if(e){const c=t.bosses[Math.floor(r/10-1)%t.bosses.length];o=c.nameKey,l=c.icon}else{const c=t.monsterTypes[(r-1)%t.monsterTypes.length];o=c.nameKey,l=c.icon}return{maxHp:a,power:n,isBoss:e,nameKey:o,icon:l}}const Xe=[{id:"phantom_finger",nameKey:"relic_phantom_finger",descriptionKey:"relic_phantom_finger_desc",maxLevel:5,icon:"☝️",modifier:{type:"auto_training",baseValue:1,growthPerLevel:1}},{id:"wings_of_haste",nameKey:"relic_wings_of_haste",descriptionKey:"relic_wings_of_haste_desc",maxLevel:5,icon:"🪽",modifier:{type:"tower_skip",baseValue:.1,growthPerLevel:.05}},{id:"spirit_lantern",nameKey:"relic_spirit_lantern",descriptionKey:"relic_spirit_lantern_desc",maxLevel:3,icon:"🏮",modifier:{type:"spirit_lure",baseValue:1.5,growthPerLevel:.5}},{id:"karmic_hourglass",nameKey:"relic_karmic_hourglass",descriptionKey:"relic_karmic_hourglass_desc",maxLevel:10,icon:"⏳",modifier:{type:"reincarnation_boost",baseValue:.05,growthPerLevel:.01}},{id:"dragon_scale",nameKey:"relic_dragon_scale",descriptionKey:"relic_dragon_scale_desc",maxLevel:5,icon:"🐉",modifier:{type:"crit_burst",baseValue:.01,growthPerLevel:.01}},{id:"harmonic_chime",nameKey:"relic_harmonic_chime",descriptionKey:"relic_harmonic_chime_desc",maxLevel:5,icon:"🎐",modifier:{type:"synergy_amp",baseValue:1.1,growthPerLevel:.1}},{id:"merchants_abacus",nameKey:"relic_merchants_abacus",descriptionKey:"relic_merchants_abacus_desc",maxLevel:3,icon:"🧮",modifier:{type:"quest_gold",baseValue:.25,growthPerLevel:.15}},{id:"ethereal_hammer",nameKey:"relic_ethereal_hammer",descriptionKey:"relic_ethereal_hammer_desc",maxLevel:3,icon:"🔨",modifier:{type:"offline_forge",baseValue:.01,growthPerLevel:.01}}];function Ae(r){return Xe.find(e=>e.id===r)}function hs(r,e){const t=Ae(r);if(!t)return 0;const s=Math.max(1,Math.min(e,t.maxLevel));return t.modifier.baseValue+(s-1)*t.modifier.growthPerLevel}class de{static getEquippedEffectValue(e,t){let s=0;for(const a of e.equippedRelics){if(!a)continue;const i=Ae(a);if(i&&i.modifier.type===t){const n=e.relics[a];n&&(s+=hs(a,n.level))}}return s}static grantRelic(e){const t=Ae(e);t&&(d.set(s=>{s.relics||(s.relics={});const a=s.relics[e];if(a){a.duplicates+=1;const i=a.level*2;a.duplicates>=i&&a.level<t.maxLevel?(a.duplicates-=i,a.level+=1,f.emit("toast:show",{message:`Relic Level Up: ${e} (Lv.${a.level})`,type:"success"})):f.emit("toast:show",{message:`Duplicate Relic: ${e}`,type:"info"})}else s.relics[e]={level:1,duplicates:0},f.emit("toast:show",{message:`New Relic Found: ${e}!`,type:"success"})}),f.emit("relic:grant",{relicId:e}))}static equipRelic(e,t){d.set(s=>{if(t<0||t>=s.equippedRelics.length||!s.relics[e])return;const a=s.equippedRelics.indexOf(e);a!==-1&&(s.equippedRelics[a]=null),s.equippedRelics[t]=e})}static unequipRelic(e){d.set(t=>{e>=0&&e<t.equippedRelics.length&&(t.equippedRelics[e]=null)})}}const fs=Object.freeze(Object.defineProperty({__proto__:null,RelicSystem:de},Symbol.toStringTag,{value:"Module"})),ae=class ae{constructor(){p(this,"combatState");const e=d.get().towerFloor||1,t=yt(e);this.combatState={currentFloor:e,enemyNameKey:t.nameKey,enemyIcon:t.icon,isBoss:t.isBoss,enemyMaxHp:t.maxHp,enemyCurrentHp:t.maxHp,battleTimer:12,maxBattleTimer:12,lastAttackTimer:0,isAutoClimbing:!0,isFarmMode:!1}}static getInstance(){return ae.instance||(ae.instance=new ae),ae.instance}getCombatState(){return this.combatState}toggleAutoClimb(){this.combatState.isAutoClimbing=!this.combatState.isAutoClimbing}toggleFarmMode(){this.combatState.isFarmMode=!this.combatState.isFarmMode}slash(){const e=d.get();if(e.rankIndex<2)return 0;const t=I.calculateMetrics(e),s=Math.max(t.towerCombatPower*.2,5);return this.combatState.enemyCurrentHp=Math.max(0,this.combatState.enemyCurrentHp-s),this.combatState.enemyCurrentHp<=0&&this.handleFloorVictory(),s}resetToFloor(e){const t=yt(e);this.combatState.currentFloor=e,this.combatState.enemyNameKey=t.nameKey,this.combatState.enemyIcon=t.icon,this.combatState.isBoss=t.isBoss,this.combatState.enemyMaxHp=t.maxHp,this.combatState.enemyCurrentHp=t.maxHp,this.combatState.battleTimer=12}update(e){if(!this.combatState.isAutoClimbing||d.get().rankIndex<2)return;const t=d.get(),i=I.calculateMetrics(t).towerCombatPower*e;this.combatState.enemyCurrentHp=Math.max(0,this.combatState.enemyCurrentHp-i),this.combatState.battleTimer-=e,this.combatState.enemyCurrentHp<=0?this.handleFloorVictory():this.combatState.battleTimer<=0&&this.handleFloorDefeat()}handleFloorVictory(){const e=this.combatState.currentFloor,t=this.combatState.isBoss,s=e%5===0,i=1+(d.get().soulSkills.soul_tower||0)*.2;let n=Math.floor(50*Math.pow(1.09,e)*(t?4:1)*i),o=Math.floor((t?25:5)*i),l=Math.floor((t?15:2)*i);if(s&&(o+=Math.floor(25*i),l+=Math.floor(10*i),f.emit("tower:milestoneClaimed",{floor:e,rewards:{crystals:25,essence:10}})),d.set(g=>{g.gold+=n,g.crystals+=o,g.essence+=l,g.stats.lifetimeGold+=n,this.combatState.isFarmMode||(g.towerFloor=e+1),e+1>g.towerMaxFloor&&(g.towerMaxFloor=e+1)}),_.playVictory(),f.emit("tower:floorClear",{floor:e,rewards:{gold:n,crystals:o,essence:l}}),t){if(f.emit("tower:bossDefeat",{floor:e,bossName:this.combatState.enemyNameKey}),Math.random()<.2){const g=Xe[Math.floor(Math.random()*Xe.length)];de.grantRelic(g.id)}ye(async()=>{const{platform:g}=await Promise.resolve().then(()=>ss);return{platform:g}},void 0,import.meta.url).then(({platform:g})=>{g.setLeaderboardScore("max_tower_floor",e)})}if(this.combatState.isFarmMode){this.resetToFloor(e);return}let c=e+1;const m=de.getEquippedEffectValue(d.get(),"tower_skip");m>0&&Math.random()<m&&(f.emit("toast:show",{message:`Relic Triggered: Skipped Floor ${c}!`,type:"info"}),c+=1),this.resetToFloor(c)}handleFloorDefeat(){f.emit("tower:loss",{floor:this.combatState.currentFloor}),this.resetToFloor(this.combatState.currentFloor)}};p(ae,"instance");let Ze=ae;const U=Ze.getInstance();class $t{static train(e){const a=(d.get().combo||{count:0}).count+1,i=1+Math.min(1,a*.05);d.set(m=>{m.combo.count=a,m.combo.multiplier=i,m.combo.timer=2});const n=I.calculateMetrics(d.get()),o=Math.random()<n.critChance,l=Math.floor(o?n.clickPower*n.critMultiplier:n.clickPower),c=Math.floor(o?n.clickGold*2:n.clickGold);return d.set(m=>{m.power+=l,m.gold+=c,m.stats.lifetimePower+=l,m.stats.lifetimeGold+=c,m.stats.totalClicks+=1,o&&(m.stats.totalCrits+=1)}),o?_.playCrit():_.playClick(),f.emit("train:click",{powerGained:l,goldGained:c,isCrit:o,x:e?.x,y:e?.y}),{powerGained:l,goldGained:c,isCrit:o,comboMult:i}}static updateCombo(e){const t=d.get();if(t.combo&&t.combo.timer>0){const s=t.combo.timer-e;s<=0?d.set(a=>{a.combo.count=0,a.combo.multiplier=1,a.combo.timer=0}):d.set(a=>{a.combo.timer=s})}}}const bt={forest_goblin:{id:"forest_goblin",nameKey:"enemy_forest_goblin",defaultName:"Forest Goblin",archetype:"melee",baseHpMultiplier:.9,rewardMultiplier:1,spriteId:"enemy_goblin"},dire_wolf:{id:"dire_wolf",nameKey:"enemy_dire_wolf",defaultName:"Dire Wolf",archetype:"melee",baseHpMultiplier:1,rewardMultiplier:1.1,spriteId:"enemy_wolf"},corrupted_treant:{id:"corrupted_treant",nameKey:"enemy_corrupted_treant",defaultName:"Corrupted Treant",archetype:"tank",baseHpMultiplier:1.3,rewardMultiplier:1.3,spriteId:"enemy_treant"},forest_spirit:{id:"forest_spirit",nameKey:"enemy_forest_spirit",defaultName:"Wandering Sprite",archetype:"magic",baseHpMultiplier:.85,rewardMultiplier:1.2,spriteId:"enemy_sprite"},forest_alpha:{id:"forest_alpha",nameKey:"enemy_forest_alpha",defaultName:"Ancient Alpha Wolf",archetype:"elite",baseHpMultiplier:1.8,rewardMultiplier:2,spriteId:"enemy_alpha_wolf"},rogue_ninja:{id:"rogue_ninja",nameKey:"enemy_rogue_ninja",defaultName:"Rogue Ninja",archetype:"ranged",baseHpMultiplier:.95,rewardMultiplier:1,spriteId:"enemy_ninja"},bamboo_ronin:{id:"bamboo_ronin",nameKey:"enemy_bamboo_ronin",defaultName:"Bamboo Ronin",archetype:"melee",baseHpMultiplier:1.1,rewardMultiplier:1.15,spriteId:"enemy_ronin"},temple_guardian:{id:"temple_guardian",nameKey:"enemy_temple_guardian",defaultName:"Stone Lion Guardian",archetype:"tank",baseHpMultiplier:1.4,rewardMultiplier:1.35,spriteId:"enemy_stone_lion"},kitsune_shade:{id:"kitsune_shade",nameKey:"enemy_kitsune_shade",defaultName:"Kitsune Shade",archetype:"magic",baseHpMultiplier:1,rewardMultiplier:1.25,spriteId:"enemy_kitsune"},corrupted_samurai:{id:"corrupted_samurai",nameKey:"enemy_corrupted_samurai",defaultName:"Corrupted Samurai Lord",archetype:"elite",baseHpMultiplier:2,rewardMultiplier:2.2,spriteId:"enemy_corrupted_samurai"},flame_imp:{id:"flame_imp",nameKey:"enemy_flame_imp",defaultName:"Flame Imp",archetype:"ranged",baseHpMultiplier:.9,rewardMultiplier:1.05,spriteId:"enemy_imp"},magma_beast:{id:"magma_beast",nameKey:"enemy_magma_beast",defaultName:"Magma Hound",archetype:"melee",baseHpMultiplier:1.15,rewardMultiplier:1.2,spriteId:"enemy_magma_hound"},obsidian_golem:{id:"obsidian_golem",nameKey:"enemy_obsidian_golem",defaultName:"Obsidian Golem",archetype:"tank",baseHpMultiplier:1.5,rewardMultiplier:1.4,spriteId:"enemy_obsidian_golem"},infernal_sorcerer:{id:"infernal_sorcerer",nameKey:"enemy_infernal_sorcerer",defaultName:"Infernal Pyromancer",archetype:"magic",baseHpMultiplier:1.05,rewardMultiplier:1.3,spriteId:"enemy_pyromancer"},abyss_executioner:{id:"abyss_executioner",nameKey:"enemy_abyss_executioner",defaultName:"Abyssal Executioner",archetype:"elite",baseHpMultiplier:2.2,rewardMultiplier:2.5,spriteId:"enemy_executioner"},frost_wolf:{id:"frost_wolf",nameKey:"enemy_frost_wolf",defaultName:"Frostfang Wolf",archetype:"melee",baseHpMultiplier:1,rewardMultiplier:1.1,spriteId:"enemy_frost_wolf"},ice_archer:{id:"ice_archer",nameKey:"enemy_ice_archer",defaultName:"Glacier Hunter",archetype:"ranged",baseHpMultiplier:.95,rewardMultiplier:1.15,spriteId:"enemy_ice_archer"},glacier_elemental:{id:"glacier_elemental",nameKey:"enemy_glacier_elemental",defaultName:"Glacier Titan",archetype:"tank",baseHpMultiplier:1.55,rewardMultiplier:1.45,spriteId:"enemy_ice_titan"},blizzard_specter:{id:"blizzard_specter",nameKey:"enemy_blizzard_specter",defaultName:"Blizzard Specter",archetype:"magic",baseHpMultiplier:1.1,rewardMultiplier:1.35,spriteId:"enemy_specter"},frost_wyrm:{id:"frost_wyrm",nameKey:"enemy_frost_wyrm",defaultName:"Frost Wyrmling",archetype:"elite",baseHpMultiplier:2.3,rewardMultiplier:2.6,spriteId:"enemy_frost_wyrm"},void_crawler:{id:"void_crawler",nameKey:"enemy_void_crawler",defaultName:"Void Scuttler",archetype:"melee",baseHpMultiplier:1.05,rewardMultiplier:1.15,spriteId:"enemy_void_crawler"},cosmic_ray:{id:"cosmic_ray",nameKey:"enemy_cosmic_ray",defaultName:"Dimensional Weaver",archetype:"ranged",baseHpMultiplier:1,rewardMultiplier:1.25,spriteId:"enemy_dimensional_weaver"},astral_colossus:{id:"astral_colossus",nameKey:"enemy_astral_colossus",defaultName:"Astral Colossus",archetype:"tank",baseHpMultiplier:1.6,rewardMultiplier:1.5,spriteId:"enemy_astral_colossus"},singularity_cultist:{id:"singularity_cultist",nameKey:"enemy_singularity_cultist",defaultName:"Void Prophet",archetype:"magic",baseHpMultiplier:1.15,rewardMultiplier:1.4,spriteId:"enemy_void_prophet"},void_harbinger:{id:"void_harbinger",nameKey:"enemy_void_harbinger",defaultName:"Harbinger of Nothingness",archetype:"elite",baseHpMultiplier:2.5,rewardMultiplier:3,spriteId:"enemy_void_harbinger"}};function Bt(r){return bt[r]||bt.forest_goblin}class R{static ensureCampaignState(e){e.campaign||(e.campaign={currentWorldId:1,currentStageId:"1-1",currentEncounter:1,highestWorldReached:1,highestStageReached:"1-1",firstClears:[],campaignMode:"progress",autoAdvance:!0,farmStageId:"1-1",bossRetryState:null})}static getCurrentStage(e){this.ensureCampaignState(e);const t=D(e.campaign.currentStageId);return t||(e.campaign.currentStageId="1-1",e.campaign.currentWorldId=1,D("1-1"))}static isFirstClear(e,t){return this.ensureCampaignState(e),!e.campaign.firstClears.includes(t)}static getCampaignRewardBreakdown(e){return this.ensureCampaignState(e),{totalGold:e.stats.campaignGoldEarned||0,totalPower:e.stats.campaignPowerEarned||0,totalCrystals:e.stats.campaignCrystalsEarned||0,bossesDefeated:e.stats.campaignBossesDefeated||0,firstClearsCount:e.campaign.firstClears.length}}static onEnemyDefeated(e,t,s){this.ensureCampaignState(e);const a=this.getCurrentStage(e),i=a.id,n=this.isFirstClear(e,i);let o;const l=t?Bt(t):null,c=l?.rewardMultiplier||1;n?(o={...a.firstClearRewards},e.campaign.firstClears.push(i)):s||a.isBoss?o={...a.baseRewards}:o={gold:Math.max(1,Math.floor(a.baseRewards.gold*c)),power:Math.max(1,Math.floor(a.baseRewards.power*c))},e.gold+=o.gold||0,e.power+=o.power||0,o.crystals&&(e.crystals+=o.crystals),o.essence&&(e.essence+=o.essence),o.souls&&(e.souls+=o.souls),e.stats.lifetimeGold+=o.gold||0,e.stats.lifetimePower+=o.power||0,e.stats.campaignGoldEarned=(e.stats.campaignGoldEarned||0)+(o.gold||0),e.stats.campaignPowerEarned=(e.stats.campaignPowerEarned||0)+(o.power||0),e.stats.campaignEnemiesDefeated=(e.stats.campaignEnemiesDefeated||0)+1,l?.archetype==="elite"&&(e.stats.campaignElitesDefeated=(e.stats.campaignElitesDefeated||0)+1),o.crystals&&(e.stats.campaignCrystalsEarned=(e.stats.campaignCrystalsEarned||0)+o.crystals),(s||a.isBoss)&&(e.stats.campaignBossesDefeated=(e.stats.campaignBossesDefeated||0)+1);let m=!1,g=!1,h,y;if(e.campaign.currentEncounter>=a.enemyCount){m=!0,e.stats.campaignStagesCleared=(e.stats.campaignStagesCleared||0)+1,e.campaign.currentEncounter=1;const v=D(e.campaign.highestStageReached);(!v||a.globalIndex>v.globalIndex)&&(e.campaign.highestStageReached=a.id,e.campaign.highestWorldReached=Math.max(e.campaign.highestWorldReached,a.worldId));const w=Me(a.worldId);if(w&&a.stageNumber===w.stageCount&&(g=!0,e.stats.campaignWorldsCleared=(e.stats.campaignWorldsCleared||0)+1),e.campaign.campaignMode==="progress"&&e.campaign.autoAdvance)if(h=gt(i),h){const S=D(h);S&&(e.campaign.currentStageId=h,e.campaign.currentWorldId=S.worldId,e.campaign.highestWorldReached=Math.max(e.campaign.highestWorldReached,S.worldId),y=S.worldId,e.campaign.farmStageId=i)}else e.campaign.campaignMode="farm",e.campaign.farmStageId=i;else e.campaign.campaignMode==="farm"&&(e.campaign.currentEncounter=1)}else e.campaign.currentEncounter++;return f.emit("campaign:enemy_defeated",{stageId:i,rewards:o,isFirstClear:n,stageCleared:m,worldCleared:g}),m&&f.emit("campaign:stage_cleared",{stageId:i,isFirstClear:n,nextStageId:h}),g&&f.emit("campaign:world_cleared",{worldId:a.worldId}),{rewards:o,isFirstClear:n,encounterFinished:!0,stageCleared:m,worldCleared:g,nextStageId:h,nextWorldId:y}}static onBossFailed(e){this.ensureCampaignState(e);const t=this.getCurrentStage(e);e.campaign.campaignMode="boss_blocked",e.campaign.bossRetryState={bossId:t.bossId||`boss_${t.id}`,failedAt:Date.now(),retryBoostActive:!1};const s=e.campaign.farmStageId||us(t.id)||"1-1";e.campaign.currentStageId=s,e.campaign.currentEncounter=1,f.emit("campaign:boss_failed",{bossId:e.campaign.bossRetryState.bossId,failedStageId:t.id,fallbackStageId:s})}static retryBoss(e,t=!1){if(this.ensureCampaignState(e),!e.campaign.bossRetryState||!D(e.campaign.highestStageReached))return!1;const a=gt(e.campaign.farmStageId)||e.campaign.highestStageReached,i=D(a);return!i||!i.isBoss?!1:(e.campaign.currentStageId=i.id,e.campaign.currentWorldId=i.worldId,e.campaign.currentEncounter=1,e.campaign.campaignMode="progress",e.campaign.bossRetryState&&(e.campaign.bossRetryState.retryBoostActive=t),f.emit("campaign:boss_retry",{stageId:i.id,retryBoostActive:t}),!0)}static setCampaignMode(e,t){this.ensureCampaignState(e),e.campaign.campaignMode=t,t==="farm"&&(e.campaign.currentEncounter=1),f.emit("campaign:mode_changed",{mode:t})}static toggleAutoAdvance(e){return this.ensureCampaignState(e),e.campaign.autoAdvance=!e.campaign.autoAdvance,f.emit("campaign:auto_advance_toggled",{autoAdvance:e.campaign.autoAdvance}),e.campaign.autoAdvance}static checkSamsaraRush(e,t){this.ensureCampaignState(e);const s=this.getCurrentStage(e),a=t>=s.baseHp*15&&e.reincarnationCount>0;return a&&e.campaign.campaignMode!=="rush"?(e.campaign.campaignMode="rush",f.emit("campaign:rush_started",{stageId:s.id})):!a&&e.campaign.campaignMode==="rush"&&(e.campaign.campaignMode="progress",f.emit("campaign:rush_ended",{stageId:s.id})),a}static onReincarnationReset(e){this.ensureCampaignState(e),e.campaign.currentWorldId=1,e.campaign.currentStageId="1-1",e.campaign.currentEncounter=1,e.campaign.campaignMode="rush",e.campaign.farmStageId="1-1",e.campaign.bossRetryState=null}}class Y{static summon(e,t=!1){const s=e===1?100:900,a=d.get();if(!t&&a.crystals<s)return null;d.set(n=>{t||(n.crystals-=s),n.stats.totalSummons+=e});const i=[];for(let n=0;n<e;n++){const o=this.rollRarity(),l=he.filter(g=>g.rarity===o),c=l[Math.floor(Math.random()*l.length)];if(!!!d.get().heroes[c.id])d.set(g=>{g.heroes[c.id]={stars:1,duplicates:0}}),i.push({hero:c,isNew:!0}),f.emit("hero:unlocked",{heroId:c.id,rarity:c.rarity,isNew:!0});else{const h=1+(d.get().soulSkills.soul_essence||0)*.3,y=K[c.rarity].duplicateEssence,v=Math.floor(y*h);d.set(w=>{w.essence+=v,w.heroes[c.id]&&(w.heroes[c.id].duplicates+=1)}),i.push({hero:c,isNew:!1,essenceGranted:v})}}return _.playSummon(),i}static upgradeHeroStars(e){const t=d.get(),s=t.heroes[e],a=ve(e);if(!s||!a||s.stars>=5)return!1;const i=At(s.stars,a.rarity);return t.essence<i?!1:(d.set(n=>{n.essence-=i,n.heroes[e]&&(n.heroes[e].stars+=1)}),_.playUpgrade(),f.emit("hero:starUp",{heroId:e,newStars:s.stars+1}),!0)}static rollRarity(){const e=Math.random()*100;let t=0;const s=["mythic","legendary","epic","rare","common"];for(const a of s)if(t+=K[a].pullRate,e<=t)return a;return"common"}static getActiveParty(e=3){const t=d.get(),s={mythic:5,legendary:4,epic:3,rare:2,common:1},a=[];for(const[i,n]of Object.entries(t.heroes)){const o=ve(i);o&&n.stars>0&&a.push({hero:o,stars:n.stars,duplicates:n.duplicates})}return a.sort((i,n)=>{const o=s[i.hero.rarity]||0,l=s[n.hero.rarity]||0;return l!==o?l-o:n.stars-i.stars}),a.slice(0,e)}static getPartySynergy(){const t=this.getActiveParty(3).length,s=1+t*.05;return{partyCount:t,synergyMultiplier:s,synergyPctText:`+${Math.round(t*5)}%`}}}const ie=class ie{constructor(){p(this,"combatState");p(this,"isResolvingDeath",!1);p(this,"deathTransitionTimer",0);p(this,"deathTransitionDuration",.3);p(this,"autoAttackTimer",0);p(this,"autoAttackCadence",.35);p(this,"isSpawning",!1);p(this,"heroSkillTimers",{});const e=d.get();R.ensureCampaignState(e);const t=R.getCurrentStage(e);this.combatState={stageId:t.id,worldId:t.worldId,encounterIndex:e.campaign.currentEncounter||1,totalEncounters:t.enemyCount,activeEnemy:null,encounterTimer:0,maxEncounterTimer:0,isTimerActive:!1,isPaused:!1,autoAttackEnabled:!0},this.spawnCurrentEncounter(e)}static getInstance(){return ie.instance||(ie.instance=new ie),ie.instance}getCombatState(){return this.combatState}setPaused(e){this.combatState.isPaused=e}setAutoAttackEnabled(e){this.combatState.autoAttackEnabled=e}toggleAutoAttack(){return this.combatState.autoAttackEnabled=!this.combatState.autoAttackEnabled,this.combatState.autoAttackEnabled}spawnCurrentEncounter(e){if(!this.isSpawning){this.isSpawning=!0;try{const t=e||d.get();R.ensureCampaignState(t);const s=R.getCurrentStage(t),a=t.campaign.currentEncounter||1;if(this.combatState.stageId=s.id,this.combatState.worldId=s.worldId,this.combatState.encounterIndex=a,this.combatState.totalEncounters=s.enemyCount,this.isResolvingDeath=!1,this.deathTransitionTimer=0,s.isBoss&&s.bossId){const i=qt(s.bossId);if(i){const n=Math.max(10,Math.floor(s.baseHp*i.baseHpMultiplier));this.combatState.activeEnemy={id:i.id,nameKey:i.nameKey,defaultName:i.defaultName,isBoss:!0,bossTitleKey:i.titleKey,defaultBossTitle:i.defaultTitle,maxHp:n,currentHp:n,archetype:"boss",spriteId:i.spriteId,specialMechanic:i.specialMechanic},this.combatState.isTimerActive=!0,this.combatState.maxEncounterTimer=i.timerSeconds||45,this.combatState.encounterTimer=this.combatState.maxEncounterTimer,f.emit("combat:boss_warning",{bossName:i.defaultName,stageId:s.id})}}else{const i=(a-1)%s.enemyPool.length,n=s.enemyPool[i]||s.enemyPool[0]||"forest_goblin",o=Bt(n),l=Math.max(10,Math.floor(s.baseHp*o.baseHpMultiplier));this.combatState.activeEnemy={id:o.id,nameKey:o.nameKey,defaultName:o.defaultName,isBoss:!1,maxHp:l,currentHp:l,archetype:o.archetype,spriteId:o.spriteId},this.combatState.isTimerActive=!1,this.combatState.encounterTimer=0,this.combatState.maxEncounterTimer=0}f.emit("combat:enemy_spawned",{enemy:this.combatState.activeEnemy,stageId:s.id,encounterIndex:a})}finally{this.isSpawning=!1}}}applyDamageToEnemy(e){const t=this.combatState.activeEnemy;if(!t||t.currentHp<=0)return{appliedHpDamage:0,appliedShieldDamage:0};let s=e;t.isDamageReductionActive&&(s=Math.max(1,Math.floor(s*.5)));let a=0;t.shieldHp&&t.shieldHp>0&&(a=Math.min(t.shieldHp,s),t.shieldHp-=a,s-=a);const i=Math.min(t.currentHp,s);return t.currentHp=Math.max(0,t.currentHp-i),t.isBoss&&t.specialMechanic&&(t.specialMechanic==="shield"&&t.currentHp<=t.maxHp*.5&&!t.maxShieldHp?(t.maxShieldHp=Math.max(10,Math.floor(t.maxHp*.25)),t.shieldHp=t.maxShieldHp,f.emit("combat:boss_mechanic",{bossId:t.id,mechanic:"shield",active:!0})):t.specialMechanic==="enrage"&&t.currentHp<=t.maxHp*.35&&!t.isEnraged?(t.isEnraged=!0,f.emit("combat:boss_mechanic",{bossId:t.id,mechanic:"enrage",active:!0})):t.specialMechanic==="damage_reduction"&&t.currentHp<=t.maxHp*.6&&!t.isDamageReductionActive&&!t.damageReductionUsed&&(t.isDamageReductionActive=!0,t.damageReductionTimer=3,t.damageReductionUsed=!0,f.emit("combat:boss_mechanic",{bossId:t.id,mechanic:"damage_reduction",active:!0}))),{appliedHpDamage:i,appliedShieldDamage:a}}attack(e,t){if(this.combatState.isPaused)return{damage:0,isCrit:!1,powerGained:0,goldGained:0,enemyDied:!1,remainingHp:this.combatState.activeEnemy?.currentHp||0};const s=e!==void 0&&t!==void 0?{x:e,y:t}:void 0,a=$t.train(s),i=d.get();if(!this.combatState.activeEnemy||this.isResolvingDeath)return{damage:0,isCrit:a.isCrit,powerGained:a.powerGained,goldGained:a.goldGained,enemyDied:!1,remainingHp:this.combatState.activeEnemy?.currentHp||0};let n=Math.max(a.powerGained,5);i.campaign.bossRetryState?.retryBoostActive&&this.combatState.activeEnemy.isBoss&&(n=Math.floor(n*1.25));const o=this.combatState.activeEnemy;this.applyDamageToEnemy(n),f.emit("combat:player_attack",{damage:n,isCrit:a.isCrit,remainingHp:o.currentHp,enemyId:o.id,x:e,y:t});let l=!1;return o.currentHp<=0&&!this.isResolvingDeath&&(l=!0,this.handleEnemyDefeat()),{damage:n,isCrit:a.isCrit,powerGained:a.powerGained,goldGained:a.goldGained,enemyDied:l,remainingHp:o.currentHp}}calculateAutoDps(e){const t=e||d.get(),s=I.calculateMetrics(t);let a=Math.max(s.passivePowerPerSec,10);return t.campaign?.bossRetryState?.retryBoostActive&&this.combatState.activeEnemy?.isBoss&&(a=Math.floor(a*1.25)),a}update(e){if(this.combatState.isPaused)return;const t=Math.max(0,e);if(this.isResolvingDeath){this.deathTransitionTimer>0&&(this.deathTransitionTimer-=t,this.deathTransitionTimer<=0&&(this.isResolvingDeath=!1,this.spawnCurrentEncounter()));return}if(!this.combatState.activeEnemy){this.spawnCurrentEncounter();return}if(this.combatState.activeEnemy?.isDamageReductionActive&&this.combatState.activeEnemy.damageReductionTimer&&(this.combatState.activeEnemy.damageReductionTimer-=t,this.combatState.activeEnemy.damageReductionTimer<=0&&(this.combatState.activeEnemy.isDamageReductionActive=!1,f.emit("combat:boss_mechanic",{bossId:this.combatState.activeEnemy.id,mechanic:"damage_reduction",active:!1}))),this.combatState.isTimerActive&&(this.combatState.encounterTimer-=t,this.combatState.encounterTimer<=0)){this.handleBossTimeout();return}if(this.combatState.activeEnemy&&this.combatState.activeEnemy.currentHp>0&&!this.isResolvingDeath&&this.updateHeroSkills(t),this.combatState.autoAttackEnabled&&this.combatState.activeEnemy&&this.combatState.activeEnemy.currentHp>0){const s=d.get(),a=this.calculateAutoDps(s);R.checkSamsaraRush(s,a);const i=this.combatState.activeEnemy;if(s.campaign?.campaignMode==="rush"&&a>=i.maxHp*3){i.currentHp=0,this.deathTransitionTimer=.05,f.emit("combat:samsara_rush_kill",{enemyId:i.id,stageId:this.combatState.stageId}),this.handleEnemyDefeat();return}const n=a*t;if(this.applyDamageToEnemy(n),this.autoAttackTimer+=t,this.autoAttackTimer>=this.autoAttackCadence){this.autoAttackTimer-=this.autoAttackCadence;const o=Math.max(1,Math.floor(a*this.autoAttackCadence));f.emit("combat:auto_attack",{damage:o,isCrit:!1,remainingHp:i.currentHp,enemyId:i.id})}i.currentHp<=0&&!this.isResolvingDeath&&this.handleEnemyDefeat()}}updateHeroSkills(e){const t=Y.getActiveParty(3);if(!(!this.combatState.activeEnemy||t.length===0))for(const a of t){const i=a.hero,n=i.skill;n&&(this.heroSkillTimers[i.id]=(this.heroSkillTimers[i.id]||0)+e,this.heroSkillTimers[i.id]>=n.cooldownSeconds&&(this.heroSkillTimers[i.id]=0,this.executeHeroSkill(i,a.stars)))}}executeHeroSkill(e,t){const s=this.combatState.activeEnemy;if(!s||s.currentHp<=0||this.isResolvingDeath)return;const a=e.skill,i=at(t),n=d.get(),o=I.calculateMetrics(n),l=this.calculateAutoDps(n);let c=0,m=0,g=0;switch(a.type){case"direct_damage":{c=Math.max(10,Math.floor(l*a.multiplier*i*.4)),this.applyDamageToEnemy(c);break}case"gold_burst":{m=Math.max(5,Math.floor((o.passiveGoldPerSec||10)*a.multiplier*i*2)),d.set(h=>{h.gold+=m});break}case"power_burst":{g=Math.max(5,Math.floor((o.passivePowerPerSec||10)*a.multiplier*i*2)),d.set(h=>{h.power+=g});break}case"crit_mark":{c=Math.max(10,Math.floor(l*a.multiplier*i*.6)),this.applyDamageToEnemy(c);break}}f.emit("combat:hero_skill",{heroId:e.id,heroName:e.nameKey,skillName:a.nameKey,skillIcon:a.icon,type:a.type,damage:c,gold:m,power:g,remainingHp:s.currentHp}),s.currentHp<=0&&!this.isResolvingDeath&&this.handleEnemyDefeat()}handleEnemyDefeat(e=!1){if(this.isResolvingDeath)return;this.isResolvingDeath=!0;const t=this.combatState.activeEnemy;t&&(t.currentHp=0),_.playEnemyHit(),d.set(s=>{const a=R.onEnemyDefeated(s,t?.id,t?.isBoss);f.emit("combat:reward_dropped",{rewards:a.rewards}),f.emit("combat:enemy_killed",{enemyId:t?.id||"unknown",rewards:a.rewards,stageCleared:a.stageCleared,worldCleared:a.worldCleared})}),e?(this.isResolvingDeath=!1,this.spawnCurrentEncounter()):this.deathTransitionTimer=this.deathTransitionDuration}handleBossTimeout(){this.isResolvingDeath||(this.isResolvingDeath=!0,_.playDefeat(),d.set(e=>{R.onBossFailed(e)}),this.deathTransitionTimer=this.deathTransitionDuration)}resetToStage(e){d.set(t=>{const s=D(e);s&&(t.campaign.currentStageId=s.id,t.campaign.currentWorldId=s.worldId,t.campaign.currentEncounter=1)}),this.isResolvingDeath=!1,this.deathTransitionTimer=0,this.spawnCurrentEncounter()}};p(ie,"instance");let Je=ie;const H=Je.getInstance(),He=class He{static update(e=Date.now()){const t=d.get();t.randomEvent.active&&e>=t.randomEvent.expiresAt&&(d.set(s=>{s.randomEvent.active=!1}),this.scheduleNext(e)),!t.randomEvent.active&&e>=this.nextSpawnTime&&this.spawnEvent(void 0,e)}static spawnEvent(e,t=Date.now()){const s=e||(Math.random()<.6?"instant_power":"frenzy"),a=15+Math.random()*70,i=25+Math.random()*50;d.set(n=>{n.randomEvent={active:!0,type:s,expiresAt:t+15e3,xPct:a,yPct:i}})}static claimEvent(){const e=d.get();if(!e.randomEvent.active)return null;const t=Date.now(),s=e.randomEvent.type,a=I.calculateMetrics(e,t);let i="";return d.set(n=>{if(n.randomEvent.active=!1,s==="instant_power"){const o=Math.max(250,Math.floor(a.passivePowerPerSec*60));n.power+=o,n.crystals+=25,n.stats.lifetimePower+=o,i=`+${o} Power & +25 Crystals!`}else n.buffs.frenzyEndsAt=t+3e4,i="CELESTIAL FRENZY! 3x Power for 30s!"}),_.playVictory(),f.emit("toast:show",{message:`✨ Golden Spirit: ${i}`,type:"gold"}),this.scheduleNext(t),{type:s,rewardDesc:i}}static scheduleNext(e){let t=(90+Math.random()*90)*1e3;ye(()=>Promise.resolve().then(()=>fs),void 0,import.meta.url).then(s=>{const a=s.RelicSystem.getEquippedEffectValue(d.get(),"spirit_lure"),i=a>0?a:1;He.nextSpawnTime=e+t/i}),this.nextSpawnTime=e+t}};p(He,"nextSpawnTime",Date.now()+6e4);let Te=He;class vt{static now(){return Date.now()}static getMidnight(e){const t=new Date(e);return t.setHours(0,0,0,0),t.getTime()}}const Pt=[{id:"daily_train_500",type:"train",descriptionKey:"quest.daily.train.500",target:500,rewardCrystals:50},{id:"daily_summon_1",type:"summon",descriptionKey:"quest.daily.summon.1",target:1,rewardCrystals:100},{id:"daily_tower_3",type:"tower",descriptionKey:"quest.daily.tower.3",target:3,rewardCrystals:75},{id:"daily_upgrade_10",type:"upgrade",descriptionKey:"quest.daily.upgrade.10",target:10,rewardCrystals:50}];function Pe(r){return Pt.find(e=>e.id===r)}class De{static checkDailyReset(){const e=d.get(),t=vt.now(),s=vt.getMidnight(t);if(e.lastDailyResetAt===0){d.set(a=>{a.lastDailyResetAt=s,a.loginStreak=1,a.loginRewardClaimed=!1}),this.generateDailyQuests();return}if(s>e.lastDailyResetAt){const a=Math.round((s-e.lastDailyResetAt)/864e5);d.set(i=>{a===1?i.loginStreak+=1:i.loginStreak=1,i.lastDailyResetAt=s,i.loginRewardClaimed=!1}),this.generateDailyQuests(),f.emit("toast:show",{message:"A new day has started! Daily quests reset.",type:"info"})}}static generateDailyQuests(){const t=[...Pt].sort(()=>.5-Math.random()).slice(0,3);d.set(s=>{s.dailyQuests=t.map(a=>({id:Math.random().toString(36).substr(2,9),templateId:a.id,progress:0,claimed:!1}))})}static claimLoginReward(){const e=d.get();if(e.loginRewardClaimed)return!1;let t=50+e.loginStreak%30*10;return e.loginStreak%30===7&&(t+=500),e.loginStreak%30===14&&(t+=1500),e.loginStreak%30===0&&(t+=5e3),d.set(s=>{s.loginRewardClaimed=!0,s.crystals+=t}),f.emit("toast:show",{message:`Daily Login Claimed! +${t} Crystals`,type:"success"}),!0}static trackQuestProgress(e,t=1){d.set(s=>{for(const a of s.dailyQuests){if(a.claimed)continue;const i=Pe(a.templateId);i&&i.type===e&&a.progress<i.target&&(a.progress+=t,a.progress>=i.target&&(a.progress=i.target,f.emit("toast:show",{message:"Daily Quest Complete!",type:"success"})))}})}static claimQuest(e){const s=d.get().dailyQuests.find(i=>i.id===e);if(!s||s.claimed)return!1;const a=Pe(s.templateId);return!a||s.progress<a.target?!1:(d.set(i=>{const n=i.dailyQuests.find(o=>o.id===e);n&&(n.claimed=!0,i.crystals+=a.rewardCrystals)}),f.emit("toast:show",{message:`Reward claimed: +${a.rewardCrystals} Crystals`,type:"success"}),!0)}}class x{static format(e,t="standard"){const s=typeof e=="number"?e:Number(e);if(isNaN(s)||!isFinite(s))return"0";if(s<0)return"-"+this.format(-s,t);if(s<1e3)return Number.isInteger(s)?s.toString():s>=10?s.toFixed(1):s.toFixed(2);if(t==="scientific")return s.toExponential(2).replace("e+","e");const a=Math.floor(Math.log10(s)/3);if(a<this.SUFFIXES.length){const i=this.SUFFIXES[a],n=Math.pow(10,a*3),o=s/n;return(o<10?o.toFixed(2):o<100?o.toFixed(1):o.toFixed(0)).replace(/\.00$/,"").replace(/(\.[1-9])0$/,"$1")+i}return s.toExponential(2).replace("e+","e")}static formatTime(e){const t=Math.max(0,Math.floor(e)),s=Math.floor(t/3600),a=Math.floor(t%3600/60),i=t%60,n=o=>o.toString().padStart(2,"0");return s>0?`${n(s)}:${n(a)}:${n(i)}`:`${n(a)}:${n(i)}`}}p(x,"SUFFIXES",["","K","M","B","T","Qa","Qi","Sx","Sp","Oc","No","Dc","UDc","DDc","TDc","QaDc","QiDc","SxDc","SpDc","OcDc","NoDc","Vg","UVg","DVg","TVg","QaVg","QiVg","SxVg","SpVg","OcVg","NoVg","Tg","UTg","DTg","TTg","QaTg","QiTg","SxTg","SpTg","OcTg","NoTg","Qd","UQd","DQd","TQd","QaQd","QiQd","SxQd","SpQd","OcQd","NoQd","Qq","UQq","DQq","TQq","QaQq","QiQq","SxQq","SpQq","OcQq","NoQq","Sg","USg","DSg","TSg","QaSg","QiSg","SxSg","SpSg","OcSg","NoSg","St","USt","DSt","TSt","QaSt","QiSt","SxSt","SpSt","OcSt","NoSt","Og","UOg","DOg","TOg","QaOg","QiOg","SxOg","SpOg","OcOg","NoOg","Nn","UNn","DNn","TNn","QaNn","QiNn","SxNn","SpNn","OcNn","NoNn","Ce","UCe","DCe","TCe","QaCe","QiCe","SxCe","SpCe","OcCe","NoCe"]);class ys{constructor(){p(this,"el");p(this,"lastGold",0);p(this,"lastCrystals",0);this.el=document.createElement("header"),this.el.className="app-header",this.render(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>this.update())}render(){this.el.innerHTML=`
      <div class="header-rank-badge" id="headerRankBadge" style="display:flex; align-items:center; gap:8px; cursor:pointer; min-width:0; flex-shrink:1;">
        <div class="rank-icon-frame" id="headerRankFrame" style="width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-weight:bold; font-size:16px; border:2px solid #94a3b8; background:rgba(15,23,42,0.8); flex-shrink:0;">
          E
        </div>
        <div style="display:flex; flex-direction:column; min-width:0; overflow:hidden;">
          <span id="headerRankTitle" style="font-size:11px; color:var(--text-muted); font-weight:bold; text-transform:uppercase; text-overflow:ellipsis; overflow:hidden; white-space:nowrap;">Novice</span>
          <span id="headerPowerDisplay" style="font-size:13px; color:var(--color-gold); font-weight:bold; white-space:nowrap;">0 ⚡</span>
        </div>
      </div>

      <div class="header-currencies" style="display:flex; align-items:center; gap:8px; flex-shrink:0;">
        <div class="currency-pill" style="display:flex; align-items:center; gap:4px; background:rgba(30,41,59,0.7); padding:4px 8px; border-radius:var(--radius-full); border:1px solid var(--border-subtle); white-space:nowrap;">
          <span style="font-size:13px;">🪙</span>
          <span id="headerGold" style="font-weight:bold; color:#fde047; font-size:12px;">0</span>
        </div>

        <div class="currency-pill" style="display:flex; align-items:center; gap:4px; background:rgba(30,41,59,0.7); padding:4px 8px; border-radius:var(--radius-full); border:1px solid var(--border-subtle); white-space:nowrap;">
          <span style="font-size:13px;">💎</span>
          <span id="headerCrystals" style="font-weight:bold; color:#38bdf8; font-size:12px;">0</span>
        </div>

        <button id="headerStatsBtn" title="Statistics & Production Breakdown" style="width:32px; height:32px; border-radius:var(--radius-md); background:rgba(30,41,59,0.7); border:1px solid var(--border-subtle); display:flex; align-items:center; justify-content:center; color:var(--text-main); font-size:14px; cursor:pointer; flex-shrink:0;">
          📊
        </button>

        <button id="headerSettingsBtn" title="Settings" style="width:32px; height:32px; border-radius:var(--radius-md); background:rgba(30,41,59,0.7); border:1px solid var(--border-subtle); display:flex; align-items:center; justify-content:center; color:var(--text-main); font-size:14px; cursor:pointer; flex-shrink:0;">
          ⚙️
        </button>
      </div>
    `,this.el.querySelector("#headerStatsBtn")?.addEventListener("click",()=>{f.emit("modal:open",{modalId:"stats"})}),this.el.querySelector("#headerSettingsBtn")?.addEventListener("click",()=>{f.emit("modal:open",{modalId:"settings"})}),this.el.querySelector("#headerRankBadge")?.addEventListener("click",()=>{f.emit("screen:change",{screenId:"ascension"})})}update(){const e=d.get(),t=O(e.rankId),s=this.el.querySelector("#headerRankFrame"),a=this.el.querySelector("#headerRankTitle"),i=this.el.querySelector("#headerPowerDisplay"),n=this.el.querySelector("#headerGold"),o=this.el.querySelector("#headerCrystals");s&&(s.innerText=t.id,s.style.borderColor=t.color,s.style.color=t.color,s.style.boxShadow=`0 0 10px ${t.color}40`),a&&(a.innerText=u(t.nameKey)),i&&(i.innerText=`${x.format(e.power,e.settings?.notation)} ⚡`),n&&(n.innerText=x.format(e.gold,e.settings?.notation),e.gold>this.lastGold+100&&(n.parentElement.style.transform="scale(1.15)",n.parentElement.style.borderColor="var(--color-gold)",n.parentElement.style.transition="all 0.15s ease",setTimeout(()=>{n.parentElement.style.transform="",n.parentElement.style.borderColor="var(--border-subtle)"},150)),this.lastGold=e.gold),o&&(o.innerText=x.format(e.crystals,e.settings?.notation),e.crystals>this.lastCrystals&&(o.parentElement.style.transform="scale(1.2)",o.parentElement.style.borderColor="var(--color-cyan)",o.parentElement.style.transition="all 0.15s ease",setTimeout(()=>{o.parentElement.style.transform="",o.parentElement.style.borderColor="var(--border-subtle)"},150)),this.lastCrystals=e.crystals)}}class Dt{static canAscend(){const e=d.get(),t=le(e.rankId);return t?e.power>=t.reqPower:!1}static getNextRank(){return le(d.get().rankId)}static ascend(){const e=d.get(),t=le(e.rankId);if(!t||e.power<t.reqPower)return!1;const s=e.rankId;return d.set(a=>{a.rankId=t.id,a.rankIndex=t.index}),_.playAscension(),f.emit("ascension:rankUp",{oldRank:s,newRank:t.id,multiplier:t.multiplier}),f.emit("modal:open",{modalId:"ascension",data:{rank:t}}),!0}}const bs=[{id:"ascension",icon:"🥋",labelKey:"nav.hero",minRankIndex:0},{id:"home",icon:"🏯",labelKey:"nav.sect",minRankIndex:0},{id:"battle",icon:"⚔️",labelKey:"nav.battle",minRankIndex:0},{id:"heroes",icon:"👥",labelKey:"nav.heroes",minRankIndex:0},{id:"more",icon:"✨",labelKey:"nav.more",minRankIndex:0}];class vs{constructor(){p(this,"el");p(this,"currentScreen","home");p(this,"badgeCheckInterval");p(this,"lastRankIndex",-1);this.el=document.createElement("nav"),this.el.className="app-bottom-nav",this.render(),this.bind(),this.badgeCheckInterval=window.setInterval(()=>this.updateBadges(),1e3)}getElement(){return this.el}destroy(){this.badgeCheckInterval&&clearInterval(this.badgeCheckInterval)}bind(){f.on("screen:change",({screenId:e})=>{this.currentScreen=e,this.updateActiveState()}),d.subscribe(()=>{this.updateVisibility(),this.updateBadges()}),document.addEventListener("i18n:change",()=>{this.lastRankIndex=-1,this.render()})}render(){const e=d.get();this.lastRankIndex=e.rankIndex,this.el.innerHTML="",bs.forEach(t=>{if(!(e.rankIndex>=t.minRankIndex))return;const a=t.id==="battle",i=document.createElement("button");i.className=`nav-tab-btn ${a?"nav-tab-battle":""}`,i.id=`navBtn_${t.id}`,i.style.position="relative",a&&(i.style.background="linear-gradient(135deg, rgba(239, 68, 68, 0.25), rgba(245, 158, 11, 0.35))",i.style.border="1px solid rgba(245, 158, 11, 0.5)",i.style.borderRadius="var(--radius-md)",i.style.boxShadow="0 0 12px rgba(245, 158, 11, 0.3)"),i.innerHTML=`
        <span class="nav-icon" style="${a?"font-size: 22px; filter: drop-shadow(0 0 6px #f59e0b);":""}">${t.icon}</span>
        <span class="nav-label" style="${a?"color: #fde047; font-weight: 900;":""}">${u(t.labelKey)}</span>
        <div class="nav-badge" style="display:none; position:absolute; top:3px; right:10px; width:10px; height:10px; background:var(--color-crimson, #ef4444); border-radius:50%; box-shadow:0 0 8px #ef4444;"></div>
      `,i.addEventListener("click",n=>{n.preventDefault(),_.playTap(),t.id==="more"?f.emit("modal:open",{modalId:"more_menu"}):f.emit("screen:change",{screenId:t.id})}),this.el.appendChild(i)}),this.updateActiveState(),this.updateBadges()}updateBadges(){const e=d.get(),t=Date.now(),s=this.el.querySelector("#navBtn_ascension");if(s){const n=s.querySelector(".nav-badge");if(n){const o=Dt.canAscend();n.style.display=o?"block":"none"}}const a=this.el.querySelector("#navBtn_heroes");if(a){const n=a.querySelector(".nav-badge");if(n){const o=t-(e.lastFreeSummonAdAt||0)>=3e5;n.style.display=o?"block":"none"}}const i=this.el.querySelector("#navBtn_more");if(i){const n=i.querySelector(".nav-badge");if(n){const o=xe.some(m=>Ne.isQuestReadyToClaim(m.id)),l=!e.loginRewardClaimed||e.dailyQuests.some(m=>{if(m.claimed)return!1;const g=Pe(m.templateId);return g&&m.progress>=g.target}),c=e.expeditions.some(m=>t>=m.startedAt+m.durationMs);n.style.display=o||l||c?"block":"none"}}}updateActiveState(){this.el.querySelectorAll(".nav-tab-btn").forEach(s=>{s.classList.remove("active")});let e=this.currentScreen;this.currentScreen==="home"||this.currentScreen==="battle"?e="battle":this.currentScreen==="summon"?e="heroes":["quests","tower","expeditions","relics","souls","dailies"].includes(this.currentScreen)&&(e="more");const t=this.el.querySelector(`#navBtn_${e}`);t&&t.classList.add("active")}updateVisibility(){d.get().rankIndex!==this.lastRankIndex&&this.render()}}const re=class re{constructor(){p(this,"container",null);p(this,"registeredModals",new Map);p(this,"activeModalId",null);this.bindKeyboard()}static getInstance(){return re.instance||(re.instance=new re),re.instance}init(e){this.container=e,f.on("modal:open",({modalId:t,data:s})=>{this.open(t,s)}),f.on("modal:close",({modalId:t})=>{this.close(t)})}register(e){this.registeredModals.set(e.id,e)}open(e,t){if(!this.container)return;const s=this.registeredModals.get(e);if(!s)return;this.activeModalId=e,this.container.innerHTML="",this.container.style.display="flex";const a=document.createElement("div");a.className="modal-backdrop",a.style.cssText=`
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background: rgba(4, 7, 17, 0.85);
      backdrop-filter: blur(8px);
      -webkit-backdrop-filter: blur(8px);
      z-index: 100;
    `,a.addEventListener("click",()=>this.close(e));const i=document.createElement("div");i.className="modal-content-animated",i.style.cssText=`
      position: relative;
      z-index: 101;
      max-width: 480px;
      width: 90%;
      max-height: 85vh;
      overflow-y: auto;
      background: #0a0f1d;
      border: 1px solid var(--border-gold);
      box-shadow: 0 10px 40px rgba(0,0,0,0.8), 0 0 30px rgba(245,158,11,0.2);
      border-radius: var(--radius-lg);
      padding: 24px;
    `;const n=s.render(t);i.appendChild(n),this.container.appendChild(a),this.container.appendChild(i)}close(e){if(this.container&&!(e&&this.activeModalId!==e)){if(this.activeModalId){const t=this.registeredModals.get(this.activeModalId);t?.onClose&&t.onClose()}this.container.innerHTML="",this.container.style.display="none",this.activeModalId=null}}bindKeyboard(){typeof window<"u"&&window.addEventListener("keydown",e=>{e.key==="Escape"&&this.activeModalId&&this.close(this.activeModalId)})}};p(re,"instance");let et=re;const C=et.getInstance();class Lt{static init(e){this.container=e,f.on("toast:show",({message:t,type:s})=>{this.show(t,s)})}static show(e,t="info"){if(!this.container)return;const s=document.createElement("div");s.className="app-toast";let a="#94a3b8",i="rgba(148, 163, 184, 0.3)";t==="gold"?(a="#f59e0b",i="rgba(245, 158, 11, 0.4)"):t==="epic"?(a="#c084fc",i="rgba(192, 132, 252, 0.5)"):t==="success"&&(a="#10b981",i="rgba(16, 185, 129, 0.4)"),s.style.cssText=`
      background: rgba(15, 23, 42, 0.95);
      backdrop-filter: blur(12px);
      border: 1px solid ${a};
      box-shadow: 0 4px 20px ${i};
      color: #ffffff;
      padding: 10px 18px;
      border-radius: var(--radius-md);
      font-size: 13px;
      font-weight: 600;
      margin-bottom: 8px;
      animation: modalPop 0.25s cubic-bezier(0.16, 1, 0.3, 1) forwards;
      pointer-events: auto;
      display: flex;
      align-items: center;
      gap: 8px;
      max-width: 320px;
    `,s.innerHTML=e,this.container.appendChild(s),setTimeout(()=>{s.style.opacity="0",s.style.transform="translateY(-10px)",s.style.transition="all 0.3s ease",setTimeout(()=>{s.parentNode&&s.parentNode.removeChild(s)},300)},2800)}}p(Lt,"container",null);const Ce={offline_reward_2x:{id:"offline_reward_2x",nameKey:"ad.offline.title",defaultName:"Double Offline Gains",cooldownSeconds:0,description:"Doubles offline meditation power and gold rewards."},boss_retry_boost:{id:"boss_retry_boost",nameKey:"ad.boss_boost.title",defaultName:"Boss Combat Surge",cooldownSeconds:0,description:"Grants +25% combat damage when retrying a blocked boss fight."},bonus_boss_chest:{id:"bonus_boss_chest",nameKey:"ad.boss_chest.title",defaultName:"Bonus Boss Treasure",cooldownSeconds:600,description:"Doubles gold and crystal drops from defeating a campaign boss."},temporary_battle_surge:{id:"temporary_battle_surge",nameKey:"ad.battle_surge.title",defaultName:"Battle Power Surge",cooldownSeconds:900,description:"Grants 2x total combat power for 3 minutes."},free_hero_summon:{id:"free_hero_summon",nameKey:"ad.free_summon.title",defaultName:"Free Hero Summon",cooldownSeconds:14400,description:"Grants 1 free Hero Gacha summon pull."}},ne=class ne{constructor(){p(this,"lastFullscreenTime",0);p(this,"FULLSCREEN_COOLDOWN_MS",9e4);p(this,"lastPlacementWatchTimes",new Map)}static getInstance(){return ne.instance||(ne.instance=new ne),ne.instance}isSafeForInterstitial(){return!0}async showFullscreenAdIfReady(e){if(Date.now()-this.lastFullscreenTime<this.FULLSCREEN_COOLDOWN_MS||!this.isSafeForInterstitial())return!1;try{const s=await V.showFullscreenAd();return s&&(this.lastFullscreenTime=Date.now()),s}catch(s){return console.warn("[AdService] Error showing fullscreen ad:",s),!1}}canWatchRewardedPlacement(e){const t=Ce[e];if(!t||t.cooldownSeconds===0)return!0;const s=this.lastPlacementWatchTimes.get(e)||0;return(Date.now()-s)/1e3>=t.cooldownSeconds}getPlacementCooldownRemaining(e){const t=Ce[e];if(!t||t.cooldownSeconds===0)return 0;const s=this.lastPlacementWatchTimes.get(e)||0,a=(Date.now()-s)/1e3;return Math.max(0,Math.ceil(t.cooldownSeconds-a))}async showRewardedAd(e){const t=e;if(Ce[t]&&!this.canWatchRewardedPlacement(t))return console.warn(`[AdService] Rewarded placement "${e}" is on cooldown.`),!1;try{return await V.showRewardedAd(e)?(Ce[t]&&this.lastPlacementWatchTimes.set(t,Date.now()),f.emit("ad:rewarded_completed",{placement:e}),!0):(f.emit("ad:rewarded_failed",{placement:e}),!1)}catch(s){return console.warn(`[AdService] Error in rewarded ad for "${e}":`,s),f.emit("ad:rewarded_failed",{placement:e,error:String(s)}),!1}}resetCooldowns(){this.lastFullscreenTime=0,this.lastPlacementWatchTimes.clear()}};p(ne,"instance");let Le=ne;const we=Le.getInstance(),xs=Object.freeze(Object.defineProperty({__proto__:null,AdService:Le,REWARDED_PLACEMENTS:Ce,adService:we},Symbol.toStringTag,{value:"Module"}));class ws{constructor(){p(this,"el");p(this,"isExpanded",!1);p(this,"fps",60);p(this,"lastFpsUpdate",performance.now());p(this,"frames",0);this.el=document.createElement("div"),this.el.id="devOverlay",this.el.style.cssText=`
      position: fixed;
      bottom: 74px;
      right: 12px;
      z-index: 999;
      font-family: monospace;
      font-size: 11px;
    `,this.render(),this.bind()}getElement(){return this.el}updateFps(){this.frames++;const e=performance.now();if(e-this.lastFpsUpdate>=1e3){this.fps=this.frames,this.frames=0,this.lastFpsUpdate=e;const t=this.el.querySelector("#devFps");t&&(t.textContent=`${this.fps} FPS`)}}bind(){d.subscribe(()=>{this.isExpanded&&this.updateTelemetry()})}render(){this.el.innerHTML=`
      <button id="devToggleBtn" style="background:#ef4444; color:#fff; font-weight:bold; padding:4px 8px; border-radius:var(--radius-sm); border:1px solid #fff; cursor:pointer; opacity:0.85;">
        🛠️ BALANCE DEV (<span id="devFps">60 FPS</span>)
      </button>

      <div id="devPanel" style="display:none; margin-top:6px; background:rgba(15,23,42,0.96); border:1px solid #ef4444; border-radius:var(--radius-md); padding:10px; color:#fff; width:300px; max-height:480px; overflow-y:auto; box-shadow:0 8px 30px rgba(0,0,0,0.8);">
        <div style="font-weight:bold; color:#ef4444; margin-bottom:6px; border-bottom:1px solid #333; padding-bottom:3px; display:flex; justify-content:space-between;">
          <span>⚡ LIVE BALANCE TELEMETRY</span>
        </div>

        <div id="devTelemetry" style="font-size:10px; color:#94a3b8; margin-bottom:8px; line-height:1.4; background:rgba(0,0,0,0.4); padding:6px; border-radius:4px;">
          <!-- Populated in updateTelemetry -->
        </div>

        <div style="font-weight:bold; color:#fde047; margin-bottom:4px; font-size:10px;">⏩ TIME SKIP / FAST FORWARD</div>
        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:4px; margin-bottom:8px;">
          <button id="devSkip1m" style="background:#1e293b; color:#38bdf8; border:1px solid #334155; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+1 Min</button>
          <button id="devSkip5m" style="background:#1e293b; color:#38bdf8; border:1px solid #334155; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+5 Min</button>
          <button id="devSkip15m" style="background:#1e293b; color:#38bdf8; border:1px solid #334155; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+15 Min</button>
          <button id="devSkip1h" style="background:#1e293b; color:#38bdf8; border:1px solid #334155; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+1 Hour</button>
          <button id="devSkip8h" style="background:#7c3aed; color:#fff; border:1px solid #a855f7; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+8h Offline</button>
          <button id="devTestAd" style="background:#059669; color:#fff; border:1px solid #10b981; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">Test Ad</button>
        </div>

        <div style="font-weight:bold; color:#ef4444; margin-bottom:4px; font-size:10px;">🛠️ CHEATS</div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:4px;">
          <button id="devAddGold" style="background:#334155; color:#fde047; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+10K Gold</button>
          <button id="devAddPower" style="background:#334155; color:#38bdf8; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+50K Power</button>
          <button id="devAddCrystals" style="background:#334155; color:#c084fc; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+500 Crystals</button>
          <button id="devAddSouls" style="background:#334155; color:#f43f5e; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+20 Souls</button>
          <button id="devAddEssence" style="background:#334155; color:#10b981; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">+200 Essence</button>
          <button id="devAscendRank" style="background:#d97706; color:#fff; padding:3px; border-radius:3px; font-size:10px; cursor:pointer;">Force Next Rank</button>
          <button id="devSpawnSpirit" style="background:#f59e0b; color:#000; font-weight:bold; padding:3px; border-radius:3px; font-size:10px; cursor:pointer; grid-column:span 2;">✨ Spawn Spirit</button>
        </div>
      </div>
    `;const e=this.el.querySelector("#devToggleBtn"),t=this.el.querySelector("#devPanel");e?.addEventListener("click",()=>{this.isExpanded=!this.isExpanded,t.style.display=this.isExpanded?"block":"none",this.isExpanded&&this.updateTelemetry()}),this.el.querySelector("#devSkip1m")?.addEventListener("click",()=>this.fastForward(60)),this.el.querySelector("#devSkip5m")?.addEventListener("click",()=>this.fastForward(300)),this.el.querySelector("#devSkip15m")?.addEventListener("click",()=>this.fastForward(900)),this.el.querySelector("#devSkip1h")?.addEventListener("click",()=>this.fastForward(3600)),this.el.querySelector("#devAddGold")?.addEventListener("click",()=>{d.set(s=>{s.gold+=1e4,s.stats.lifetimeGold+=1e4})}),this.el.querySelector("#devAddPower")?.addEventListener("click",()=>{d.set(s=>{s.power+=5e4,s.stats.lifetimePower+=5e4})}),this.el.querySelector("#devAddCrystals")?.addEventListener("click",()=>{d.set(s=>{s.crystals+=500})}),this.el.querySelector("#devAddSouls")?.addEventListener("click",()=>{d.set(s=>{s.souls+=20})}),this.el.querySelector("#devAddEssence")?.addEventListener("click",()=>{d.set(s=>{s.essence+=200})}),this.el.querySelector("#devAscendRank")?.addEventListener("click",()=>{const s=le(d.get().rankId);s&&d.set(a=>{a.rankId=s.id,a.rankIndex=s.index,a.power=Math.max(a.power,s.reqPower)})}),this.el.querySelector("#devSpawnSpirit")?.addEventListener("click",()=>{Te.spawnEvent("instant_power")}),this.el.querySelector("#devSkip8h")?.addEventListener("click",()=>{const s=d.get(),a=s.lastSeenAt+8*3600*1e3,i=It.calculateOfflineGains(s,a);i&&f.emit("modal:open",{modalId:"offline_reward",data:{gains:i}})}),this.el.querySelector("#devTestAd")?.addEventListener("click",()=>{we.showRewardedAd("dev_test")})}fastForward(e){const t=d.get(),s=I.calculateMetrics(t),a=Math.floor(s.passivePowerPerSec*e),i=Math.floor(s.passiveGoldPerSec*e);d.set(n=>{n.power+=a,n.gold+=i,n.stats.lifetimePower+=a,n.stats.lifetimeGold+=i,n.stats.playtimeSeconds+=e})}updateTelemetry(){const e=d.get(),t=I.calculateMetrics(e),s=O(e.rankId),a=le(e.rankId);let i="MAX";if(a){const c=Math.max(0,a.reqPower-e.power);if(t.passivePowerPerSec>0){const m=Math.ceil(c/t.passivePowerPerSec);i=m<60?`${m}s`:m<3600?`${Math.floor(m/60)}m ${m%60}s`:`${(m/3600).toFixed(1)}h`}else i="Manual click needed"}let n="None",o=1/0;for(const c of oe)if(e.rankIndex>=c.requiredRankIndex){const m=e.buildings[c.id]||0,g=G(c,m,1,t.buildingCostDiscount),h=Re(m),y=c.baseProduction*h*t.rankMultiplier*t.heroPowerMultiplier*t.soulPowerMultiplier,v=g/(y||1);v<o&&(o=v,n=`${c.nameKey} (ROI ${v.toFixed(1)}s)`)}const l=this.el.querySelector("#devTelemetry");l&&(l.innerHTML=`
        <div><strong>Power/s:</strong> ${x.format(t.passivePowerPerSec)} | <strong>Gold/s:</strong> ${x.format(t.passiveGoldPerSec)}</div>
        <div><strong>Click Power:</strong> ${x.format(t.clickPower)} | <strong>Click Gold:</strong> ${x.format(t.clickGold)}</div>
        <div><strong>Rank:</strong> ${s.id} (×${t.rankMultiplier.toFixed(2)}) | <strong>Next ETA:</strong> ${i}</div>
        <div><strong>Multipliers:</strong> Heroes ×${t.heroPowerMultiplier.toFixed(2)} | Souls ×${t.soulPowerMultiplier.toFixed(2)} | Upgrades ×${t.globalUpgradesMultiplier.toFixed(2)}</div>
        <div><strong>Next Best ROI:</strong> <span style="color:#10b981">${n}</span></div>
      `)}}class _s{constructor(e){p(this,"canvas");p(this,"ctx",null);p(this,"particles",[]);p(this,"pool",[]);p(this,"width",0);p(this,"height",0);p(this,"isHidden",!1);p(this,"MAX_ACTIVE_PARTICLES",120);p(this,"MAX_POOL_SIZE",150);for(this.canvas=e,this.ctx=e.getContext("2d"),this.resize(),typeof window<"u"&&(window.addEventListener("resize",()=>this.resize()),document.addEventListener("visibilitychange",()=>{this.isHidden=document.hidden,this.isHidden&&this.clear()}));this.pool.length<50;)this.pool.push({x:0,y:0,vx:0,vy:0,size:0,alpha:1,decay:.02,color:"",glow:!1})}resize(){const e=Math.min(typeof window<"u"&&window.devicePixelRatio||1,2);this.width=this.canvas.clientWidth||(typeof window<"u"?window.innerWidth:800),this.height=this.canvas.clientHeight||(typeof window<"u"?window.innerHeight:600),this.canvas.width=this.width*e,this.canvas.height=this.height*e,this.ctx&&this.ctx.scale(e,e)}emitBurst(e,t,s=16,a="#f59e0b",i=!1){if(this.isHidden)return;const n=i?Math.min(s*2,24):Math.min(s,16),o=this.MAX_ACTIVE_PARTICLES-this.particles.length;if(o<n){const c=n-o;for(let m=0;m<c;m++){const g=this.particles.shift();g&&this.pool.length<this.MAX_POOL_SIZE&&this.pool.push(g)}}const l=Math.min(n,Math.max(0,this.MAX_ACTIVE_PARTICLES-this.particles.length));for(let c=0;c<l;c++){const m=Math.random()*Math.PI*2,g=(i?4:2.5)*(.4+Math.random()*.8),h=this.pool.pop()||{x:0,y:0,vx:0,vy:0,size:0,alpha:1,decay:.02,color:"",glow:!1};h.x=e,h.y=t,h.vx=Math.cos(m)*g,h.vy=Math.sin(m)*g-(i?1.5:.5),h.size=(i?3.5:2.2)+Math.random()*2,h.alpha=1,h.decay=.025+Math.random()*.02,h.color=a,h.glow=i,this.particles.push(h)}}update(){if(!(!this.ctx||this.isHidden)){this.ctx.clearRect(0,0,this.width,this.height);for(let e=this.particles.length-1;e>=0;e--){const t=this.particles[e];if(t.x+=t.vx,t.y+=t.vy,t.alpha-=t.decay,t.alpha<=0){this.particles.splice(e,1),this.pool.length<this.MAX_POOL_SIZE&&this.pool.push(t);continue}this.ctx.save(),this.ctx.globalAlpha=Math.max(0,t.alpha),this.ctx.fillStyle=t.color,t.glow&&(this.ctx.shadowColor=t.color,this.ctx.shadowBlur=8),this.ctx.beginPath(),this.ctx.arc(t.x,t.y,t.size,0,Math.PI*2),this.ctx.fill(),this.ctx.restore()}}}clear(){for(;this.particles.length>0;){const e=this.particles.pop();e&&this.pool.length<this.MAX_POOL_SIZE&&this.pool.push(e)}this.ctx&&this.ctx.clearRect(0,0,this.width,this.height)}getStats(){return{active:this.particles.length,pooled:this.pool.length}}}class E{static init(e){if(this.container=e,typeof document<"u")for(;this.pool.length<15;){const t=document.createElement("div");t.className="floating-number",t.style.display="none",this.pool.push(t)}}static spawn(e,t,s,a=!1,i="+"){if(!this.container||typeof document<"u"&&document.hidden)return;if(this.active.length>=this.MAX_ACTIVE){const g=this.active.shift();g&&(clearTimeout(g.timeoutId),this.recycle(g.el))}const n=this.pool.pop()||(typeof document<"u"?document.createElement("div"):{style:{},className:"",innerHTML:""});n.className=`floating-number ${a?"crit":""}`,n.style.display="block";const o=(Math.random()-.5)*36,l=(Math.random()-.5)*18;n.style.left=`${e+o}px`,n.style.top=`${t+l}px`;const c=typeof s=="number"?x.format(s):s;n.innerHTML=a?`💥 CRITICAL<br/><span style="font-size:1.15em">${i}${c}</span>`:`${i}${c}`,n.parentNode||this.container.appendChild(n);const m=setTimeout(()=>{this.recycle(n);const g=this.active.findIndex(h=>h.el===n);g!==-1&&this.active.splice(g,1)},700);this.active.push({el:n,timeoutId:m})}static recycle(e){e.style.display="none",this.pool.length<this.MAX_POOL?this.pool.push(e):e.parentNode&&e.parentNode.removeChild(e)}static clear(){for(const e of this.active)clearTimeout(e.timeoutId),this.recycle(e.el);this.active=[]}static getPoolStats(){return{pooled:this.pool.length,active:this.active.length}}}p(E,"container",null),p(E,"pool",[]),p(E,"active",[]),p(E,"MAX_ACTIVE",20),p(E,"MAX_POOL",30);const ks=Object.freeze(Object.defineProperty({__proto__:null,FloatingNumbers:E},Symbol.toStringTag,{value:"Module"})),Ss={id:"ascension",render:r=>{const e=r.rank,t=document.createElement("div");return t.style.textAlign="center",t.innerHTML=`
      <div style="font-size:54px; margin-bottom:8px; animation:heroFloat 2s ease-in-out infinite;">
        🌟
      </div>
      <h2 style="font-family:var(--font-display); font-size:26px; color:#fde047; letter-spacing:1px; text-shadow:0 0 15px rgba(245,158,11,0.6); margin-bottom:6px;">
        ${u("modal.ascension.title")}
      </h2>
      <p style="color:var(--text-muted); font-size:13px; margin-bottom:16px;">
        ${u("modal.ascension.congrats")}
      </p>

      <div style="background:rgba(30,41,59,0.6); border:1px solid ${e.color}; border-radius:var(--radius-md); padding:16px; margin-bottom:20px; box-shadow:0 0 20px ${e.glowColor};">
        <div style="font-size:20px; font-weight:900; color:${e.color}; margin-bottom:4px;">
          ${u(e.titleKey)}
        </div>
        <div style="font-size:13px; color:var(--text-main); margin-bottom:8px;">
          ${u(e.descriptionKey)}
        </div>
        <div style="font-size:16px; font-weight:bold; color:#fde047;">
          ${u("rank.multiplier")}: ×${e.multiplier}
        </div>
      </div>

      <button id="closeAscensionModalBtn" style="width:100%; height:48px; background:linear-gradient(135deg, #d97706, #f59e0b); border:1px solid #fde047; border-radius:var(--radius-md); color:#ffffff; font-weight:bold; font-size:16px; cursor:pointer;">
        ${u("btn.claim")}
      </button>
    `,t.querySelector("#closeAscensionModalBtn")?.addEventListener("click",()=>{C.close("ascension"),we.showFullscreenAdIfReady("ascension_milestone")}),t}},ze={common:{borderColor:"rgba(148, 163, 184, 0.6)",glowColor:"rgba(148, 163, 184, 0.2)",gradientBackground:"linear-gradient(135deg, rgba(30, 41, 59, 0.8), rgba(15, 23, 42, 0.95))",badgeSymbol:"C",badgeColor:"#94a3b8",particleColor:"#94a3b8"},uncommon:{borderColor:"rgba(34, 197, 94, 0.8)",glowColor:"rgba(34, 197, 94, 0.35)",gradientBackground:"linear-gradient(135deg, rgba(20, 83, 45, 0.4), rgba(15, 23, 42, 0.95))",badgeSymbol:"UC",badgeColor:"#22c55e",particleColor:"#4ade80"},rare:{borderColor:"rgba(59, 130, 246, 0.85)",glowColor:"rgba(59, 130, 246, 0.45)",gradientBackground:"linear-gradient(135deg, rgba(30, 58, 138, 0.5), rgba(15, 23, 42, 0.95))",badgeSymbol:"R",badgeColor:"#3b82f6",particleColor:"#60a5fa"},epic:{borderColor:"rgba(168, 85, 247, 0.9)",glowColor:"rgba(168, 85, 247, 0.55)",gradientBackground:"linear-gradient(135deg, rgba(88, 28, 135, 0.5), rgba(15, 23, 42, 0.95))",badgeSymbol:"SR",badgeColor:"#a855f7",particleColor:"#c084fc"},legendary:{borderColor:"rgba(234, 179, 8, 0.95)",glowColor:"rgba(234, 179, 8, 0.65)",gradientBackground:"linear-gradient(135deg, rgba(113, 63, 18, 0.6), rgba(15, 23, 42, 0.95))",badgeSymbol:"SSR",badgeColor:"#eab308",particleColor:"#fde047"},mythic:{borderColor:"rgba(236, 72, 153, 1.0)",glowColor:"rgba(236, 72, 153, 0.75)",gradientBackground:"linear-gradient(135deg, rgba(131, 24, 67, 0.6), rgba(15, 23, 42, 0.95))",badgeSymbol:"UR",badgeColor:"#ec4899",particleColor:"#f472b6"}};function Cs(r){const e=ze[r.toLowerCase()]||ze.common;return`
    border: 2px solid ${e.borderColor};
    box-shadow: 0 0 16px ${e.glowColor}, inset 0 0 8px ${e.glowColor};
    background: ${e.gradientBackground};
  `}const Es={id:"summon_result",render:r=>{const e=document.createElement("div");e.style.textAlign="center";const t=r.results.map(s=>{const a=K[s.hero.rarity],i=ze[s.hero.rarity.toLowerCase()]||ze.common;return`
        <div style="${Cs(s.hero.rarity)} border-radius:var(--radius-md); padding:12px; display:flex; flex-direction:column; align-items:center; position:relative; min-width:110px;">
          ${s.isNew?'<div style="position:absolute; top:-8px; right:-6px; background:#10b981; color:#fff; font-size:10px; font-weight:bold; padding:2px 6px; border-radius:var(--radius-full); box-shadow:0 0 8px #10b981;">NEW</div>':""}
          <div style="position:absolute; top:4px; left:6px; font-size:10px; font-weight:900; color:${i.badgeColor};">${i.badgeSymbol}</div>
          <div style="font-size:36px; margin:4px 0; filter:drop-shadow(0 0 8px ${i.glowColor});">🥋</div>
          <div style="font-size:13px; font-weight:bold; color:var(--text-main);">${u(s.hero.nameKey)}</div>
          <div style="font-size:11px; font-weight:bold; color:${a.color}; text-transform:uppercase;">${u(a.nameKey)}</div>
          ${s.isNew?"":`<div style="font-size:11px; color:#c084fc; margin-top:4px;">+${s.essenceGranted} ✨</div>`}
        </div>
      `}).join("");return e.innerHTML=`
      <h2 style="font-family:var(--font-display); font-size:24px; color:#fde047; margin-bottom:12px;">
        ${u("modal.summon.title")}
      </h2>

      <div style="display:flex; flex-wrap:wrap; justify-content:center; gap:12px; max-height:55vh; overflow-y:auto; padding:8px 0; margin-bottom:16px;">
        ${t}
      </div>

      <button id="closeSummonResultBtn" style="width:100%; height:46px; background:linear-gradient(135deg, #7c3aed, #a855f7); border:1px solid #c084fc; border-radius:var(--radius-md); color:#ffffff; font-weight:bold; font-size:15px; cursor:pointer;">
        ${u("btn.close")}
      </button>
    `,e.querySelector("#closeSummonResultBtn")?.addEventListener("click",()=>{C.close("summon_result")}),e}},Ms={id:"offline_reward",render:r=>{const e=r.gains,t=document.createElement("div");t.style.textAlign="center",t.innerHTML=`
      <div style="font-size:48px; margin-bottom:8px;">⏳</div>
      <h2 style="font-family:var(--font-display); font-size:22px; color:#fde047; margin-bottom:4px;">
        ${u("modal.offline.title")}
      </h2>
      <p style="color:var(--text-muted); font-size:12px; margin-bottom:12px;">
        ${u("modal.offline.time")} <b style="color:var(--color-cyan);">${x.formatTime(e.seconds)}</b>
      </p>

      <div style="background:rgba(30,41,59,0.7); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:14px; margin-bottom:18px; display:flex; justify-content:space-around;">
        <div>
          <div style="font-size:11px; color:var(--text-muted);">${u("currency.power")}</div>
          <div id="offlinePowerReward" style="font-size:18px; font-weight:bold; color:#fde047;">+${x.format(e.powerGained)} ⚡</div>
        </div>
        <div>
          <div style="font-size:11px; color:var(--text-muted);">${u("currency.gold")}</div>
          <div id="offlineGoldReward" style="font-size:18px; font-weight:bold; color:#fde047;">+${x.format(e.goldGained)} 🪙</div>
        </div>
      </div>

      <div style="display:flex; flex-direction:column; gap:10px;">
        <button id="claimOfflineAdBtn" style="height:50px; background:linear-gradient(135deg, #10b981, #059669); border:2px solid #6ee7b7; border-radius:var(--radius-md); color:#ffffff; font-weight:bold; font-size:16px; cursor:pointer; box-shadow:0 0 15px rgba(16,185,129,0.4); display:flex; align-items:center; justify-content:center; gap:8px;">
          <span>🎬</span>
          <span>${u("btn.claim_ad")}</span>
        </button>

        <button id="claimOfflineNormalBtn" style="height:44px; background:rgba(30,41,59,0.8); border:1px solid var(--border-subtle); border-radius:var(--radius-md); color:var(--text-main); font-weight:bold; font-size:14px; cursor:pointer;">
          ${u("btn.claim")} (1x)
        </button>
      </div>
    `;const s=a=>{d.set(i=>{i.power+=e.powerGained*a,i.gold+=e.goldGained*a,i.stats.lifetimePower+=e.powerGained*a,i.stats.lifetimeGold+=e.goldGained*a}),_.playVictory(),C.close("offline_reward")};return t.querySelector("#claimOfflineNormalBtn")?.addEventListener("click",()=>{s(1)}),t.querySelector("#claimOfflineAdBtn")?.addEventListener("click",async()=>{const a=await we.showRewardedAd("offline_claim_3x");s(a?3:1)}),t}};class fe{static getPotentialSouls(){const e=d.get(),t=e.soulSkills.soul_rebirth||0;return os(e.stats.lifetimePower,e.towerFloor,t)}static canReincarnate(){return d.get().rankIndex>=5&&this.getPotentialSouls()>0}static reincarnate(){const e=this.getPotentialSouls();return e<=0?!1:(d.set(t=>{t.souls+=e,t.reincarnationCount+=1,t.power=0,t.gold=0,t.rankId="E",t.rankIndex=0,t.buildings={},t.upgrades={},t.towerFloor=1,t.combo={count:0,multiplier:1,timer:0},t.buffs.celestialSurgeEndsAt=0,t.buffs.adPowerSurgeEndsAt=0,t.buffs.frenzyEndsAt=0,R.onReincarnationReset(t)}),_.playAscension(),f.emit("reincarnate:complete",{soulsGained:e,totalSouls:d.get().souls}),!0)}static buySoulSkill(e){const t=d.get(),s=ns(e);if(!s)return!1;const a=t.soulSkills[e]||0;if(a>=s.maxLevel)return!1;const i=Tt(s,a);return t.souls<i?!1:(d.set(n=>{n.souls-=i,n.soulSkills[e]=a+1}),_.playUpgrade(),!0)}}const As={id:"reincarnate",render:()=>{const r=fe.getPotentialSouls(),e=document.createElement("div");return e.style.textAlign="center",e.innerHTML=`
      <div style="font-size:48px; margin-bottom:6px;">🔄</div>
      <h2 style="font-family:var(--font-display); font-size:22px; color:#f43f5e; margin-bottom:8px;">
        ${u("modal.reincarnate.title")}
      </h2>

      <p style="color:var(--text-muted); font-size:12px; margin-bottom:14px; line-height:1.5;">
        ${u("modal.reincarnate.warning")}
      </p>

      <div style="background:rgba(30,41,59,0.7); border:1px solid #f43f5e; border-radius:var(--radius-md); padding:16px; margin-bottom:18px; box-shadow:0 0 20px rgba(244,63,94,0.3);">
        <div style="font-size:12px; color:var(--text-muted);">${u("modal.reincarnate.souls_awarded")}</div>
        <div style="font-size:28px; font-weight:900; color:#f43f5e; font-family:var(--font-display);">
          +${x.format(r)} ⚡
        </div>
      </div>

      <div style="display:flex; gap:10px;">
        <button id="cancelReincarnateBtn" style="flex:1; height:46px; background:rgba(30,41,59,0.8); border:1px solid var(--border-subtle); border-radius:var(--radius-md); color:var(--text-muted); font-weight:bold; cursor:pointer;">
          ${u("btn.cancel")}
        </button>
        <button id="confirmReincarnateBtn" style="flex:1; height:46px; background:linear-gradient(135deg, #e11d48, #be123c); border:1px solid #f43f5e; border-radius:var(--radius-md); color:#ffffff; font-weight:bold; cursor:pointer; box-shadow:0 0 15px rgba(225,29,72,0.4);">
          ${u("btn.confirm")}
        </button>
      </div>
    `,e.querySelector("#cancelReincarnateBtn")?.addEventListener("click",()=>{C.close("reincarnate")}),e.querySelector("#confirmReincarnateBtn")?.addEventListener("click",()=>{fe.reincarnate(),C.close("reincarnate"),we.showFullscreenAdIfReady("reincarnation_checkpoint")}),e}},Ts={id:"settings",render:()=>{const r=d.get().settings,e=document.createElement("div");return e.innerHTML=`
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
        <h2 style="font-family:var(--font-display); font-size:20px; color:#fde047;">
          ⚙️ ${u("nav.settings")}
        </h2>
        <button id="settingsCloseBtn" style="font-size:20px; color:var(--text-muted); cursor:pointer;">✕</button>
      </div>

      <div style="display:flex; flex-direction:column; gap:14px; font-size:13px;">
        <!-- Sound FX -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.sound")}</span>
          <input type="checkbox" id="setSound" ${r.soundEnabled?"checked":""} style="width:20px; height:20px; cursor:pointer;" />
        </div>

        <!-- BGM Music -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.music")}</span>
          <input type="checkbox" id="setMusic" ${r.musicEnabled?"checked":""} style="width:20px; height:20px; cursor:pointer;" />
        </div>

        <!-- Reduced Motion -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.reduced_motion")}</span>
          <input type="checkbox" id="setReducedMotion" ${r.reducedMotion?"checked":""} style="width:20px; height:20px; cursor:pointer;" />
        </div>

        <!-- Screen Shake -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.screen_shake")}</span>
          <input type="checkbox" id="setScreenShake" ${r.screenShake?"checked":""} style="width:20px; height:20px; cursor:pointer;" />
        </div>

        <!-- Number Notation -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.notation")}</span>
          <select id="setNotation" style="background:#1e293b; color:#fff; border:1px solid var(--border-subtle); padding:4px 8px; border-radius:var(--radius-sm);">
            <option value="standard" ${r.notation==="standard"?"selected":""}>Standard (1.25M)</option>
            <option value="scientific" ${r.notation==="scientific"?"selected":""}>Scientific (1.25e6)</option>
          </select>
        </div>

        <!-- Language -->
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <span>${u("settings.language")}</span>
          <select id="setLang" style="background:#1e293b; color:#fff; border:1px solid var(--border-subtle); padding:4px 8px; border-radius:var(--radius-sm);">
            <option value="ru" ${r.language==="ru"?"selected":""}>Русский</option>
            <option value="en" ${r.language==="en"?"selected":""}>English</option>
          </select>
        </div>

        <hr style="border:none; border-top:1px solid var(--border-subtle); margin:8px 0;" />

        <!-- Reset Save -->
        <button id="resetSaveBtn" style="height:40px; background:rgba(239,68,68,0.2); border:1px solid #ef4444; color:#f87171; border-radius:var(--radius-md); font-weight:bold; cursor:pointer;">
          ${u("settings.reset")}
        </button>
      </div>
    `,e.querySelector("#settingsCloseBtn")?.addEventListener("click",()=>{C.close("settings")}),e.querySelector("#setSound")?.addEventListener("change",t=>{const s=t.target.checked;d.set(a=>{a.settings.soundEnabled=s}),_.updateVolumes()}),e.querySelector("#setMusic")?.addEventListener("change",t=>{const s=t.target.checked;d.set(a=>{a.settings.musicEnabled=s}),_.updateVolumes(),s?_.startAmbientBgm():_.stopAmbientBgm()}),e.querySelector("#setReducedMotion")?.addEventListener("change",t=>{const s=t.target.checked;d.set(a=>{a.settings.reducedMotion=s})}),e.querySelector("#setScreenShake")?.addEventListener("change",t=>{const s=t.target.checked;d.set(a=>{a.settings.screenShake=s})}),e.querySelector("#setNotation")?.addEventListener("change",t=>{const s=t.target.value;d.set(a=>{a.settings.notation=s})}),e.querySelector("#setLang")?.addEventListener("change",t=>{const s=t.target.value;st.setLanguage(s),C.close("settings")}),e.querySelector("#resetSaveBtn")?.addEventListener("click",()=>{confirm(u("settings.reset_confirm"))&&(Et.clearSave(),C.close("settings"),location.reload())}),e}},Is={id:"stats",render:()=>{const r=d.get(),e=I.calculateMetrics(r),t=O(r.rankId),s=le(r.rankId),a=document.createElement("div"),i=Object.values(r.buildings||{}).reduce((c,m)=>c+m,0),n=Object.keys(r.heroes||{}).length,o=s?r.power>=s.reqPower:!1,l=s?Math.min(100,Math.floor(r.power/s.reqPower*100)):100;return a.innerHTML=`
      <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:14px; border-bottom:1px solid var(--border-subtle); padding-bottom:8px;">
        <h2 style="font-family:var(--font-display); font-size:20px; color:#fde047; display:flex; align-items:center; gap:8px;">
          <span>🥋</span> ${u("modal.stats.title")}
        </h2>
        <button id="statsCloseBtn" class="close-stats-modal-btn" style="font-size:20px; color:var(--text-muted); cursor:pointer;">✕</button>
      </div>

      <div style="display:flex; flex-direction:column; gap:14px; max-height:68vh; overflow-y:auto; padding-right:4px;">
        <!-- Protagonist Hero Profile Card -->
        <div style="
          background: linear-gradient(135deg, rgba(30,41,59,0.8), rgba(15,23,42,0.95));
          border: 2px solid ${t.color};
          border-radius: var(--radius-lg);
          padding: 14px;
          display: flex;
          align-items: center;
          gap: 14px;
          box-shadow: 0 0 15px ${t.color}30;
          position: relative;
        ">
          <!-- Animated Avatar Frame -->
          <div style="
            width: 58px;
            height: 58px;
            border-radius: 50%;
            background: rgba(15,23,42,0.9);
            border: 2px solid ${t.color};
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 30px;
            box-shadow: 0 0 12px ${t.color}60;
            flex-shrink: 0;
          ">
            🥋
          </div>

          <!-- Info -->
          <div style="flex:1; min-width:0;">
            <div style="display:flex; align-items:center; gap:6px;">
              <span style="font-weight:900; font-size:15px; color:#fff;">
                ${u("rpg.protagonist")}
              </span>
              <span style="background:${t.color}25; color:${t.color}; border:1px solid ${t.color}; font-size:10px; font-weight:bold; padding:1px 6px; border-radius:4px;">
                [${t.id}] ${u(t.nameKey)}
              </span>
            </div>

            <!-- Ascension Progress -->
            <div style="margin-top:6px;">
              <div style="display:flex; justify-content:space-between; font-size:10px; color:var(--text-muted); margin-bottom:2px;">
                <span>${s?`${u("rpg.next_ascension")}: ${u(s.nameKey)}`:"MAX REALM"}</span>
                <span style="color:${o?"#10b981":"#fde047"}; font-weight:bold;">${l}%</span>
              </div>
              <div style="width:100%; height:6px; background:rgba(0,0,0,0.5); border-radius:3px; overflow:hidden;">
                <div style="width:${l}%; height:100%; background:linear-gradient(90deg, #f59e0b, ${o?"#10b981":"#fde047"});"></div>
              </div>
            </div>
          </div>

          ${o?`
            <button id="rpgAscendQuickBtn" style="
              background: linear-gradient(135deg, #10b981, #059669);
              border: 1px solid #34d399;
              color: #fff;
              font-weight: 900;
              font-size: 11px;
              padding: 6px 10px;
              border-radius: var(--radius-sm);
              cursor: pointer;
              box-shadow: 0 0 10px rgba(16,185,129,0.5);
              white-space: nowrap;
              flex-shrink: 0;
            ">
              ✨ ${u("ascend.ready")}
            </button>
          `:""}
        </div>

        <!-- Core RPG Combat Stats Grid -->
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:8px;">
          <!-- Combat Power -->
          <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px; text-align:center;">
            <div style="font-size:10px; color:var(--text-muted); font-weight:bold; text-transform:uppercase;">⚔️ ${u("rpg.combat_power")}</div>
            <div style="font-size:15px; font-weight:900; color:#fde047; margin-top:2px;">
              ${x.format(e.passivePowerPerSec+e.towerCombatPower)}/s
            </div>
          </div>

          <!-- Strike Power -->
          <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px; text-align:center;">
            <div style="font-size:10px; color:var(--text-muted); font-weight:bold; text-transform:uppercase;">💥 ${u("rpg.tap_power")}</div>
            <div style="font-size:15px; font-weight:900; color:#38bdf8; margin-top:2px;">
              ${x.format(e.clickPower)}
            </div>
          </div>

          <!-- Crit Rate -->
          <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px; text-align:center;">
            <div style="font-size:10px; color:var(--text-muted); font-weight:bold; text-transform:uppercase;">🎯 ${u("rpg.crit_rate")}</div>
            <div style="font-size:15px; font-weight:900; color:#c084fc; margin-top:2px;">
              ${(e.critChance*100).toFixed(1)}%
            </div>
          </div>

          <!-- Crit Damage -->
          <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px; text-align:center;">
            <div style="font-size:10px; color:var(--text-muted); font-weight:bold; text-transform:uppercase;">⚡ ${u("rpg.crit_dmg")}</div>
            <div style="font-size:15px; font-weight:900; color:#f43f5e; margin-top:2px;">
              ${e.critMultiplier.toFixed(1)}×
            </div>
          </div>
        </div>

        <!-- Power Sources & Multipliers Breakdown -->
        <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-cyan); border-radius:var(--radius-md); padding:12px;">
          <div style="font-weight:bold; font-size:12px; color:var(--color-cyan); margin-bottom:8px; text-transform:uppercase; display:flex; justify-content:space-between;">
            <span>🌐 ${u("rpg.sources_title")}</span>
            <span>+${x.format(e.passivePowerPerSec)}/s</span>
          </div>
          <div style="display:flex; flex-direction:column; gap:5px; font-size:11px;">
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">🏯 ${u("rpg.sect_output")}:</span>
              <span style="font-weight:bold;">${x.format(e.baseBuildingsPowerPerSec)} / s</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">👑 ${u("rpg.rank_mult")}:</span>
              <span style="color:#fbbf24; font-weight:bold;">×${e.rankMultiplier}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">⚔️ ${u("upgrade.title")}:</span>
              <span style="color:#38bdf8; font-weight:bold;">×${e.globalUpgradesMultiplier.toFixed(2)}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">👥 ${u("rpg.heroes_party")}:</span>
              <span style="color:#c084fc; font-weight:bold;">×${e.heroPowerMultiplier.toFixed(2)}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">🌌 ${u("rpg.soul_mastery")}:</span>
              <span style="color:#f43f5e; font-weight:bold;">×${e.soulPowerMultiplier.toFixed(2)}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">🔥 ${u("rpg.surge_buffs")}:</span>
              <span style="color:#10b981; font-weight:bold;">×${e.activeSurgeMultiplier.toFixed(1)}</span>
            </div>
          </div>
        </div>

        <!-- Lifetime Statistics -->
        <div style="background:rgba(30,41,59,0.6); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:12px;">
          <div style="font-weight:bold; font-size:12px; color:#fde047; margin-bottom:8px; text-transform:uppercase;">
            📜 Lifetime Records
          </div>
          <div style="display:flex; flex-direction:column; gap:4px; font-size:11px;">
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Lifetime Power:</span>
              <span style="font-weight:bold; color:#fde047;">${x.format(r.stats.lifetimePower)} ⚡</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Lifetime Gold:</span>
              <span style="font-weight:bold; color:#fde047;">${x.format(r.stats.lifetimeGold)} 🪙</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Manual Training Taps:</span>
              <span style="font-weight:bold;">${r.stats.totalClicks} (${r.stats.totalCrits} Crits)</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Sect Buildings Owned:</span>
              <span style="font-weight:bold;">${i}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Allied Heroes:</span>
              <span style="font-weight:bold; color:#c084fc;">${n} / 16</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Highest Tower Floor:</span>
              <span style="font-weight:bold; color:#38bdf8;">Floor ${r.towerMaxFloor}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Campaign Bosses Slain:</span>
              <span style="font-weight:bold; color:#ef4444;">${r.stats.campaignBossesDefeated||0}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Reincarnations Performed:</span>
              <span style="font-weight:bold; color:#f43f5e;">${r.reincarnationCount}</span>
            </div>
            <div style="display:flex; justify-content:space-between;">
              <span style="color:var(--text-muted);">Total Active Playtime:</span>
              <span style="font-weight:bold;">${x.formatTime(r.stats.playtimeSeconds)}</span>
            </div>
          </div>
        </div>
      </div>
    `,a.querySelector("#statsCloseBtn")?.addEventListener("click",()=>{C.close("stats")}),a.querySelector("#rpgAscendQuickBtn")?.addEventListener("click",()=>{C.close("stats"),f.emit("screen:change",{screenId:"ascension"})}),a}},qs={id:"more_menu",render:()=>{const r=document.createElement("div");r.style.textAlign="center";const t=[{id:"quests",icon:"📜",labelKey:"nav.quests",color:"#f59e0b",type:"screen"},{id:"tower",icon:"🏰",labelKey:"nav.tower",color:"#38bdf8",type:"screen"},{id:"expeditions",icon:"🗺️",labelKey:"nav.expeditions",color:"#10b981",type:"screen"},{id:"relics",icon:"🏺",labelKey:"nav.relics",color:"#a855f7",type:"screen"},{id:"souls",icon:"🌀",labelKey:"nav.souls",color:"#ec4899",type:"screen"},{id:"dailies",icon:"📅",labelKey:"nav.dailies",color:"#eab308",type:"screen"},{id:"stats",icon:"📊",labelKey:"btn.stats",color:"#06b6d4",type:"modal"},{id:"settings",icon:"⚙️",labelKey:"nav.settings",color:"#94a3b8",type:"modal"}].map(s=>`
      <button class="more-menu-tile" data-id="${s.id}" data-type="${s.type}" style="
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        padding: 14px 10px;
        background: rgba(30, 41, 59, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.12);
        border-radius: var(--radius-md);
        color: var(--text-main);
        cursor: pointer;
        transition: all 0.15s ease;
        gap: 6px;
      ">
        <span style="font-size: 28px; filter: drop-shadow(0 0 8px ${s.color}60);">${s.icon}</span>
        <span style="font-size: 12px; font-weight: bold;">${u(s.labelKey)}</span>
      </button>
    `).join("");return r.innerHTML=`
      <h2 style="font-family:var(--font-display); font-size:22px; color:#fde047; margin-bottom:14px; text-shadow:0 0 10px rgba(253,224,71,0.4);">
        ✨ ${u("modal.more.title")}
      </h2>

      <div style="display:grid; grid-template-columns: repeat(3, 1fr); gap:10px; margin-bottom:18px;">
        ${t}
      </div>

      <button id="closeMoreMenuBtn" style="
        width: 100%;
        height: 44px;
        background: rgba(51, 65, 85, 0.8);
        border: 1px solid var(--border-subtle);
        border-radius: var(--radius-md);
        color: #ffffff;
        font-weight: bold;
        font-size: 14px;
        cursor: pointer;
      ">
        ${u("btn.close")}
      </button>
    `,r.querySelectorAll(".more-menu-tile").forEach(s=>{s.addEventListener("click",a=>{const i=a.currentTarget,n=i.getAttribute("data-id"),o=i.getAttribute("data-type");_.playTap(),C.close("more_menu"),o==="screen"?f.emit("screen:change",{screenId:n}):o==="modal"&&f.emit("modal:open",{modalId:n})})}),r.querySelector("#closeMoreMenuBtn")?.addEventListener("click",()=>{_.playTap(),C.close("more_menu")}),r}};class Ks{constructor(e){p(this,"el");p(this,"particleCanvas",null);p(this,"heroAvatarEl",null);p(this,"enemyAvatarEl",null);p(this,"enemyHpFillEl",null);p(this,"enemyHpTextEl",null);p(this,"bossTimerBarEl",null);p(this,"bossTimerTextEl",null);p(this,"bossWarningBannerEl",null);p(this,"lastHitSoundTime",0);this.particleCanvas=e||null,this.el=document.createElement("div"),this.el.className="battlefield-viewport",this.el.style.cssText=`
      position: relative;
      width: 100%;
      min-height: 220px;
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      border-radius: var(--radius-lg);
      background: radial-gradient(circle at 50% 30%, rgba(30, 41, 59, 0.9), rgba(15, 23, 42, 0.98));
      border: 1px solid var(--border-subtle);
      box-shadow: inset 0 0 30px rgba(0, 0, 0, 0.6);
      overflow: hidden;
      user-select: none;
      padding: 10px;
    `,this.render(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>this.update()),f.on("combat:enemy_spawned",()=>this.onEnemySpawned()),f.on("combat:player_attack",e=>this.onPlayerAttack(e)),f.on("combat:auto_attack",e=>this.onAutoAttack(e)),f.on("combat:enemy_killed",()=>this.onEnemyKilled()),f.on("combat:reward_dropped",e=>this.onRewardDropped(e)),f.on("combat:boss_warning",e=>this.showBossWarning(e.bossName)),f.on("campaign:boss_failed",()=>this.update()),f.on("ascension:rankUp",()=>this.onHeroAscended()),f.on("hero:unlocked",()=>this.render()),f.on("hero:starUp",()=>this.render()),f.on("combat:hero_skill",e=>this.onHeroSkill(e)),f.on("campaign:world_cleared",e=>this.onWorldCleared(e)),f.on("combat:boss_mechanic",e=>this.onBossMechanic(e)),f.on("combat:samsara_rush_kill",e=>this.onSamsaraRushKill(e)),this.el.addEventListener("pointerdown",e=>{if(e.target.closest("button"))return;const s=this.el.getBoundingClientRect(),a="touches"in e&&e.touches[0]?e.touches[0].clientX:e.clientX||s.left+s.width*.7,i="touches"in e&&e.touches[0]?e.touches[0].clientY:e.clientY||s.top+s.height*.5;this.triggerAttack(a,i)})}onSamsaraRushKill(e){if(!this.enemyAvatarEl)return;const t=this.enemyAvatarEl.getBoundingClientRect(),s=t.left+t.width/2,a=t.top+t.height/2;E.spawn(s,a-20,"⚡ SAMSARA RUSH!",!0,""),this.particleCanvas&&this.particleCanvas.emitBurst(s,a,25,"#fbbf24",!0)}onBossMechanic(e){if(!this.enemyAvatarEl)return;const t=this.enemyAvatarEl.getBoundingClientRect(),s=t.left+t.width/2,a=t.top;e.active?e.mechanic==="shield"?(E.spawn(s,a-10,"🛡️ SHIELD UP!",!0,""),this.enemyAvatarEl.style.boxShadow="0 0 25px #38bdf8",this.particleCanvas&&this.particleCanvas.emitBurst(s,a,16,"#38bdf8",!0)):e.mechanic==="enrage"?(E.spawn(s,a-10,"🔥 ENRAGED!",!0,""),this.enemyAvatarEl.style.boxShadow="0 0 30px #ef4444",this.enemyAvatarEl.style.filter="brightness(1.4) drop-shadow(0 0 15px #ef4444)",this.particleCanvas&&this.particleCanvas.emitBurst(s,a,20,"#ef4444",!0)):e.mechanic==="damage_reduction"&&(E.spawn(s,a-10,"⛓️ HARDENED (-50%)",!0,""),this.enemyAvatarEl.style.boxShadow="0 0 20px #94a3b8",this.particleCanvas&&this.particleCanvas.emitBurst(s,a,14,"#94a3b8",!0)):(this.enemyAvatarEl.style.boxShadow="",this.enemyAvatarEl.style.filter="")}onWorldCleared(e){const t=Me(e.worldId)||Ee[0];if(_.playAscension(),this.particleCanvas){const s=this.el.getBoundingClientRect();this.particleCanvas.emitBurst(s.left+s.width/2,s.top+s.height/2,35,t.accentColor,!0)}this.bossWarningBannerEl&&(this.bossWarningBannerEl.textContent=`🎉 ${t.emoji} ${u(t.nameKey).toUpperCase()} CLEARED! 🎉`,this.bossWarningBannerEl.style.background="rgba(16, 185, 129, 0.95)",this.bossWarningBannerEl.style.display="block",this.bossWarningBannerEl.style.opacity="1",this.bossWarningBannerEl.style.transform="translate(-50%, -50%) scale(1.1)",setTimeout(()=>{this.bossWarningBannerEl&&(this.bossWarningBannerEl.style.opacity="0",this.bossWarningBannerEl.style.transform="translate(-50%, -50%) scale(0.8)",setTimeout(()=>{this.bossWarningBannerEl&&(this.bossWarningBannerEl.style.display="none",this.bossWarningBannerEl.style.background="rgba(239, 68, 68, 0.9)")},300))},2e3)),this.render()}onHeroAscended(){if(!this.heroAvatarEl)return;const e=d.get().settings?.reducedMotion;if(e||(this.heroAvatarEl.style.transform="scale(1.35) rotate(-5deg)",this.heroAvatarEl.style.filter="brightness(2.2) drop-shadow(0 0 25px #fde047)"),this.particleCanvas){const t=this.heroAvatarEl.getBoundingClientRect(),s=t.left+t.width/2,a=t.top+t.height/2;this.particleCanvas.emitBurst(s,a,e?6:24,"#fde047",!e)}e||setTimeout(()=>{this.heroAvatarEl&&(this.heroAvatarEl.style.transform="",this.heroAvatarEl.style.filter="")},450),this.update()}onHeroSkill(e){if(this.updateHpBar(e.remainingHp),this.enemyAvatarEl){const s=this.enemyAvatarEl.getBoundingClientRect(),a=s.left+s.width/2+(Math.random()*20-10),i=s.top;e.damage>0&&(E.spawn(a,i,`${e.skillIcon} ${x.format(e.damage)}`,!0,"💥 "),this.particleCanvas&&this.particleCanvas.emitBurst(a,i,18,"#f59e0b",!0)),e.gold>0&&E.spawn(a,i-20,`${e.skillIcon} +${x.format(e.gold)} 🪙`,!0,""),e.power>0&&E.spawn(a,i-20,`${e.skillIcon} +${x.format(e.power)} ⚡`,!0,"")}this.el.querySelectorAll(".support-hero-slot").forEach(s=>{s.style.transform="scale(1.25)",s.style.filter="brightness(1.5) drop-shadow(0 0 10px #fde047)",setTimeout(()=>{s.style.transform="",s.style.filter=""},250)}),_.playEnemyHit()}triggerScreenShake(e=4){const t=d.get();if(t.settings?.reducedMotion||t.settings?.screenShake===!1)return;const s=(Math.random()-.5)*e,a=(Math.random()-.5)*e;this.el.style.transform=`translate(${s}px, ${a}px)`,setTimeout(()=>{this.el.style.transform=""},80)}flyRewardCoin(e,t,s="🪙"){const a=document.createElement("div");a.textContent=s,a.style.cssText=`
      position: fixed;
      left: ${e}px;
      top: ${t}px;
      font-size: 20px;
      pointer-events: none;
      z-index: 1000;
      transition: all 0.65s cubic-bezier(0.25, 1, 0.5, 1);
      filter: drop-shadow(0 0 6px rgba(234, 179, 8, 0.8));
    `,document.body.appendChild(a);const i=window.innerWidth*.5+(Math.random()*40-20),n=30;requestAnimationFrame(()=>{a.style.transform=`translate(${i-e}px, ${n-t}px) scale(0.6)`,a.style.opacity="0"}),setTimeout(()=>{a.parentNode&&a.parentNode.removeChild(a)},700)}triggerAttack(e,t){const s=this.el.getBoundingClientRect(),a=e||s.left+s.width*.7,i=t||s.top+s.height*.5,n=H.attack(a,i);if(n.damage<=0)return;if(E.spawn(a,i,n.damage,n.isCrit,"-"),n.isCrit&&this.triggerScreenShake(6),this.particleCanvas){const l=n.isCrit?"#fde047":"#38bdf8";this.particleCanvas.emitBurst(a,i,n.isCrit?16:8,l,n.isCrit)}d.get().settings?.reducedMotion||(this.heroAvatarEl&&(this.heroAvatarEl.style.transform="translateX(12px) scale(1.05)",setTimeout(()=>{this.heroAvatarEl&&(this.heroAvatarEl.style.transform="")},120)),this.el.querySelectorAll(".support-hero-slot").forEach((c,m)=>{setTimeout(()=>{c.style.transform="translateX(6px) scale(1.06)",setTimeout(()=>{c.style.transform=""},110)},m*25)}),this.enemyAvatarEl&&(this.enemyAvatarEl.style.transform="scale(0.92) translateX(4px)",this.enemyAvatarEl.style.filter="brightness(1.5) drop-shadow(0 0 10px rgba(239, 68, 68, 0.8))",setTimeout(()=>{this.enemyAvatarEl&&(this.enemyAvatarEl.style.transform="",this.enemyAvatarEl.style.filter="")},150)))}onAutoAttack(e){if(this.updateHpBar(e.remainingHp),d.get().settings?.reducedMotion||(this.heroAvatarEl&&(this.heroAvatarEl.style.transform="translateX(6px) scale(1.02)",setTimeout(()=>{this.heroAvatarEl&&(this.heroAvatarEl.style.transform="")},100)),this.el.querySelectorAll(".support-hero-slot").forEach((i,n)=>{setTimeout(()=>{i.style.transform="translateX(4px) scale(1.03)",setTimeout(()=>{i.style.transform=""},90)},n*20)}),this.enemyAvatarEl&&(this.enemyAvatarEl.style.transform="scale(0.96) translateX(2px)",this.enemyAvatarEl.style.filter="brightness(1.3) drop-shadow(0 0 6px rgba(239, 68, 68, 0.5))",setTimeout(()=>{this.enemyAvatarEl&&(this.enemyAvatarEl.style.transform="",this.enemyAvatarEl.style.filter="")},120))),this.enemyAvatarEl){const a=this.enemyAvatarEl.getBoundingClientRect(),i=a.left+a.width/2+(Math.random()*20-10),n=a.top+10;E.spawn(i,n,e.damage,e.isCrit,"-")}const s=Date.now();s-this.lastHitSoundTime>=280&&(this.lastHitSoundTime=s,_.playEnemyHit())}onPlayerAttack(e){this.updateHpBar(e.remainingHp)}onEnemyKilled(){if(this.enemyAvatarEl&&(this.enemyAvatarEl.style.transform="scale(0) rotate(15deg)",this.enemyAvatarEl.style.opacity="0",this.enemyAvatarEl.style.filter="brightness(2.0)"),this.particleCanvas&&this.enemyAvatarEl){const e=this.enemyAvatarEl.getBoundingClientRect();this.particleCanvas.emitBurst(e.left+e.width/2,e.top+e.height/2,20,"#eab308",!0)}}onRewardDropped(e){let t=e.x,s=e.y;if(t===void 0||s===void 0)if(this.enemyAvatarEl){const a=this.enemyAvatarEl.getBoundingClientRect();t=a.left+a.width/2,s=a.top+a.height/3}else{const a=this.el.getBoundingClientRect();t=a.left+a.width*.7,s=a.top+a.height*.5}e.rewards.gold>0&&(E.spawn(t,s,`${x.format(e.rewards.gold)} 🪙`,!1,"+"),this.flyRewardCoin(t,s,"🪙")),e.rewards.power>0&&setTimeout(()=>{E.spawn(t,s-18,`${x.format(e.rewards.power)} ⚡`,!1,"+"),this.flyRewardCoin(t,s-18,"⚡")},80),e.rewards.crystals&&e.rewards.crystals>0&&setTimeout(()=>{E.spawn(t,s-36,`${e.rewards.crystals} 💎`,!0,"+"),this.flyRewardCoin(t,s-36,"💎")},160)}onEnemySpawned(){this.updateEnemy(),this.enemyAvatarEl&&(this.enemyAvatarEl.style.transition="none",this.enemyAvatarEl.style.transform="scale(0.6) translateY(20px)",this.enemyAvatarEl.style.opacity="0",this.enemyAvatarEl.style.filter="brightness(1.5)",requestAnimationFrame(()=>{this.enemyAvatarEl&&(this.enemyAvatarEl.style.transition="all 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275)",this.enemyAvatarEl.style.transform="scale(1) translateY(0)",this.enemyAvatarEl.style.opacity="1",this.enemyAvatarEl.style.filter="")}))}showBossWarning(e){this.bossWarningBannerEl&&(this.bossWarningBannerEl.textContent=`⚠️ BOSS: ${e.toUpperCase()} ⚠️`,this.bossWarningBannerEl.style.display="block",this.bossWarningBannerEl.style.opacity="1",this.bossWarningBannerEl.style.transform="translate(-50%, -50%) scale(1)",this.triggerScreenShake(8),_.playAscension(),setTimeout(()=>{this.bossWarningBannerEl&&(this.bossWarningBannerEl.style.opacity="0",this.bossWarningBannerEl.style.transform="translate(-50%, -50%) scale(0.8)",setTimeout(()=>{this.bossWarningBannerEl&&(this.bossWarningBannerEl.style.display="none")},300))},1800))}updateHpBar(e){const s=H.getCombatState().activeEnemy;if(!s)return;const a=s.maxHp||1,i=Math.max(0,Math.min(100,e/a*100));this.enemyHpFillEl&&(this.enemyHpFillEl.style.width=`${i}%`,this.enemyHpFillEl.style.background=s.isBoss?"linear-gradient(90deg, #ef4444, #f59e0b)":"linear-gradient(90deg, #10b981, #38bdf8)"),this.enemyHpTextEl&&(this.enemyHpTextEl.textContent=`${x.format(Math.ceil(e))} / ${x.format(a)} HP`)}update(){const e=d.get(),t=O(e.rankId),s=H.getCombatState(),a=s.activeEnemy,i=Me(s.worldId||e.campaign.currentWorldId)||Ee[0];this.el.style.background=i.bgGradient;const n=this.el.querySelector("#worldBadgeText");n&&(n.innerHTML=`<span>${i.emoji}</span><span>${u(i.nameKey)}</span><span style="color:var(--text-muted); font-size:10px;">[${s.stageId}]</span>`,n.style.color=i.accentColor);const o=this.el.querySelector("#heroAvatarRing"),l=this.el.querySelector("#heroAvatarIcon"),c=this.el.querySelector("#heroRankTitle"),m=this.el.querySelector("#heroDpsTag"),g=this.el.querySelector("#partySynergyBadge");if(o&&(o.style.borderColor=t.color,o.style.background=`radial-gradient(circle, ${t.glowColor}, rgba(15,23,42,0.95))`,o.style.boxShadow=`0 0 20px ${t.color}50`),l&&(l.textContent=t.avatarIcon||"🥋",l.style.filter=`drop-shadow(0 0 8px ${t.color})`),c&&(c.textContent=`[${t.id}] ${u(t.nameKey)}`,c.style.color=t.color),m&&(m.textContent=`${x.format(H.calculateAutoDps())}/s`),g){const h=Y.getPartySynergy();g.innerHTML=`<span>👥</span><span>${h.partyCount>0?`${h.synergyPctText} Party Synergy`:"Solo Cultivator"}</span>`}if(a){this.updateHpBar(a.currentHp);const h=this.el.querySelector("#bossTimerContainer");if(s.isTimerActive&&h){h.style.display="flex";const y=Math.max(0,s.encounterTimer/(s.maxEncounterTimer||1)*100);this.bossTimerBarEl&&(this.bossTimerBarEl.style.width=`${y}%`),this.bossTimerTextEl&&(this.bossTimerTextEl.textContent=`${Math.ceil(s.encounterTimer)}s`)}else h&&(h.style.display="none")}}updateEnemy(){const t=H.getCombatState().activeEnemy;if(!t)return;const s=this.el.querySelector("#enemyNameText"),a=this.el.querySelector("#enemyTitleText"),i=this.el.querySelector("#enemySpriteIcon");s&&(s.textContent=t.defaultName),a&&(t.isBoss&&t.defaultBossTitle?(a.style.display="block",a.textContent=`⚔️ ${t.defaultBossTitle}`):a.style.display="none"),i&&(i.textContent=t.isBoss?"👹":t.archetype==="elite"?"🐺":t.archetype==="magic"?"🔮":t.archetype==="tank"?"🗿":"👺"),this.update()}render(){const e=d.get(),t=O(e.rankId),s=H.getCombatState(),a=s.activeEnemy,i=Y.getActiveParty(3),n=Y.getPartySynergy(),o=Me(s.worldId||e.campaign.currentWorldId)||Ee[0];this.el.style.background=o.bgGradient,this.el.innerHTML=`
      <!-- Top World & Encounter Info Bar -->
      <div style="width:100%; display:flex; justify-content:space-between; align-items:center; max-width:400px; padding:0 4px 4px 4px; border-bottom:1px solid rgba(255,255,255,0.08); z-index:10;">
        <div id="worldBadgeText" style="font-size:11px; font-weight:bold; color:${o.accentColor}; display:flex; align-items:center; gap:5px;">
          <span>${o.emoji}</span>
          <span>${u(o.nameKey)}</span>
          <span style="color:var(--text-muted); font-size:10px;">[${s.stageId}]</span>
        </div>
        ${o.worldModifier?`
          <div id="worldModifierBadge" style="font-size:9px; font-weight:bold; color:${o.accentColor}; background:${o.accentColor}20; border:1px solid ${o.accentColor}40; padding:1px 6px; border-radius:999px;">
            ${o.worldModifier.label}
          </div>
        `:""}
      </div>

      <!-- Top Enemy Status & Health Bar -->
      <div style="width:100%; display:flex; flex-direction:column; align-items:center; gap:4px; z-index:10;">
        <div style="display:flex; justify-content:space-between; align-items:center; width:100%; max-width:400px; padding:0 4px;">
          <div>
            <div id="enemyTitleText" style="font-size:10px; color:#f59e0b; font-weight:bold; letter-spacing:0.5px; display:${a?.isBoss?"block":"none"};">
              ⚔️ ${a?.defaultBossTitle||""}
            </div>
            <div id="enemyNameText" style="font-size:14px; font-weight:bold; color:#f1f5f9; text-shadow:0 1px 3px rgba(0,0,0,0.8);">
              ${a?.defaultName||"Enemy Encounter"}
            </div>
          </div>
          <div id="enemyHpText" style="font-size:11px; font-weight:bold; color:var(--text-muted); font-family:var(--font-display);">
            ${x.format(a?.currentHp||0)} / ${x.format(a?.maxHp||1)} HP
          </div>
        </div>

        <!-- Enemy HP Bar Container -->
        <div style="width:100%; max-width:400px; height:10px; background:rgba(0,0,0,0.6); border-radius:6px; border:1px solid rgba(255,255,255,0.15); overflow:hidden; position:relative;">
          <div id="enemyHpFill" style="height:100%; width:100%; background:linear-gradient(90deg, #10b981, #38bdf8); transition:width 0.1s ease-out;"></div>
        </div>

        <!-- Boss Timer Bar (if active) -->
        <div id="bossTimerContainer" style="display:${s.isTimerActive?"flex":"none"}; align-items:center; gap:6px; width:100%; max-width:400px; margin-top:2px;">
          <span style="font-size:10px; font-weight:bold; color:#ef4444;">⏱️ TIME:</span>
          <div style="flex:1; height:4px; background:rgba(0,0,0,0.6); border-radius:2px; overflow:hidden;">
            <div id="bossTimerBar" style="height:100%; width:100%; background:#ef4444; transition:width 0.2s linear;"></div>
          </div>
          <span id="bossTimerText" style="font-size:10px; font-weight:bold; color:#ef4444;">30s</span>
        </div>
      </div>

      <!-- Boss Warning Banner Overlay -->
      <div id="bossWarningBanner" style="display:none; position:absolute; top:35%; left:50%; transform:translate(-50%, -50%); background:rgba(239, 68, 68, 0.9); color:#fff; font-size:14px; font-weight:900; font-family:var(--font-display); padding:8px 18px; border-radius:var(--radius-md); border:2px solid #fde047; box-shadow:0 0 30px rgba(239,68,68,0.8); z-index:40; pointer-events:none; transition:all 0.3s ease; text-align:center;">
        ⚠️ BOSS ENCOUNTER ⚠️
      </div>

      <!-- Center Battlefield Arena (Hero Party on left, Enemy on right) -->
      <div style="display:flex; justify-content:space-around; align-items:center; width:100%; flex:1; position:relative; padding:10px 0;">
        <!-- Left: Active Hero Party Formation (Leader + Support Heroes) -->
        <div id="battlePartyFormation" style="display:flex; flex-direction:column; align-items:center; gap:5px; position:relative;">
          <div style="display:flex; align-items:center; gap:6px;">
            <!-- Support Hero Left Slot -->
            <div id="supportHero0" class="support-hero-slot" style="display:${i[0]?"flex":"none"}; flex-direction:column; align-items:center; cursor:pointer; transition:transform 0.12s ease-out;">
              <div style="width:36px; height:36px; border-radius:50%; border:2px solid ${i[0]?K[i[0].hero.rarity].color:"#64748b"}; background:radial-gradient(circle, ${i[0]?K[i[0].hero.rarity].glow:"rgba(0,0,0,0.5)"}, rgba(15,23,42,0.9)); display:flex; align-items:center; justify-content:center; box-shadow:0 0 8px ${i[0]?K[i[0].hero.rarity].color:"#000"}40; position:relative;">
                <span style="font-size:17px;">${i[0]?.hero.icon||"🌸"}</span>
                <div style="position:absolute; bottom:-3px; right:-3px; background:#0f172a; border:1px solid #eab308; border-radius:4px; font-size:8px; font-weight:900; color:#eab308; padding:0 2px; line-height:10px;">⭐${i[0]?.stars||1}</div>
              </div>
            </div>

            <!-- Central Leader (Protagonist) -->
            <div id="battleHeroAvatar" style="display:flex; flex-direction:column; align-items:center; gap:3px; cursor:pointer; transition:all 0.15s ease-out; position:relative;">
              <div id="heroAvatarRing" style="
                width: 66px;
                height: 66px;
                border-radius: 50%;
                border: 2px solid ${t.color};
                background: radial-gradient(circle, ${t.glowColor}, rgba(15,23,42,0.95));
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 0 18px ${t.color}50;
                position: relative;
                animation: heroFloat 3s infinite ease-in-out;
              ">
                <span id="heroAvatarIcon" style="font-size:32px; filter:drop-shadow(0 0 8px ${t.color});">
                  ${t.avatarIcon||"🥋"}
                </span>
              </div>
              <div id="heroRankTitle" style="font-size:10px; font-weight:bold; color:${t.color}; text-shadow:0 1px 3px #000; text-transform:uppercase; letter-spacing:0.5px;">
                [${t.id}] ${u(t.nameKey)}
              </div>
              <!-- Hero DPS tag -->
              <div id="heroDpsTag" style="font-size:9px; color:var(--text-muted); background:rgba(0,0,0,0.6); border:1px solid rgba(255,255,255,0.1); padding:1px 5px; border-radius:4px;">
                ${x.format(H.calculateAutoDps())}/s
              </div>
            </div>

            <!-- Support Hero Right Slot 1 -->
            <div id="supportHero1" class="support-hero-slot" style="display:${i[1]?"flex":"none"}; flex-direction:column; align-items:center; cursor:pointer; transition:transform 0.12s ease-out;">
              <div style="width:36px; height:36px; border-radius:50%; border:2px solid ${i[1]?K[i[1].hero.rarity].color:"#64748b"}; background:radial-gradient(circle, ${i[1]?K[i[1].hero.rarity].glow:"rgba(0,0,0,0.5)"}, rgba(15,23,42,0.9)); display:flex; align-items:center; justify-content:center; box-shadow:0 0 8px ${i[1]?K[i[1].hero.rarity].color:"#000"}40; position:relative;">
                <span style="font-size:17px;">${i[1]?.hero.icon||"⚔️"}</span>
                <div style="position:absolute; bottom:-3px; right:-3px; background:#0f172a; border:1px solid #eab308; border-radius:4px; font-size:8px; font-weight:900; color:#eab308; padding:0 2px; line-height:10px;">⭐${i[1]?.stars||1}</div>
              </div>
            </div>

            <!-- Support Hero Right Slot 2 -->
            <div id="supportHero2" class="support-hero-slot" style="display:${i[2]?"flex":"none"}; flex-direction:column; align-items:center; cursor:pointer; transition:transform 0.12s ease-out;">
              <div style="width:36px; height:36px; border-radius:50%; border:2px solid ${i[2]?K[i[2].hero.rarity].color:"#64748b"}; background:radial-gradient(circle, ${i[2]?K[i[2].hero.rarity].glow:"rgba(0,0,0,0.5)"}, rgba(15,23,42,0.9)); display:flex; align-items:center; justify-content:center; box-shadow:0 0 8px ${i[2]?K[i[2].hero.rarity].color:"#000"}40; position:relative;">
                <span style="font-size:17px;">${i[2]?.hero.icon||"⚡"}</span>
                <div style="position:absolute; bottom:-3px; right:-3px; background:#0f172a; border:1px solid #eab308; border-radius:4px; font-size:8px; font-weight:900; color:#eab308; padding:0 2px; line-height:10px;">⭐${i[2]?.stars||1}</div>
              </div>
            </div>
          </div>

          <!-- Party Synergy Badge -->
          <div id="partySynergyBadge" style="font-size:9px; font-weight:bold; color:#38bdf8; background:rgba(56,189,248,0.15); border:1px solid rgba(56,189,248,0.3); padding:1px 6px; border-radius:999px; display:flex; align-items:center; gap:3px;">
            <span>👥</span>
            <span>${i.length>0?`${n.synergyPctText} Party Synergy`:"Solo Cultivator"}</span>
          </div>
        </div>

        <!-- Center Combat Clash VFX Anchor -->
        <div style="display:flex; flex-direction:column; align-items:center; opacity:0.6;">
          <span style="font-size:20px; color:#f59e0b; font-weight:900;">⚔️</span>
        </div>

        <!-- Right: Active Enemy Entity -->
        <div id="battleEnemyAvatar" style="display:flex; flex-direction:column; align-items:center; gap:4px; cursor:pointer; transition:all 0.15s ease-out; position:relative;">
          <div style="width:76px; height:76px; border-radius:50%; border:2px solid ${a?.isBoss?"#ef4444":"#64748b"}; background:radial-gradient(circle, rgba(239,68,68,0.2), rgba(15,23,42,0.95)); display:flex; align-items:center; justify-content:center; box-shadow:${a?.isBoss?"0 0 25px rgba(239,68,68,0.6)":"none"};">
            <span id="enemySpriteIcon" style="font-size:${a?.isBoss?"44px":"36px"};">
              ${a?.isBoss?"👹":"👺"}
            </span>
          </div>
          <div style="font-size:11px; font-weight:bold; color:${a?.isBoss?"#f87171":"#cbd5e1"};">
            Encounter
          </div>
        </div>
      </div>

      <!-- Ground Platform Silhouette -->
      <div style="width:100%; height:2px; background:linear-gradient(90deg, transparent, rgba(56,189,248,0.4), transparent); margin-top:auto;"></div>
    `,this.heroAvatarEl=this.el.querySelector("#battleHeroAvatar"),this.enemyAvatarEl=this.el.querySelector("#battleEnemyAvatar"),this.enemyHpFillEl=this.el.querySelector("#enemyHpFill"),this.enemyHpTextEl=this.el.querySelector("#enemyHpText"),this.bossTimerBarEl=this.el.querySelector("#bossTimerBar"),this.bossTimerTextEl=this.el.querySelector("#bossTimerText"),this.bossWarningBannerEl=this.el.querySelector("#bossWarningBanner")}}class Rs{constructor(e){p(this,"el");p(this,"viewport");p(this,"buyMultiplier",1);p(this,"activeCategory","buildings");p(this,"renderedCategory","");p(this,"renderedRankIndex",-1);p(this,"handleKeydown",e=>{if(!(typeof HTMLInputElement<"u"&&e.target instanceof HTMLInputElement)&&!(typeof HTMLTextAreaElement<"u"&&e.target instanceof HTMLTextAreaElement))if(e.code==="Space"){e.preventDefault?.(),this.viewport.triggerAttack();const t=this.el.querySelector("#trainActionBtn");t&&(t.style.transform="scale(0.96)",setTimeout(()=>{t.style.transform=""},100))}else e.code==="KeyA"?(e.preventDefault?.(),d.set(t=>{R.toggleAutoAdvance(t)}),_.playTap(),this.updateStageHeader()):e.code==="KeyB"&&d.get().campaign.campaignMode==="boss_blocked"&&(e.preventDefault?.(),d.set(t=>{R.retryBoss(t,!1)}),H.spawnCurrentEncounter(),_.playTap(),this.updateStageHeader())});this.viewport=new Ks(e),this.el=document.createElement("div"),this.el.className="screen-container battle-screen-container",this.render(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.renderedCategory="",this.renderedRankIndex=-1,this.render()}),f.on("campaign:stage_cleared",()=>this.updateStageHeader()),f.on("campaign:mode_changed",()=>this.updateStageHeader()),f.on("campaign:boss_failed",()=>this.updateStageHeader());const e=this.el.querySelector("#trainActionBtn"),t=s=>{s.preventDefault();const a=e.getBoundingClientRect(),i="touches"in s&&s.touches[0]?s.touches[0].clientX:s.clientX||a.left+a.width/2,n="touches"in s&&s.touches[0]?s.touches[0].clientY:s.clientY||a.top+a.height/2;this.viewport.triggerAttack(i,n),e.style.transform="scale(0.96)",setTimeout(()=>{e.style.transform=""},100)};e?.addEventListener("pointerdown",t),typeof window<"u"&&window.addEventListener("keydown",this.handleKeydown),this.el.addEventListener("click",s=>{const a=s.target;if(a.closest("#autoAdvanceToggleBtn")){d.set(n=>{R.toggleAutoAdvance(n)}),_.playTap(),this.updateStageHeader();return}if(a.closest("#bossRetryBtn")){d.get().campaign.campaignMode==="boss_blocked"&&(d.set(n=>{R.retryBoss(n,!1)}),H.spawnCurrentEncounter(),_.playTap(),this.updateStageHeader());return}if(a.closest("#bossBoostedRetryBtn")){d.get().campaign.campaignMode==="boss_blocked"&&we.showRewardedAd("boss_retry_boost").then(n=>{n&&(d.set(o=>{R.retryBoss(o,!0)}),H.spawnCurrentEncounter(),_.playAscension(),f.emit("toast:show",{message:"🔥 Boss Surge Active: +25% DMG!",type:"epic"}),this.updateStageHeader())});return}if(a.closest("#ascendQuickBtn")){f.emit("screen:change",{screenId:"ascension"});return}if(a.closest("#goldenSpiritOrb")){Te.claimEvent();return}if(a.closest("#viewAllQuestsBtn")){f.emit("screen:change",{screenId:"quests"});return}if(a.closest("#tabBuildingsBtn")){this.activeCategory!=="buildings"&&(this.activeCategory="buildings",this.updateTabStyles(),this.buildListDOM(),this.updateList());return}if(a.closest("#tabUpgradesBtn")){this.activeCategory!=="upgrades"&&(this.activeCategory="upgrades",this.updateTabStyles(),this.buildListDOM(),this.updateList());return}const i=a.closest(".buy-mult-btn");if(i){const n=i.dataset.mult;this.buyMultiplier=n==="max"?"max":Number(n),_.playTap(),this.updateMultiplierStyles(),this.updateList();return}}),this.buildListDOM(),this.update()}updateTabStyles(){const e=this.el.querySelector("#tabBuildingsBtn"),t=this.el.querySelector("#tabUpgradesBtn");e&&(e.style.borderColor=this.activeCategory==="buildings"?"#f59e0b":"var(--border-subtle)",e.style.background=this.activeCategory==="buildings"?"rgba(245,158,11,0.2)":"rgba(30,41,59,0.5)",e.style.color=this.activeCategory==="buildings"?"#fde047":"var(--text-muted)"),t&&(t.style.borderColor=this.activeCategory==="upgrades"?"#38bdf8":"var(--border-subtle)",t.style.background=this.activeCategory==="upgrades"?"rgba(56,189,248,0.2)":"rgba(30,41,59,0.5)",t.style.color=this.activeCategory==="upgrades"?"#7dd3fc":"var(--text-muted)")}updateMultiplierStyles(){this.el.querySelectorAll(".buy-mult-btn").forEach(e=>{const t=e,s=t.dataset.mult,a=s==="max"&&this.buyMultiplier==="max"||Number(s)===this.buyMultiplier;t.classList.toggle("active",a),t.style.background=a?"#f59e0b":"transparent",t.style.color=a?"#000":"var(--text-muted)"})}update(){this.updateStageHeader(),this.updateList(),this.updateNextGoal()}updateStageHeader(){const e=d.get();R.ensureCampaignState(e);const t=R.getCurrentStage(e),s=Me(t.worldId),a=this.el.querySelector("#campaignWorldTitle"),i=this.el.querySelector("#campaignStageTitle"),n=this.el.querySelector("#campaignModeBadge"),o=this.el.querySelector("#autoAdvanceToggleBtn");if(a&&(a.textContent=`${u("campaign.world").toUpperCase()} ${t.worldId} — ${s?u(s.nameKey).toUpperCase():"UNKNOWN"}`),i&&(i.textContent=`${u("campaign.stage")} ${t.id} ${t.isBoss?"👑":""}`),n){const c=e.campaign.campaignMode;n.textContent=u(`campaign.mode_${c}`).toUpperCase(),c==="rush"?(n.style.background="rgba(239,68,68,0.3)",n.style.color="#f87171",n.style.borderColor="#ef4444"):c==="farm"?(n.style.background="rgba(16,185,129,0.3)",n.style.color="#34d399",n.style.borderColor="#10b981"):c==="boss_blocked"?(n.style.background="rgba(245,158,11,0.3)",n.style.color="#fbbf24",n.style.borderColor="#f59e0b"):(n.style.background="rgba(56,189,248,0.2)",n.style.color="#38bdf8",n.style.borderColor="#0284c7")}const l=this.el.querySelector("#bossRetryContainer");l&&(l.style.display=e.campaign.campaignMode==="boss_blocked"?"flex":"none"),o&&(o.textContent=e.campaign.autoAdvance?u("campaign.auto_advance_on"):u("campaign.auto_advance_off"),o.style.background=e.campaign.autoAdvance?"rgba(16,185,129,0.2)":"rgba(100,116,139,0.2)",o.style.borderColor=e.campaign.autoAdvance?"#10b981":"#64748b",o.style.color=e.campaign.autoAdvance?"#34d399":"#94a3b8"),this.updateProgressStrip(t.stageNumber,s?.stageCount||10)}updateProgressStrip(e,t){const s=this.el.querySelector("#stageNodeStrip");if(!s)return;let a="";for(let i=1;i<=t;i++){const n=i<e,o=i===e,l=i===t,c=i===Math.floor(t/2);a+=`<span style="color:${n?"#10b981":o?"#fde047":"#64748b"}; font-weight:bold; font-size:${o?"13px":"11px"};">${l?"☠":c?"◆":"●"}</span>`,i<t&&(a+=`<span style="color:${n?"#10b981":"#334155"}; font-size:10px;">━</span>`)}s.innerHTML=a}updateNextGoal(){const e=d.get(),t=I.calculateMetrics(e),s=O(e.rankId),a=le(e.rankId),i=this.el.querySelector("#stagePowerNumber"),n=this.el.querySelector("#stagePowerRate"),o=this.el.querySelector("#stageComboDisplay"),l=this.el.querySelector("#stageRankName"),c=this.el.querySelector("#stageProgressPct"),m=this.el.querySelector("#stageProgressBar"),g=this.el.querySelector("#nextGoalText"),h=this.el.querySelector("#ascendQuickBtn"),y=this.el.querySelector("#goldenSpiritOrb");if(i&&(i.textContent=x.format(e.power)),n&&(n.textContent=`+${x.format(t.passivePowerPerSec)} / sec`),o&&(e.combo&&e.combo.count>0&&e.combo.timer>0?(o.style.display="block",o.textContent=`🔥 COMBO ×${e.combo.multiplier.toFixed(1)} (${e.combo.count} hits)`):o.style.display="none"),l&&(l.textContent=u(s.nameKey)),a){const w=a.reqPower,S=Math.min(100,Math.floor(e.power/w*100));g&&(g.textContent=`${u(a.nameKey)} (${S}%)`),c&&(c.textContent=`${S}%`),m&&(m.style.width=`${S}%`),h&&(e.power>=w?(h.style.display="block",h.innerHTML=`✨ ${u("ascend.ready")}`):h.style.display="none")}else g&&(g.textContent="MAX RANK"),c&&(c.textContent="100%"),m&&(m.style.width="100%"),h&&(h.style.display="none");y&&(y.style.display=e.randomEvent?.active?"flex":"none");const v=this.el.querySelector("#homeQuickQuests");if(v){const w=xe.find(S=>!e.completedQuests.includes(S.id));if(w){const S=Math.min(w.targetCount,w.getProgress(e)),$=Math.floor(S/w.targetCount*100),M=S>=w.targetCount;v.innerHTML=`
          <div style="background:rgba(17,24,39,0.9); border:1px solid ${M?"#fde047":"var(--border-subtle)"}; border-radius:var(--radius-sm); padding:8px 10px; display:flex; flex-direction:column; gap:4px; box-shadow:${M?"0 0 12px rgba(253,224,71,0.3)":"none"};">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <span style="font-weight:bold; font-size:12px; color:var(--text-main);">${u(w.nameKey)}</span>
              <span style="font-size:10px; color:${M?"#fde047":"#94a3b8"}; font-weight:bold;">${S}/${w.targetCount} (${$}%)</span>
            </div>
            <div style="width:100%; height:4px; background:rgba(30,41,59,0.8); border-radius:var(--radius-full); overflow:hidden;">
              <div style="width:${$}%; height:100%; background:${M?"#fde047":"#f59e0b"}; transition:width 0.2s ease;"></div>
            </div>
            ${M?`
              <button class="quick-claim-btn" data-quest="${w.id}" style="margin-top:4px; padding:4px 8px; font-size:11px; font-weight:bold; background:linear-gradient(135deg, #d97706, #f59e0b); color:#000; border:none; border-radius:4px; cursor:pointer;">
                🎁 ${u("btn.claim")}${w.reward?.gold?` (+${w.reward.gold}🪙)`:""}
              </button>
            `:""}
          </div>
        `;const A=v.querySelector(".quick-claim-btn");A&&A.addEventListener("click",q=>{q.stopPropagation(),Ne.claimQuest(w.id),_.playClaim()})}}}buildListDOM(){const e=this.el.querySelector("#homeListContainer");if(!e)return;const t=d.get();this.renderedCategory=this.activeCategory,this.renderedRankIndex=t.rankIndex,e.innerHTML="",this.activeCategory==="buildings"?oe.forEach(s=>{if(t.rankIndex<s.requiredRankIndex){if(s.requiredRankIndex===t.rankIndex+1){const n=document.createElement("div");n.className="building-card-locked",n.style.cssText=`
              display: flex;
              align-items: center;
              gap: 10px;
              background: rgba(15, 23, 42, 0.5);
              border: 1px dashed var(--border-subtle);
              border-radius: var(--radius-md);
              padding: 8px 12px;
              opacity: 0.6;
            `,n.innerHTML=`
              <div style="font-size:20px; width:38px; height:38px; display:flex; align-items:center; justify-content:center; background:rgba(30,41,59,0.4); border-radius:var(--radius-sm);">
                🔒
              </div>
              <div style="flex:1;">
                <div style="font-weight:bold; font-size:12px; color:var(--text-muted);">
                  ${u(s.nameKey)}
                </div>
                <div style="font-size:10px; color:#f59e0b;">
                  🔒 ${u("sect.unlocked_rank")||"Unlocks at Rank"} ${s.requiredRankIndex+1}
                </div>
              </div>
            `,e.appendChild(n)}return}const a=document.createElement("div");a.className="building-card",a.id=`bcard_${s.id}`,a.style.cssText=`
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(17, 24, 39, 0.85);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-md);
          padding: 8px 12px;
          transition: all 0.15s ease;
        `,a.innerHTML=`
          <div style="display:flex; align-items:center; gap:10px; flex:1;">
            <div style="font-size:24px; width:40px; height:40px; display:flex; align-items:center; justify-content:center; background:radial-gradient(circle, rgba(245,158,11,0.15), rgba(30,41,59,0.8)); border-radius:var(--radius-sm); border:1px solid rgba(245,158,11,0.3); box-shadow:0 0 8px rgba(0,0,0,0.5);">
              ${s.icon}
            </div>
            <div style="flex:1;">
              <div style="display:flex; align-items:center; justify-content:space-between; margin-right:8px;">
                <span style="font-weight:bold; font-size:13px; color:var(--text-main); display:flex; align-items:center; gap:4px;">
                  ${u(s.nameKey)} <span class="b-owned" style="font-size:12px; color:#fde047; font-weight:bold;">×0</span>
                  <span class="b-best-value" style="display:none; font-size:9px; background:linear-gradient(90deg, #f59e0b, #ef4444); color:#000; font-weight:900; padding:1px 5px; border-radius:3px; letter-spacing:0.5px;">⭐ BEST</span>
                </span>
                <span class="b-contrib" style="font-size:10px; color:#38bdf8; font-weight:bold;"></span>
              </div>
              <div style="font-size:11px; color:var(--text-muted); display:flex; gap:6px; align-items:center;">
                <span class="b-rate">+0/s</span>
                <span class="b-milestone" style="color:#10b981; font-size:10px; font-weight:bold;"></span>
              </div>
            </div>
          </div>

          <button class="buy-building-action-btn" data-building-id="${s.id}" style="
            min-width: 84px;
            height: 38px;
            background: rgba(51, 65, 85, 0.5);
            border: 1px solid transparent;
            border-radius: var(--radius-sm);
            color: #64748b;
            font-weight: bold;
            font-size: 11px;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
          ">
            <span class="btn-count">+1</span>
            <span class="btn-cost" style="font-size:10px;">🪙 0</span>
          </button>
        `,a.querySelector(".buy-building-action-btn").addEventListener("click",n=>{n.preventDefault(),this.executeBuildingPurchase(s.id)}),e.appendChild(a)}):qe.forEach(s=>{if(t.rankIndex<s.requiredRankIndex||s.unlockCheck&&!s.unlockCheck(t))return;const a=document.createElement("div");a.className="upgrade-card",a.id=`ucard_${s.id}`,a.style.cssText=`
          display: flex;
          align-items: center;
          justify-content: space-between;
          background: rgba(17, 24, 39, 0.85);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-md);
          padding: 8px 12px;
        `,a.innerHTML=`
          <div style="display:flex; align-items:center; gap:10px;">
            <div style="font-size:22px; width:36px; height:36px; display:flex; align-items:center; justify-content:center; background:rgba(30,41,59,0.7); border-radius:var(--radius-sm);">
              ${s.icon}
            </div>
            <div>
              <div style="font-weight:bold; font-size:12px; color:var(--text-main);">
                ${u(s.nameKey)} <span class="u-lvl" style="font-size:11px; color:#38bdf8;">Lv.0/${s.maxLevel}</span>
              </div>
              <div style="font-size:10px; color:var(--text-muted);">
                ${u(s.descKey)}
              </div>
            </div>
          </div>

          <button class="buy-upg-action-btn" data-upgrade-id="${s.id}" style="
            min-width: 80px;
            height: 36px;
            background: rgba(51, 65, 85, 0.5);
            border: 1px solid transparent;
            border-radius: var(--radius-sm);
            color: #64748b;
            font-weight: bold;
            font-size: 11px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
          ">
            <span class="upg-cost">🪙 0</span>
          </button>
        `,a.querySelector(".buy-upg-action-btn").addEventListener("click",n=>{n.preventDefault(),this.executeUpgradePurchase(s.id)}),e.appendChild(a)})}updateList(){const e=d.get();(this.renderedCategory!==this.activeCategory||this.renderedRankIndex!==e.rankIndex)&&this.buildListDOM();const t=I.calculateMetrics(e),s=t.buildingCostDiscount||0;if(this.activeCategory==="buildings"){let a="",i=0;oe.forEach(n=>{if(e.rankIndex<n.requiredRankIndex)return;const o=e.buildings[n.id]||0,l=G(n,o,1,s),c=Re(o),m=n.baseProduction*c,g=l>0?m/l:0;g>i&&(i=g,a=n.id)}),oe.forEach(n=>{const o=this.el.querySelector(`#bcard_${n.id}`);if(!o)return;const l=e.buildings[n.id]||0;let c=1,m=0;if(this.buyMultiplier===1)c=1,m=G(n,l,1,s);else if(this.buyMultiplier===10)c=10,m=G(n,l,10,s);else if(this.buyMultiplier===100)c=100,m=G(n,l,100,s);else{const L=ut(n,l,e.gold,s);c=Math.max(1,L.count),m=L.totalCost>0?L.totalCost:G(n,l,1,s)}const g=e.gold>=m&&m>0,h=t.buildingDetails[n.id],y=Re(l),v=rs(l),w=o.querySelector(".b-owned"),S=o.querySelector(".b-contrib"),$=o.querySelector(".b-rate"),M=o.querySelector(".b-milestone"),A=o.querySelector(".b-best-value"),q=o.querySelector(".btn-count"),j=o.querySelector(".btn-cost"),P=o.querySelector(".buy-building-action-btn");w&&(w.innerText=`×${l}`),S&&(S.innerText=h&&h.contributionPct>0?`${h.contributionPct}%`:""),$&&($.innerText=`+${x.format(h?h.totalBuildingPowerPerSec:n.baseProduction*y)}/s`),M&&(v?M.innerText=`[${l}/${v.target}] (×${v.multiplier.toFixed(1)})`:M.innerText=`(×${y.toFixed(1)})`),A&&(A.style.display=n.id===a&&l>0?"inline-block":"none"),q&&(q.innerText=`+${c}`),j&&(j.innerText=`🪙 ${x.format(m)}`),P&&(P.style.background=g?"linear-gradient(135deg, #d97706, #f59e0b)":"rgba(51, 65, 85, 0.5)",P.style.borderColor=g?"#fde047":"transparent",P.style.color=g?"#000":"#64748b",P.style.cursor=g?"pointer":"not-allowed",P.style.boxShadow=g?"0 0 10px rgba(245,158,11,0.3)":"none")})}else qe.forEach(a=>{const i=this.el.querySelector(`#ucard_${a.id}`);if(!i)return;const n=e.upgrades[a.id]||0,o=n>=a.maxLevel,l=mt(a,n),c=e.gold>=l&&!o,m=i.querySelector(".u-lvl"),g=i.querySelector(".upg-cost"),h=i.querySelector(".buy-upg-action-btn");m&&(m.innerText=`Lv.${n}/${a.maxLevel}`),g&&(g.innerText=o?"MAX":`🪙 ${x.format(l)}`),h&&(o?(h.style.background="rgba(30, 41, 59, 0.5)",h.style.color="#64748b",h.style.cursor="default"):(h.style.background=c?"linear-gradient(135deg, #0284c7, #38bdf8)":"rgba(51, 65, 85, 0.5)",h.style.borderColor=c?"#38bdf8":"transparent",h.style.color=c?"#000":"#64748b",h.style.cursor=c?"pointer":"not-allowed"))})}executeBuildingPurchase(e){const t=d.get(),s=oe.find(c=>c.id===e);if(!s)return;const i=I.calculateMetrics(t).buildingCostDiscount||0,n=t.buildings[s.id]||0;let o=1,l=0;if(this.buyMultiplier===1)o=1,l=G(s,n,1,i);else if(this.buyMultiplier===10)o=10,l=G(s,n,10,i);else if(this.buyMultiplier===100)o=100,l=G(s,n,100,i);else{const c=ut(s,n,t.gold,i);o=c.count,l=c.totalCost}o<=0||t.gold<l||(d.set(c=>{c.gold-=l,c.buildings[s.id]=n+o,c.stats.totalBuildingsOwned=(c.stats.totalBuildingsOwned||0)+o}),_.playBuy(),f.emit("building:buy",{buildingId:s.id,count:o,totalCost:l}),this.updateList())}executeUpgradePurchase(e){const t=d.get(),s=qe.find(n=>n.id===e);if(!s)return;const a=t.upgrades[s.id]||0;if(a>=s.maxLevel)return;const i=mt(s,a);t.gold<i||(d.set(n=>{n.gold-=i,n.upgrades[s.id]=a+1}),_.playUpgrade(),f.emit("upgrade:buy",{upgradeId:s.id,newLevel:a+1,cost:i}),this.updateList())}render(){this.el.innerHTML=`
      <div class="home-desktop-grid">
        <!-- Left Column: Sect Buildings & Upgrades (Desktop) -->
        <div class="home-col-left" id="homeLeftCol">
          <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px; border-bottom:1px solid var(--border-subtle); padding-bottom:8px;">
            <div style="display:flex; gap:6px;">
              <button id="tabBuildingsBtn" style="padding:5px 12px; font-size:12px; font-weight:bold; border-radius:var(--radius-sm); border:1px solid ${this.activeCategory==="buildings"?"#f59e0b":"var(--border-subtle)"}; background:${this.activeCategory==="buildings"?"rgba(245,158,11,0.2)":"rgba(30,41,59,0.5)"}; color:${this.activeCategory==="buildings"?"#fde047":"var(--text-muted)"}; cursor:pointer;">
                🏯 ${u("building.title")}
              </button>
              <button id="tabUpgradesBtn" style="padding:5px 12px; font-size:12px; font-weight:bold; border-radius:var(--radius-sm); border:1px solid ${this.activeCategory==="upgrades"?"#38bdf8":"var(--border-subtle)"}; background:${this.activeCategory==="upgrades"?"rgba(56,189,248,0.2)":"rgba(30,41,59,0.5)"}; color:${this.activeCategory==="upgrades"?"#7dd3fc":"var(--text-muted)"}; cursor:pointer;">
                ⚡ ${u("upgrade.title")}
              </button>
            </div>

            <!-- Multipliers -->
            <div style="display:flex; gap:3px; background:rgba(15,23,42,0.9); padding:2px; border-radius:var(--radius-sm); border:1px solid var(--border-subtle);">
              <button class="buy-mult-btn ${this.buyMultiplier===1?"active":""}" data-mult="1" style="padding:3px 7px; font-size:11px; font-weight:bold; border-radius:4px; cursor:pointer; color:${this.buyMultiplier===1?"#000":"var(--text-muted)"}; background:${this.buyMultiplier===1?"#f59e0b":"transparent"};">1x</button>
              <button class="buy-mult-btn ${this.buyMultiplier===10?"active":""}" data-mult="10" style="padding:3px 7px; font-size:11px; font-weight:bold; border-radius:4px; cursor:pointer; color:${this.buyMultiplier===10?"#000":"var(--text-muted)"}; background:${this.buyMultiplier===10?"#f59e0b":"transparent"};">10x</button>
              <button class="buy-mult-btn ${this.buyMultiplier===100?"active":""}" data-mult="100" style="padding:3px 7px; font-size:11px; font-weight:bold; border-radius:4px; cursor:pointer; color:${this.buyMultiplier===100?"#000":"var(--text-muted)"}; background:${this.buyMultiplier===100?"#f59e0b":"transparent"};">100x</button>
              <button class="buy-mult-btn ${this.buyMultiplier==="max"?"active":""}" data-mult="max" style="padding:3px 7px; font-size:11px; font-weight:bold; border-radius:4px; cursor:pointer; color:${this.buyMultiplier==="max"?"#000":"var(--text-muted)"}; background:${this.buyMultiplier==="max"?"#f59e0b":"transparent"};">${u("btn.max")}</button>
            </div>
          </div>

          <div id="homeListContainer" style="display:flex; flex-direction:column; gap:8px; padding-bottom:16px;"></div>
        </div>

        <!-- Center Column: Zone A (Power/Progress) + Zone B (Progress) + Zone C (Battlefield) + Zone D (Action) -->
        <div class="home-col-center" id="battleCenterCol" style="display:flex; flex-direction:column; gap:8px; width:100%; position:relative;">
          
          <!-- Zone A / Header HUD: Power, Rate, Rank Progress & Combo -->
          <div style="background:rgba(15,23,42,0.8); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:8px 12px; display:flex; flex-direction:column; align-items:center; gap:2px; width:100%; position:relative;">
            <div style="font-size:10px; color:var(--text-muted); font-weight:bold; letter-spacing:1px; text-transform:uppercase;">
              ${u("currency.power")}
            </div>
            <div id="stagePowerNumber" style="font-family:var(--font-display); font-size:28px; font-weight:900; color:#fde047; text-shadow:0 0 16px rgba(245,158,11,0.6); line-height:1.1;">
              0
            </div>
            <div id="stagePowerRate" style="font-size:11px; color:var(--color-cyan); font-weight:600;">
              +0 / sec
            </div>
            <div id="stageComboDisplay" style="display:none; font-size:11px; color:#f43f5e; font-weight:bold; margin-top:2px;">
              🔥 COMBO ×1.0 (0 hits)
            </div>

            <!-- Rank & Progress Bar -->
            <div style="width:100%; max-width:280px; margin-top:2px;">
              <div style="display:flex; justify-content:space-between; font-size:10px; font-weight:bold; margin-bottom:2px;">
                <span id="stageRankName" style="color:var(--text-main);">Rank E</span>
                <span id="stageProgressPct" style="color:var(--color-gold);">0%</span>
              </div>
              <div style="width:100%; height:6px; background:rgba(30,41,59,0.8); border-radius:var(--radius-full); overflow:hidden; border:1px solid var(--border-subtle);">
                <div id="stageProgressBar" style="width:0%; height:100%; background:linear-gradient(90deg, #f59e0b, #fde047); border-radius:var(--radius-full); transition:width 0.2s ease;"></div>
              </div>
            </div>

            <!-- Floating Golden Spirit Orb (Random Event) -->
            <div id="goldenSpiritOrb" style="display:none; position:absolute; right:12px; top:12px; width:36px; height:36px; border-radius:50%; background:radial-gradient(circle, #fde047 0%, #f59e0b 60%, #b45309 100%); border:2px solid #ffffff; box-shadow:0 0 20px #fde047; animation:auraPulse 1s infinite; cursor:pointer; z-index:50; align-items:center; justify-content:center; font-size:18px;">
              ✨
            </div>
          </div>

          <!-- Zone B: Campaign Stage Header & Progress Strip -->
          <div style="background:rgba(15,23,42,0.8); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:8px 12px; display:flex; flex-direction:column; gap:6px;">
            <div style="display:flex; justify-content:space-between; align-items:center;">
              <div>
                <div id="campaignWorldTitle" style="font-size:10px; font-weight:bold; color:var(--text-muted); letter-spacing:1px;">WORLD 1 — WHISPERING FOREST</div>
                <div id="campaignStageTitle" style="font-size:15px; font-weight:900; color:#fde047; font-family:var(--font-display);">Stage 1-1</div>
              </div>

              <!-- Mode Badge & Controls -->
              <div style="display:flex; gap:6px; align-items:center;">
                <span id="campaignModeBadge" style="font-size:10px; font-weight:bold; padding:2px 8px; border-radius:var(--radius-full); border:1px solid #0284c7; background:rgba(56,189,248,0.2); color:#38bdf8;">PROGRESS</span>
                <button id="autoAdvanceToggleBtn" style="padding:3px 8px; font-size:10px; font-weight:bold; border-radius:var(--radius-sm); border:1px solid #10b981; background:rgba(16,185,129,0.2); color:#34d399; cursor:pointer;">AUTO ON</button>
              </div>
            </div>

            <!-- Progress Node Strip -->
            <div id="stageNodeStrip" style="display:flex; align-items:center; justify-content:center; gap:3px; padding-top:2px;"></div>

            <!-- Boss Retry CTAs (if blocked) -->
            <div id="bossRetryContainer" style="display:none; gap:6px; margin-top:2px;">
              <button id="bossRetryBtn" style="flex:1; padding:6px; font-size:11px; font-weight:bold; border-radius:var(--radius-sm); background:linear-gradient(90deg, #f59e0b, #ef4444); color:#000; cursor:pointer; border:none;">
                ⚔️ RETRY BOSS
              </button>
              <button id="bossBoostedRetryBtn" style="flex:1.2; padding:6px; font-size:11px; font-weight:bold; border-radius:var(--radius-sm); background:linear-gradient(90deg, #8b5cf6, #ec4899); color:#fff; cursor:pointer; border:none; box-shadow:0 0 10px rgba(236,72,153,0.5);">
                🔥 BOOSTED (+25% 📺)
              </button>
            </div>
          </div>

          <!-- Zone C: Battlefield Viewport Container -->
          <div id="battlefieldContainer" style="display:flex; flex-direction:column; flex:1;"></div>

          <!-- Zone D: Primary Action Controls -->
          <div style="display:flex; gap:8px; align-items:center; width:100%;">
            <!-- Primary Attack Button -->
            <button id="trainActionBtn" class="btn btn-primary" style="flex:1; padding:12px; font-size:16px; font-weight:900; font-family:var(--font-display); letter-spacing:1px; border-radius:var(--radius-md); background:linear-gradient(135deg, #f59e0b, #d97706); box-shadow:0 0 20px rgba(245,158,11,0.5); cursor:pointer; border:none; display:flex; align-items:center; justify-content:center; gap:8px;">
              <span>⚔️</span>
              <span>ATTACK</span>
            </button>

            <!-- Quick Ascension button (if ready) -->
            <button id="ascendQuickBtn" style="display:none; padding:12px 16px; font-size:13px; font-weight:bold; border-radius:var(--radius-md); background:linear-gradient(135deg, #10b981, #059669); color:#fff; border:none; cursor:pointer; box-shadow:0 0 15px rgba(16,185,129,0.5);">
              ✨ ASCEND
            </button>
          </div>
        </div>

        <!-- Right Column: Quests & Goals (Desktop) -->
        <div class="home-col-right" id="homeRightCol" style="gap:12px;">
          <!-- Next Goal Banner -->
          <div id="nextGoalBanner" style="background:rgba(30,41,59,0.7); border:1px solid var(--border-gold); border-radius:var(--radius-md); padding:8px 12px; font-size:12px; font-weight:bold; color:#fde047; display:flex; justify-content:space-between; align-items:center;">
            <span>🎯 NEXT GOAL:</span>
            <span id="nextGoalText">Rank D (0%)</span>
          </div>

          <div style="display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--border-subtle); padding-bottom:6px;">
            <div style="font-weight:bold; font-size:14px; color:#38bdf8;">
              📜 ${u("quest.title")}
            </div>
            <button id="viewAllQuestsBtn" style="font-size:11px; color:var(--color-gold); font-weight:bold; cursor:pointer; background:none; border:none;">
              View All ➔
            </button>
          </div>
          <div id="homeQuickQuests" style="display:flex; flex-direction:column; gap:6px;">
            <div style="font-size:11px; color:var(--text-muted); padding:8px; background:rgba(30,41,59,0.3); border-radius:var(--radius-sm);">
              Clear Campaign Stages and improve your Sect to earn rewards!
            </div>
          </div>

          <div style="margin-top:auto; background:rgba(30,41,59,0.5); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px; text-align:center;">
            <div style="font-size:11px; color:var(--text-muted);">${u("app.subtitle")}</div>
            <div style="font-size:10px; color:#94a3b8; margin-top:2px;">Pixel-Anime Campaign Autobattler</div>
          </div>
        </div>
      </div>
    `;const e=this.el.querySelector("#battlefieldContainer");e&&e.appendChild(this.viewport.getElement())}destroy(){typeof window<"u"&&window.removeEventListener("keydown",this.handleKeydown)}}class $s{constructor(){p(this,"el");p(this,"isDOMBuilt",!1);this.el=document.createElement("div"),this.el.className="screen-container",this.buildDOM(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.isDOMBuilt=!1,this.buildDOM(),this.update()})}buildDOM(){this.el.innerHTML=`
      <div style="padding:16px; max-width:640px; margin:0 auto; width:100%;">
        <div style="text-align:center; margin-bottom:20px;">
          <h2 style="font-family:var(--font-display); font-size:24px; color:#fde047; letter-spacing:1px;">
            🌟 ${u("nav.ascension")}
          </h2>
          <p style="color:var(--text-muted); font-size:13px;">
            ${u("app.subtitle")}
          </p>
        </div>

        <div id="ascensionCardsList" style="display:flex; flex-direction:column; gap:12px;">
          ${be.map(e=>`
            <div class="ascension-card" id="ascCard_${e.id}" style="
              background: rgba(17, 24, 39, 0.75);
              border: 1px solid var(--border-subtle);
              border-radius: var(--radius-md);
              padding: 14px;
              display: flex;
              align-items: center;
              justify-content: space-between;
              transition: all 0.2s ease;
            ">
              <div style="display:flex; align-items:center; gap:12px;">
                <div class="asc-badge" style="
                  width: 44px;
                  height: 44px;
                  border-radius: 50%;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  font-weight: 900;
                  font-size: 18px;
                  border: 2px solid ${e.color};
                  color: ${e.color};
                  background: rgba(15,23,42,0.8);
                ">
                  ${e.id}
                </div>

                <div>
                  <div style="font-weight:bold; font-size:14px; color:${e.color};">
                    ${u(e.titleKey)}
                  </div>
                  <div class="asc-desc" style="font-size:12px; color:var(--text-muted);">
                    ${u(e.descriptionKey)}
                  </div>
                  <div style="font-size:11px; color:#fde047; font-weight:bold; margin-top:2px;">
                    ${u("rank.multiplier")}: ×${e.multiplier}
                  </div>
                </div>
              </div>

              <div class="asc-action-slot">
                <!-- Dynamic status / button -->
              </div>
            </div>
          `).join("")}
        </div>
      </div>
    `,this.isDOMBuilt=!0,this.update()}update(){if(!this.isDOMBuilt)return;const e=d.get(),t=e.rankIndex;be.forEach(s=>{const a=this.el.querySelector(`#ascCard_${s.id}`);if(!a)return;const i=t>s.index,n=t===s.index,o=s.index===t+1,l=s.index>t+1,c=o&&e.power>=s.reqPower;n?(a.style.border=`2px solid ${s.color}`,a.style.background="rgba(30, 41, 59, 0.9)",a.style.boxShadow=`0 0 20px ${s.glowColor}`,a.style.opacity="1"):c?(a.style.border="2px solid #fde047",a.style.background="rgba(245, 158, 11, 0.15)",a.style.boxShadow="none",a.style.opacity="1"):(a.style.border="1px solid var(--border-subtle)",a.style.background="rgba(17, 24, 39, 0.75)",a.style.boxShadow="none",a.style.opacity=l?"0.5":"1");const m=a.querySelector(".asc-badge");m&&(m.style.color=n?"#000":s.color,m.style.background=n?s.color:"rgba(15,23,42,0.8)");const g=a.querySelector(".asc-desc");g&&(g.innerText=l?"???":u(s.descriptionKey));const h=a.querySelector(".asc-action-slot");h&&(i?h.innerHTML=`<span style="color:#10b981; font-weight:bold; font-size:12px;">✓ ${u("btn.claim")}</span>`:n?h.innerHTML=`<span style="color:#38bdf8; font-weight:bold; font-size:12px; border:1px solid #38bdf8; padding:4px 8px; border-radius:var(--radius-sm);">${u("rank.current")}</span>`:c?h.querySelector(".ascend-now-btn")||(h.innerHTML=`
              <button class="ascend-now-btn" style="
                height: 40px;
                padding: 0 16px;
                background: linear-gradient(135deg, #d97706, #f59e0b);
                border: 1px solid #fde047;
                border-radius: var(--radius-sm);
                color: #fff;
                font-weight: bold;
                font-size: 13px;
                cursor: pointer;
                animation: buttonReadyGlow 1.5s infinite;
              ">
                ${u("btn.ascend")}
              </button>
            `,h.querySelector(".ascend-now-btn")?.addEventListener("click",y=>{y.preventDefault(),Dt.ascend()})):h.innerHTML=`
            <div style="text-align:right;">
              <div style="font-size:10px; color:var(--text-muted);">${u("rank.req")}</div>
              <div style="font-size:12px; font-weight:bold; color:var(--color-gold);">
                ${x.format(s.reqPower)} ⚡
              </div>
            </div>
          `)})}}class Bs{constructor(){p(this,"el");p(this,"renderedFloor",-1);this.el=document.createElement("div"),this.el.className="screen-container",this.render(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),je.addCallback(()=>{this.el.isConnected&&this.update()}),document.addEventListener("i18n:change",()=>this.render())}render(){const e=U.getCombatState(),t=Ye(e.currentFloor);this.renderedFloor=e.currentFloor;const s=d.get();this.el.innerHTML=`
      <div style="padding:16px; max-width:640px; margin:0 auto; width:100%; display:flex; flex-direction:column; height:100%; justify-content:space-between;">
        <!-- Header / Challenge Info -->
        <div style="text-align:center; margin-bottom:12px;">
          <div style="display:flex; justify-content:center; align-items:center; gap:8px; margin-bottom:4px;">
            <span style="font-size:11px; background:rgba(234,179,8,0.15); border:1px solid rgba(234,179,8,0.4); color:#eab308; font-weight:bold; padding:2px 8px; border-radius:999px;">
              🏆 ЧЕЛЛЕНДЖ-РЕЖИМ
            </span>
            <span style="font-size:11px; background:rgba(56,189,248,0.15); border:1px solid rgba(56,189,248,0.4); color:#38bdf8; font-weight:bold; padding:2px 8px; border-radius:999px;">
              🏅 Рекорд: Этаж ${s.towerMaxFloor||1}
            </span>
          </div>

          <div id="towerWorldName" style="font-size:12px; color:${t.accentColor}; font-weight:bold; text-transform:uppercase; letter-spacing:1px;">
            ${u(t.nameKey)}
          </div>
          <h2 style="font-family:var(--font-display); font-size:24px; color:#fde047; margin:2px 0;">
            ${u("tower.title")} - ${u("tower.floor")} <span id="towerFloorNum">${e.currentFloor}</span>
          </h2>
          <div id="towerBossBadge" style="display:${e.isBoss?"inline-block":"none"}; background:#ef4444; color:#fff; font-weight:bold; font-size:11px; padding:2px 8px; border-radius:var(--radius-sm); animation:buttonReadyGlow 1s infinite;">🔥 ${u("tower.boss")}</div>
        </div>

        <!-- Meta Rewards & Milestone Banner -->
        <div style="display:flex; justify-content:space-between; align-items:center; background:rgba(15,23,42,0.8); border:1px solid rgba(255,255,255,0.08); border-radius:var(--radius-md); padding:6px 12px; margin-bottom:12px; font-size:11px;">
          <div style="color:#94a3b8; display:flex; align-items:center; gap:4px;">
            <span>💎</span><span>Награды: Кристаллы & Эссенция</span>
          </div>
          <div style="color:#eab308; font-weight:bold;">
            🎁 Бонус каждые 5 эт.
          </div>
        </div>

        <!-- Combat Arena Stage -->
        <div id="towerArenaCard" style="
          background: ${t.bgGradient};
          border: 2px solid ${e.isBoss?"#ef4444":"var(--border-subtle)"};
          border-radius: var(--radius-lg);
          padding: 24px 16px;
          display: flex;
          flex-direction: column;
          align-items: center;
          position: relative;
          box-shadow: 0 10px 30px rgba(0,0,0,0.8);
          margin-bottom: 16px;
        ">
          <!-- Combatants Row -->
          <div style="display:flex; justify-content:space-around; align-items:center; width:100%; margin-bottom:18px;">
            <!-- Player Avatar -->
            <div style="display:flex; flex-direction:column; align-items:center; gap:6px;">
              <div style="width:72px; height:72px; border-radius:50%; background:rgba(30,41,59,0.8); border:2px solid var(--color-cyan); display:flex; align-items:center; justify-content:center; font-size:36px; box-shadow:0 0 15px rgba(56,189,248,0.4); animation:heroFloat 3s infinite;">
                🥋
              </div>
              <div style="font-weight:bold; font-size:12px; color:var(--text-main);">YOU</div>
              <div id="towerPlayerDps" style="font-size:11px; color:var(--color-cyan); font-weight:bold;">120 DPS</div>
            </div>

            <!-- VS Badge -->
            <div style="font-family:var(--font-display); font-size:24px; color:#fde047; font-weight:900; text-shadow:0 0 10px rgba(245,158,11,0.6);">
              VS
            </div>

            <!-- Enemy Avatar -->
            <div style="display:flex; flex-direction:column; align-items:center; gap:6px;">
              <div id="towerEnemyIcon" style="width:72px; height:72px; border-radius:50%; background:rgba(30,41,59,0.8); border:2px solid ${e.isBoss?"#ef4444":"#94a3b8"}; display:flex; align-items:center; justify-content:center; font-size:36px; box-shadow:0 0 15px ${e.isBoss?"rgba(239,68,68,0.6)":"rgba(148,163,184,0.3)"}; animation:heroFloat 3s infinite reverse;">
                ${e.enemyIcon}
              </div>
              <div id="towerEnemyName" style="font-weight:bold; font-size:12px; color:var(--text-main);">${u(e.enemyNameKey)}</div>
              <div id="towerEnemyStats" style="font-size:11px; color:#ef4444; font-weight:bold;">HP: ${x.format(e.enemyMaxHp)}</div>
            </div>
          </div>

          <!-- Enemy Health Bar -->
          <div style="width:100%; max-width:400px; margin-bottom:8px;">
            <div style="display:flex; justify-content:space-between; font-size:11px; font-weight:bold; margin-bottom:3px;">
              <span style="color:#ef4444;">Enemy HP</span>
              <span id="towerHpText" style="color:#fde047;">${x.format(e.enemyCurrentHp)} / ${x.format(e.enemyMaxHp)}</span>
            </div>
            <div style="width:100%; height:12px; background:rgba(15,23,42,0.9); border-radius:var(--radius-full); overflow:hidden; border:1px solid var(--border-subtle);">
              <div id="towerHpBar" style="width:${Math.max(0,e.enemyCurrentHp/e.enemyMaxHp*100)}%; height:100%; background:linear-gradient(90deg, #ef4444, #f87171); transition:width 0.1s linear;"></div>
            </div>
          </div>

          <!-- Battle Timer -->
          <div style="font-size:11px; color:var(--text-muted);">
            Time Remaining: <span id="towerTimerText" style="color:#fde047; font-weight:bold;">12.0s</span>
          </div>
        </div>

        <!-- Controls (Auto-Climb + Farm/Push Mode) -->
        <div style="display:flex; gap:10px; margin-bottom:16px;">
          <button id="toggleAutoClimbBtn" style="
            flex:1;
            height:48px;
            background: ${e.isAutoClimbing?"linear-gradient(135deg, #059669, #10b981)":"rgba(51,65,85,0.6)"};
            border: 1px solid ${e.isAutoClimbing?"#34d399":"var(--border-subtle)"};
            border-radius: var(--radius-md);
            color: #ffffff;
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
          ">
            <span>⚔️</span>
            <span id="autoClimbText">${e.isAutoClimbing?u("tower.auto_climb"):"Auto Paused"}</span>
          </button>

          <button id="toggleFarmModeBtn" style="
            flex:1;
            height:48px;
            background: ${e.isFarmMode?"linear-gradient(135deg, #d97706, #f59e0b)":"rgba(51,65,85,0.6)"};
            border: 1px solid ${e.isFarmMode?"#fbbf24":"var(--border-subtle)"};
            border-radius: var(--radius-md);
            color: #ffffff;
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
          ">
            <span>${e.isFarmMode?"🔄":"🚀"}</span>
            <span id="farmModeText">${e.isFarmMode?"Фарм этажа":"Штурм рекорда"}</span>
          </button>
        </div>
      </div>
    `,this.el.querySelector("#toggleAutoClimbBtn")?.addEventListener("click",i=>{i.preventDefault(),U.toggleAutoClimb(),this.update()}),this.el.querySelector("#toggleFarmModeBtn")?.addEventListener("click",i=>{i.preventDefault(),U.toggleFarmMode(),this.update()});const a=this.el.querySelector("#towerEnemyIcon");a&&(a.style.cursor="pointer",a.addEventListener("pointerdown",i=>{i.preventDefault();const n=U.slash();if(n>0){a.style.transform="scale(0.8) translateY(10px)",setTimeout(()=>{a.style.transform=""},80);const o=a.getBoundingClientRect(),l=i.clientX||o.left+o.width/2,c=i.clientY||o.top+o.height/2;ye(()=>Promise.resolve().then(()=>ks),void 0,import.meta.url).then(m=>{m.FloatingNumbers.spawn(l,c,Math.floor(n),!1,"-")}),ye(()=>Promise.resolve().then(()=>ht),void 0,import.meta.url).then(m=>m.sound.playSlash()),this.update()}})),f.on("tower:bossDefeat",()=>{const i=this.el.querySelector("#towerArenaCard");i&&(i.classList.add("shake-active"),setTimeout(()=>i.classList.remove("shake-active"),200))}),f.on("tower:floorClear",()=>{U.getCombatState().isBoss&&ye(()=>Promise.resolve().then(()=>ht),void 0,import.meta.url).then(i=>i.sound.playBossWarning())})}update(){const e=U.getCombatState(),t=I.calculateMetrics(d.get());if(this.renderedFloor!==e.currentFloor){this.renderedFloor=e.currentFloor;const y=Ye(e.currentFloor),v=this.el.querySelector("#towerWorldName"),w=this.el.querySelector("#towerBossBadge"),S=this.el.querySelector("#towerArenaCard");v&&(v.textContent=u(y.nameKey),v.style.color=y.accentColor),w&&(w.style.display=e.isBoss?"inline-block":"none"),S&&(S.style.background=y.bgGradient,S.style.borderColor=e.isBoss?"#ef4444":"var(--border-subtle)")}const s=this.el.querySelector("#towerFloorNum"),a=this.el.querySelector("#towerPlayerDps"),i=this.el.querySelector("#towerEnemyIcon"),n=this.el.querySelector("#towerEnemyName"),o=this.el.querySelector("#towerEnemyStats"),l=this.el.querySelector("#towerHpText"),c=this.el.querySelector("#towerHpBar"),m=this.el.querySelector("#towerTimerText");if(s&&(s.textContent=String(e.currentFloor)),a&&(a.textContent=`${x.format(t.towerCombatPower)} DPS`),i&&(i.textContent=e.enemyIcon),n&&(n.textContent=u(e.enemyNameKey)),o&&(o.textContent=`HP: ${x.format(e.enemyMaxHp)}`),l&&(l.textContent=`${x.format(e.enemyCurrentHp)} / ${x.format(e.enemyMaxHp)}`),c){const y=Math.max(0,Math.min(100,e.enemyCurrentHp/e.enemyMaxHp*100));c.style.width=`${y}%`}m&&(m.textContent=`${e.battleTimer.toFixed(1)}s`);const g=this.el.querySelector("#toggleAutoClimbBtn"),h=this.el.querySelector("#autoClimbText");h&&(h.textContent=e.isAutoClimbing?u("tower.auto_climb"):"Auto Paused"),g&&(g.style.background=e.isAutoClimbing?"linear-gradient(135deg, #059669, #10b981)":"rgba(51,65,85,0.6)",g.style.borderColor=e.isAutoClimbing?"#34d399":"var(--border-subtle)")}}class Ps{constructor(){p(this,"el");p(this,"isDOMBuilt",!1);this.el=document.createElement("div"),this.el.className="screen-container",this.buildDOM(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.isDOMBuilt=!1,this.buildDOM()})}buildDOM(){this.el.innerHTML=`
      <div style="padding:16px; max-width:760px; margin:0 auto; width:100%;">
        <!-- Header -->
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; border-bottom:1px solid var(--border-subtle); padding-bottom:10px;">
          <div>
            <h2 id="heroesHeaderTitle" style="font-family:var(--font-display); font-size:22px; color:#fde047;">
              👥 ${u("nav.heroes")} (0 / ${he.length})
            </h2>
            <p style="color:var(--text-muted); font-size:12px;">
              ${u("currency.essence")}: <b id="heroesEssenceDisplay" style="color:#c084fc;">0 ✨</b>
            </p>
          </div>
        </div>

        <!-- Heroes Grid -->
        <div id="heroesGrid" style="display:grid; grid-template-columns:repeat(auto-fill, minmax(180px, 1fr)); gap:12px;">
          ${he.map(e=>{const t=K[e.rarity];return`
              <div class="hero-card" id="hcard_${e.id}" style="
                background: rgba(15, 23, 42, 0.5);
                border: 2px solid var(--border-subtle);
                border-radius: var(--radius-md);
                padding: 12px;
                display: flex;
                flex-direction: column;
                align-items: center;
                text-align: center;
                opacity: 0.45;
                position: relative;
                transition: all 0.2s ease;
              ">
                <!-- Rarity Badge -->
                <div style="position:absolute; top:6px; left:8px; font-size:10px; font-weight:bold; color:${t.color}; text-transform:uppercase;">
                  ${u(t.nameKey)}
                </div>

                <!-- Avatar Artwork -->
                <div class="h-avatar" style="width:64px; height:64px; border-radius:50%; background:rgba(30,41,59,0.8); border:2px solid ${t.color}; display:flex; align-items:center; justify-content:center; font-size:32px; margin:14px 0 6px 0;">
                  ❓
                </div>

                <!-- Name & Title -->
                <div style="font-weight:bold; font-size:13px; color:var(--text-main);">${u(e.nameKey)}</div>
                <div class="h-title" style="font-size:10px; color:var(--text-muted); margin-bottom:6px;">Locked</div>

                <!-- Star Rating -->
                <div class="h-stars" style="font-size:12px; color:#fde047; margin-bottom:6px;">
                  ☆☆☆☆☆
                </div>

                <!-- Modifier description -->
                <div class="h-bonus" style="font-size:11px; color:#38bdf8; font-weight:bold; margin-bottom:10px;">
                  ???
                </div>

                <!-- Action Slot -->
                <div class="h-action" style="width:100%;">
                  <div style="font-size:11px; color:var(--text-dim);">${u("btn.locked")}</div>
                </div>
              </div>
            `}).join("")}
        </div>
      </div>
    `,this.isDOMBuilt=!0,this.update()}update(){if(!this.isDOMBuilt)return;const e=d.get(),t=Object.keys(e.heroes).length,s=this.el.querySelector("#heroesHeaderTitle"),a=this.el.querySelector("#heroesEssenceDisplay");s&&(s.innerHTML=`👥 ${u("nav.heroes")} (${t} / ${he.length})`),a&&(a.innerHTML=`${x.format(e.essence)} ✨`),he.forEach(i=>{const n=this.el.querySelector(`#hcard_${i.id}`);if(!n)return;const o=e.heroes[i.id],l=!!o,c=K[i.rarity],m=o?o.stars:0,g=at(m),h=Math.floor(i.modifier.baseValue*g*100),y=l?At(m,i.rarity):0,v=l&&m<5&&e.essence>=y;n.style.background=l?"rgba(17, 24, 39, 0.9)":"rgba(15, 23, 42, 0.5)",n.style.borderColor=l?c.color:"var(--border-subtle)",n.style.boxShadow=l?`0 0 15px ${c.glow}`:"none",n.style.opacity=l?"1":"0.45";const w=n.querySelector(".h-avatar"),S=n.querySelector(".h-title"),$=n.querySelector(".h-stars"),M=n.querySelector(".h-bonus"),A=n.querySelector(".h-action");if(w&&(w.innerText=l?"🥋":"❓"),S&&(S.innerText=l?u(i.titleKey):"Locked"),$&&($.innerText=l?"⭐".repeat(m):"☆☆☆☆☆"),M&&(M.innerText=l?`+${h}% ${i.modifier.type.replace("_pct","").toUpperCase()}`:"???"),A)if(l&&m<5)if(!A.querySelector(".star-up-btn"))A.innerHTML=`
              <button class="star-up-btn" style="
                width: 100%;
                height: 32px;
                background: ${v?"linear-gradient(135deg, #7c3aed, #a855f7)":"rgba(51,65,85,0.5)"};
                border: 1px solid ${v?"#c084fc":"transparent"};
                border-radius: var(--radius-sm);
                color: ${v?"#fff":"#64748b"};
                font-size: 11px;
                font-weight: bold;
                cursor: pointer;
              ">
                ⭐ UP (${y} ✨)
              </button>
            `,A.querySelector(".star-up-btn")?.addEventListener("click",q=>{q.preventDefault(),Y.upgradeHeroStars(i.id)});else{const q=A.querySelector(".star-up-btn");q.innerText=`⭐ UP (${y} ✨)`,q.style.background=v?"linear-gradient(135deg, #7c3aed, #a855f7)":"rgba(51,65,85,0.5)",q.style.borderColor=v?"#c084fc":"transparent",q.style.color=v?"#fff":"#64748b"}else l?A.innerHTML='<div style="font-size:11px; color:#fde047; font-weight:bold;">MAX STARS</div>':A.innerHTML=`<div style="font-size:11px; color:var(--text-dim);">${u("btn.locked")}</div>`})}}class Ds{constructor(){p(this,"el");p(this,"isDOMBuilt",!1);p(this,"timerId");this.el=document.createElement("div"),this.el.className="screen-container",this.buildDOM(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.isDOMBuilt=!1,this.buildDOM()})}buildDOM(){this.el.innerHTML=`
      <div style="padding:16px; max-width:580px; margin:0 auto; width:100%; display:flex; flex-direction:column; align-items:center; height:100%; justify-content:space-between;">
        <!-- Header -->
        <div style="text-align:center;">
          <h2 style="font-family:var(--font-display); font-size:24px; color:#fde047;">
            🔮 ${u("nav.summon")}
          </h2>
          <p style="color:var(--text-muted); font-size:12px;">
            ${u("currency.crystals")}: <b id="summonCrystalsDisplay" style="color:#38bdf8;">0 💎</b>
          </p>
        </div>

        <!-- Portal Artwork Visual -->
        <div style="position:relative; width:220px; height:220px; display:flex; align-items:center; justify-content:center; margin:16px 0;">
          <svg style="position:absolute; width:100%; height:100%; animation:celestialRotate 12s linear infinite;" viewBox="0 0 200 200">
            <circle cx="100" cy="100" r="90" fill="none" stroke="#a855f7" stroke-width="2" stroke-dasharray="12 8" opacity="0.6" />
            <circle cx="100" cy="100" r="75" fill="none" stroke="#38bdf8" stroke-width="2" stroke-dasharray="20 12" opacity="0.8" />
            <circle cx="100" cy="100" r="60" fill="none" stroke="#f59e0b" stroke-width="1.5" opacity="0.4" />
          </svg>
          <div style="width:140px; height:140px; border-radius:50%; background:radial-gradient(circle, #7c3aed 0%, #1e1b4b 70%, #030712 100%); display:flex; align-items:center; justify-content:center; box-shadow:0 0 35px rgba(168,85,247,0.6); animation:heroFloat 3s ease-in-out infinite;">
            <span style="font-size:64px;">🌌</span>
          </div>
        </div>

        <!-- Rates Table -->
        <div style="width:100%; background:rgba(30,41,59,0.5); border:1px solid var(--border-subtle); border-radius:var(--radius-md); padding:10px 14px; margin-bottom:16px;">
          <div style="font-size:11px; font-weight:bold; color:var(--text-muted); margin-bottom:6px; text-transform:uppercase;">
            Drop Probabilities & Essence:
          </div>
          <div style="display:flex; justify-content:space-between; font-size:11px;">
            <span style="color:#f43f5e; font-weight:bold;">Mythic: 0.5%</span>
            <span style="color:#fbbf24; font-weight:bold;">Legendary: 3.5%</span>
            <span style="color:#c084fc; font-weight:bold;">Epic: 11%</span>
            <span style="color:#38bdf8; font-weight:bold;">Rare: 30%</span>
            <span style="color:#94a3b8; font-weight:bold;">Common: 55%</span>
          </div>
        </div>

        <!-- Action Buttons (1x & 10x) -->
        <div style="display:flex; flex-direction:column; gap:12px; width:100%; margin-bottom:16px;">
          <div style="display:flex; gap:12px; width:100%;">
            <button id="summon1Btn" style="
              flex:1;
              height:50px;
              background: rgba(51,65,85,0.5);
              border: 1px solid transparent;
              border-radius: var(--radius-md);
              color: #64748b;
              font-weight: bold;
              font-size: 14px;
              cursor: pointer;
            ">
              <div>${u("btn.summon_1")}</div>
              <div style="font-size:11px; color:#38bdf8;">100 💎</div>
            </button>

            <button id="summon10Btn" style="
              flex:1;
              height:50px;
              background: rgba(51,65,85,0.5);
              border: 1px solid transparent;
              border-radius: var(--radius-md);
              color: #64748b;
              font-weight: bold;
              font-size: 14px;
              cursor: pointer;
            ">
              <div>${u("btn.summon_10")}</div>
              <div style="font-size:11px; color:#fde047;">900 💎 (10% OFF)</div>
            </button>
          </div>
          <button id="summonAdBtn" style="
            width:100%;
            height:44px;
            background: linear-gradient(135deg, #059669, #10b981);
            border: 2px solid #34d399;
            border-radius: var(--radius-md);
            color: #ffffff;
            font-weight: bold;
            font-size: 14px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            box-shadow: 0 4px 15px rgba(16,185,129,0.3);
          ">
            <span>🎬</span>
            <span>Free Summon</span>
            <span id="summonAdCooldown" style="font-size:11px; color:#a7f3d0; margin-left:8px;"></span>
          </button>
        </div>
      </div>
    `,this.el.querySelector("#summon1Btn")?.addEventListener("click",e=>{e.preventDefault();const t=Y.summon(1);t&&f.emit("modal:open",{modalId:"summon_result",data:{results:t}})}),this.el.querySelector("#summon10Btn")?.addEventListener("click",e=>{e.preventDefault();const t=Y.summon(10);t&&f.emit("modal:open",{modalId:"summon_result",data:{results:t}})}),this.el.querySelector("#summonAdBtn")?.addEventListener("click",e=>{e.preventDefault(),this.executeFreeAdSummon()}),this.isDOMBuilt=!0,this.update()}async executeFreeAdSummon(){const e=d.get();Date.now()-e.lastFreeSummonAdAt<5*60*1e3||ye(()=>Promise.resolve().then(()=>xs),void 0,import.meta.url).then(async s=>{if(await s.adService.showRewardedAd("free_summon")){d.set(n=>{n.lastFreeSummonAdAt=Date.now()});const i=Y.summon(1,!0);i&&f.emit("modal:open",{modalId:"summon_result",data:{results:i}})}})}update(){if(!this.isDOMBuilt)return;const e=d.get(),t=e.crystals>=100,s=e.crystals>=900,a=this.el.querySelector("#summonCrystalsDisplay");a&&(a.innerHTML=`${e.crystals} 💎`);const i=this.el.querySelector("#summon1Btn"),n=this.el.querySelector("#summon10Btn");i&&(i.style.background=t?"linear-gradient(135deg, #7c3aed, #9333ea)":"rgba(51,65,85,0.5)",i.style.borderColor=t?"#c084fc":"transparent",i.style.color=t?"#ffffff":"#64748b",i.style.boxShadow=t?"0 0 15px rgba(147,51,234,0.4)":"none"),n&&(n.style.background=s?"linear-gradient(135deg, #d97706, #f59e0b)":"rgba(51,65,85,0.5)",n.style.borderColor=s?"#fde047":"transparent",n.style.color=s?"#ffffff":"#64748b",n.style.boxShadow=s?"0 0 15px rgba(245,158,11,0.4)":"none");const o=this.el.querySelector("#summonAdBtn"),l=this.el.querySelector("#summonAdCooldown");if(o&&l){const m=Date.now()-e.lastFreeSummonAdAt,g=5*60*1e3;if(m<g){o.disabled=!0,o.style.filter="grayscale(100%)",o.style.opacity="0.5";const h=Math.ceil((g-m)/1e3),y=Math.floor(h/60),v=h%60;l.innerText=`(${y}:${v.toString().padStart(2,"0")})`,this.timerId||(this.timerId=window.setInterval(()=>this.update(),1e3))}else o.disabled=!1,o.style.filter="none",o.style.opacity="1",l.innerText="",this.timerId&&(clearInterval(this.timerId),this.timerId=void 0)}}}class Ls{constructor(){p(this,"el");p(this,"isDOMBuilt",!1);this.el=document.createElement("div"),this.el.className="screen-container",this.buildDOM(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.isDOMBuilt=!1,this.buildDOM()})}buildDOM(){this.el.innerHTML=`
      <div style="padding:16px; max-width:680px; margin:0 auto; width:100%;">
        <!-- Reincarnation Banner Card -->
        <div style="
          background: radial-gradient(circle at center, rgba(225,29,72,0.2) 0%, rgba(15,23,42,0.9) 100%);
          border: 2px solid #f43f5e;
          border-radius: var(--radius-lg);
          padding: 16px;
          margin-bottom: 20px;
          box-shadow: 0 0 25px rgba(244,63,94,0.3);
          text-align: center;
        ">
          <h2 style="font-family:var(--font-display); font-size:22px; color:#f43f5e; margin-bottom:4px;">
            ⚡ ${u("soul.title")}
          </h2>
          <p style="color:var(--text-muted); font-size:12px; margin-bottom:12px;">
            ${u("soul.desc")}
          </p>

          <div style="display:flex; justify-content:space-around; align-items:center; margin-bottom:14px;">
            <div>
              <div style="font-size:11px; color:var(--text-muted);">${u("currency.souls")} (Owned)</div>
              <div id="soulOwnedDisplay" style="font-size:20px; font-weight:bold; color:#f43f5e;">0 ⚡</div>
            </div>
            <div>
              <div style="font-size:11px; color:var(--text-muted);">Reset Reward</div>
              <div id="soulPotentialDisplay" style="font-size:20px; font-weight:bold; color:#fde047;">+0 ⚡</div>
            </div>
          </div>

          <button id="openReincarnateModalBtn" style="
            width: 100%;
            max-width: 320px;
            height: 44px;
            background: rgba(51,65,85,0.5);
            border: 1px solid transparent;
            border-radius: var(--radius-md);
            color: #64748b;
            font-weight: bold;
            font-size: 14px;
            cursor: pointer;
          ">
            Requires Rank S (1M Power)
          </button>
        </div>

        <!-- Soul Skills List -->
        <h3 style="font-family:var(--font-display); font-size:18px; color:#fde047; margin-bottom:12px;">
          ✨ Permanent Soul Mastery
        </h3>

        <div id="soulSkillsList" style="display:flex; flex-direction:column; gap:10px;">
          ${$e.map(e=>`
            <div class="soul-skill-card" id="scard_${e.id}" style="
              background: rgba(17, 24, 39, 0.85);
              border: 1px solid var(--border-subtle);
              border-radius: var(--radius-md);
              padding: 12px;
              display: flex;
              align-items: center;
              justify-content: space-between;
            ">
              <div style="display:flex; align-items:center; gap:12px;">
                <div style="font-size:24px; width:40px; height:40px; border-radius:var(--radius-sm); background:rgba(30,41,59,0.7); display:flex; align-items:center; justify-content:center;">
                  ${e.icon}
                </div>
                <div>
                  <div style="font-weight:bold; font-size:13px; color:var(--text-main);">
                    ${u(e.nameKey)} <span class="s-lvl" style="color:#f43f5e; font-size:11px;">Lv.0 / ${e.maxLevel}</span>
                  </div>
                  <div style="font-size:11px; color:var(--text-muted);">
                    ${u(e.descKey)}
                  </div>
                </div>
              </div>

              <button class="buy-soul-action-btn" data-skill="${e.id}" style="
                min-width: 80px;
                height: 38px;
                background: rgba(51,65,85,0.5);
                border: 1px solid transparent;
                border-radius: var(--radius-sm);
                color: #64748b;
                font-weight: bold;
                font-size: 12px;
                cursor: pointer;
              ">
                1 ⚡
              </button>
            </div>
          `).join("")}
        </div>
      </div>
    `,this.el.querySelector("#openReincarnateModalBtn")?.addEventListener("click",e=>{e.preventDefault(),fe.canReincarnate()&&f.emit("modal:open",{modalId:"reincarnate"})}),this.el.querySelectorAll(".buy-soul-action-btn").forEach(e=>{e.addEventListener("click",t=>{t.preventDefault();const s=t.currentTarget.getAttribute("data-skill");s&&fe.buySoulSkill(s)})}),this.isDOMBuilt=!0,this.update()}update(){if(!this.isDOMBuilt)return;const e=d.get(),t=fe.getPotentialSouls(),s=fe.canReincarnate(),a=this.el.querySelector("#soulOwnedDisplay"),i=this.el.querySelector("#soulPotentialDisplay"),n=this.el.querySelector("#openReincarnateModalBtn");a&&(a.innerHTML=`${e.souls} ⚡`),i&&(i.innerHTML=`+${t} ⚡`),n&&(s?(n.innerText=u("btn.reincarnate"),n.style.background="linear-gradient(135deg, #e11d48, #be123c)",n.style.borderColor="#f43f5e",n.style.color="#ffffff",n.style.boxShadow="0 0 15px rgba(225,29,72,0.4)"):(n.innerText="Requires Rank S (1M Power)",n.style.background="rgba(51,65,85,0.5)",n.style.borderColor="transparent",n.style.color="#64748b",n.style.boxShadow="none")),$e.forEach(o=>{const l=this.el.querySelector(`#scard_${o.id}`);if(!l)return;const c=e.soulSkills[o.id]||0,m=Tt(o,c),g=c>=o.maxLevel,h=e.souls>=m&&!g,y=l.querySelector(".s-lvl"),v=l.querySelector(".buy-soul-action-btn");y&&(y.innerText=`Lv.${c} / ${o.maxLevel}`),l.style.borderColor=h?"rgba(244,63,94,0.6)":"var(--border-subtle)",v&&(v.innerText=g?"MAX":`${m} ⚡`,v.style.background=g?"rgba(30,41,59,0.5)":h?"linear-gradient(135deg, #e11d48, #be123c)":"rgba(51,65,85,0.5)",v.style.borderColor=h?"#f43f5e":"transparent",v.style.color=g?"#64748b":h?"#ffffff":"#64748b")})}}class zs{constructor(){p(this,"el");p(this,"activeTab","quests");p(this,"isDOMBuilt",!1);this.el=document.createElement("div"),this.el.className="screen-container",this.buildDOM(),this.bind()}getElement(){return this.el}bind(){d.subscribe(()=>this.update()),document.addEventListener("i18n:change",()=>{this.isDOMBuilt=!1,this.buildDOM()})}buildDOM(){const e=d.get();this.el.innerHTML=`
      <div style="padding:16px; max-width:640px; margin:0 auto; width:100%;">
        <!-- Tabs Header -->
        <div style="display:flex; gap:10px; margin-bottom:16px; border-bottom:1px solid var(--border-subtle); padding-bottom:10px;">
          <button id="tabQuestsBtn" style="
            flex:1;
            height:40px;
            background: ${this.activeTab==="quests"?"rgba(245,158,11,0.2)":"rgba(30,41,59,0.5)"};
            border: 1px solid ${this.activeTab==="quests"?"#f59e0b":"var(--border-subtle)"};
            border-radius: var(--radius-md);
            color: ${this.activeTab==="quests"?"#fde047":"var(--text-muted)"};
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
          ">
            📜 ${u("quest.title")}
          </button>

          <button id="tabAchieveBtn" style="
            flex:1;
            height:40px;
            background: ${this.activeTab==="achievements"?"rgba(56,189,248,0.2)":"rgba(30,41,59,0.5)"};
            border: 1px solid ${this.activeTab==="achievements"?"#38bdf8":"var(--border-subtle)"};
            border-radius: var(--radius-md);
            color: ${this.activeTab==="achievements"?"#7dd3fc":"var(--text-muted)"};
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
          ">
            🏆 ${u("achieve.title")} (<span id="achieveCount">${e.claimedAchievements.length}</span> / ${Ke.length})
          </button>
        </div>

        <!-- Tab Content -->
        <div id="questsContentList" style="display:flex; flex-direction:column; gap:10px;">
          <!-- Items populated here -->
        </div>
      </div>
    `,this.el.querySelector("#tabQuestsBtn")?.addEventListener("click",s=>{s.preventDefault(),this.activeTab!=="quests"&&(this.activeTab="quests",this.buildDOM())}),this.el.querySelector("#tabAchieveBtn")?.addEventListener("click",s=>{s.preventDefault(),this.activeTab!=="achievements"&&(this.activeTab="achievements",this.buildDOM())});const t=this.el.querySelector("#questsContentList");this.activeTab==="quests"?xe.forEach(s=>{const a=document.createElement("div");a.className="quest-card",a.id=`qcard_${s.id}`,a.style.cssText=`
          background: rgba(17, 24, 39, 0.85);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-md);
          padding: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
        `,a.innerHTML=`
          <div style="flex:1; margin-right:12px;">
            <div style="font-weight:bold; font-size:13px; color:var(--text-main);">${u(s.nameKey)}</div>
            <div style="font-size:11px; color:var(--text-muted); margin-bottom:4px;">${u(s.descKey)}</div>
            
            <div style="display:flex; align-items:center; gap:8px;">
              <div style="flex:1; height:6px; background:rgba(30,41,59,0.8); border-radius:var(--radius-full); overflow:hidden;">
                <div class="q-bar" style="width:0%; height:100%; background:#f59e0b;"></div>
              </div>
              <span class="q-count" style="font-size:10px; color:var(--text-muted); font-weight:bold;">0 / ${s.targetCount}</span>
            </div>
          </div>

          <button class="claim-quest-action-btn" data-quest="${s.id}" style="
            min-width: 80px;
            height: 38px;
            background: rgba(51,65,85,0.5);
            border: 1px solid transparent;
            border-radius: var(--radius-sm);
            color: #64748b;
            font-weight: bold;
            font-size: 12px;
            cursor: pointer;
          ">
            0%
          </button>
        `,a.querySelector(".claim-quest-action-btn").addEventListener("click",n=>{n.preventDefault(),Ne.claimQuest(s.id)}),t.appendChild(a)}):Ke.forEach(s=>{const a=document.createElement("div");a.className="achievement-card",a.id=`acard_${s.id}`,a.style.cssText=`
          background: rgba(15, 23, 42, 0.5);
          border: 1px solid var(--border-subtle);
          border-radius: var(--radius-md);
          padding: 12px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          opacity: 0.5;
        `,a.innerHTML=`
          <div style="display:flex; align-items:center; gap:10px;">
            <div style="font-size:24px; width:38px; height:38px; border-radius:var(--radius-sm); background:rgba(30,41,59,0.7); display:flex; align-items:center; justify-content:center;">
              ${s.icon}
            </div>
            <div>
              <div style="font-weight:bold; font-size:13px; color:var(--text-main);">${u(s.nameKey)}</div>
              <div style="font-size:11px; color:var(--text-muted);">${u(s.descKey)}</div>
            </div>
          </div>

          <div class="a-status" style="font-weight:bold; font-size:12px; color:#38bdf8;">
            +${s.rewardCrystals} 💎
          </div>
        `,t.appendChild(a)}),this.isDOMBuilt=!0,this.update()}update(){if(!this.isDOMBuilt)return;const e=d.get(),t=this.el.querySelector("#achieveCount");t&&(t.innerText=`${e.claimedAchievements.length}`),this.activeTab==="quests"?xe.forEach(s=>{const a=this.el.querySelector(`#qcard_${s.id}`);if(!a)return;const i=e.completedQuests.includes(s.id),n=Math.min(s.targetCount,s.getProgress(e)),o=Math.floor(n/s.targetCount*100),l=!i&&n>=s.targetCount,c=a.querySelector(".q-bar"),m=a.querySelector(".q-count"),g=a.querySelector(".claim-quest-action-btn");c&&(c.style.width=`${o}%`,c.style.background=i?"#10b981":"#f59e0b"),m&&(m.innerText=`${n} / ${s.targetCount}`),g&&(g.innerText=i?"✓ Done":l?u("btn.claim"):`${o}%`,g.style.background=i?"rgba(30,41,59,0.5)":l?"linear-gradient(135deg, #d97706, #f59e0b)":"rgba(51,65,85,0.5)",g.style.borderColor=l?"#fde047":"transparent",g.style.color=i?"#10b981":l?"#ffffff":"#64748b")}):Ke.forEach(s=>{const a=this.el.querySelector(`#acard_${s.id}`);if(!a)return;const i=e.claimedAchievements.includes(s.id),n=s.check(e),o=a.querySelector(".a-status");a.style.opacity=i||n?"1":"0.5",a.style.borderColor=i?"#38bdf8":"var(--border-subtle)",o&&(o.innerText=i?"✓ Claimed":`+${s.rewardCrystals} 💎`,o.style.color=i?"#10b981":"#38bdf8")})}}class Hs{constructor(){p(this,"el");p(this,"unsubscribe");p(this,"lastKey","");this.el=document.createElement("div"),this.el.className="screen-container",this.el.style.padding="16px",this.unsubscribe=d.subscribe(()=>this.update())}getElement(){return this.render(),this.el}destroy(){this.unsubscribe()}update(){const e=d.get(),t=`${JSON.stringify(e.equippedRelics)}_${JSON.stringify(e.relics)}`;t!==this.lastKey&&(this.lastKey=t,this.render())}render(){const e=d.get();this.el.innerHTML=`
      <h1 style="margin-bottom: 24px; color: var(--color-gold); text-align: center;">🏺 ${u("nav.relics")}</h1>
      
      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg); margin-bottom: 24px;">
        <h2 style="margin-bottom: 16px; font-size: 16px;">Equipped Relics</h2>
        <div style="display: flex; gap: 16px; justify-content: center;">
          ${e.equippedRelics.map((t,s)=>this.renderSlot(t,s)).join("")}
        </div>
      </div>

      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg);">
        <h2 style="margin-bottom: 16px; font-size: 16px;">Inventory</h2>
        ${Object.keys(e.relics).length===0?'<div class="empty-state">No relics found yet. Defeat Tower Bosses to find them!</div>':`<div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(140px, 1fr)); gap: 12px;">
             ${Object.keys(e.relics).map(t=>this.renderInventoryItem(t)).join("")}
           </div>`}
      </div>
    `,this.el.querySelectorAll(".unequip-btn").forEach(t=>{t.addEventListener("click",s=>{const a=parseInt(s.currentTarget.dataset.slot);de.unequipRelic(a)})}),this.el.querySelectorAll(".equip-btn").forEach(t=>{t.addEventListener("click",s=>{const a=s.currentTarget.dataset.id,i=e.equippedRelics.findIndex(n=>!n);i!==-1?de.equipRelic(a,i):de.equipRelic(a,0)})})}renderSlot(e,t){if(!e)return`
        <div style="width: 80px; height: 80px; border: 2px dashed var(--border-subtle); border-radius: var(--radius-md); display: flex; align-items: center; justify-content: center; color: var(--text-muted);">
          Slot ${t+1}
        </div>
      `;const s=Ae(e);if(!s)return"";const a=d.get().relics[e];return`
      <div style="width: 80px; height: 80px; background: var(--bg-surface-raised); border: 1px solid var(--border-highlight); border-radius: var(--radius-md); display: flex; flex-direction: column; align-items: center; justify-content: center; position: relative;">
        <span style="font-size: 24px;">${s.icon}</span>
        <span style="font-size: 10px; color: var(--text-gold); font-weight: bold; margin-top: 4px;">Lv.${a.level}</span>
        <button class="unequip-btn" data-slot="${t}" style="position: absolute; top: -8px; right: -8px; background: var(--color-crimson); color: white; width: 24px; height: 24px; border-radius: 50%; font-size: 12px; font-weight: bold; border: 1px solid white;">X</button>
      </div>
    `}renderInventoryItem(e){const t=Ae(e);if(!t)return"";const s=d.get().relics[e],a=d.get().equippedRelics.includes(e);return`
      <div style="background: var(--bg-surface-raised); border: 1px solid ${a?"var(--color-cyan)":"var(--border-subtle)"}; border-radius: var(--radius-md); padding: 12px; text-align: center; display: flex; flex-direction: column; align-items: center;">
        <span style="font-size: 32px; margin-bottom: 8px;">${t.icon}</span>
        <span style="font-size: 12px; font-weight: bold; margin-bottom: 4px; line-height: 1.2;">${u(t.nameKey)}</span>
        <span style="font-size: 10px; color: var(--text-gold); margin-bottom: 12px;">Lv.${s.level} / ${t.maxLevel}</span>
        
        <div style="font-size: 9px; color: var(--text-muted); margin-bottom: 12px;">
          Dupes: ${s.duplicates} / ${s.level*2}
        </div>

        <button class="equip-btn" data-id="${e}" ${a?"disabled":""} style="background: ${a?"var(--bg-core)":"var(--color-cyan)"}; color: ${a?"var(--text-muted)":"#000"}; padding: 6px 16px; border-radius: var(--radius-full); font-size: 12px; font-weight: bold; transition: opacity 0.2s;">
          ${a?"Equipped":"Equip"}
        </button>
      </div>
    `}}const tt=[{id:"scout_forest",nameKey:"expedition_scout_forest",durationHours:2,rewards:{crystals:50,essence:10,goldEquivalentMinutes:15}},{id:"explore_ruins",nameKey:"expedition_explore_ruins",durationHours:4,requiredElement:"fire",rewards:{crystals:150,essence:25,goldEquivalentMinutes:45}},{id:"abyssal_dive",nameKey:"expedition_abyssal_dive",durationHours:8,requiredRarity:"epic",rewards:{crystals:400,essence:70,goldEquivalentMinutes:120}}];function xt(r){return tt.find(e=>e.id===r)}class wt{static dispatch(e,t){const s=d.get();if(!s.heroes[t]||s.expeditions.some(c=>c.heroId===t))return!1;const i=xt(e);if(!i)return!1;const n=ve(t);if(!n||i.requiredElement&&n.element!==i.requiredElement)return!1;const o={common:1,rare:2,epic:3,legendary:4,mythic:5};if(i.requiredRarity&&o[n.rarity]<o[i.requiredRarity])return!1;const l={id:Math.random().toString(36).substr(2,9),templateId:e,heroId:t,startedAt:Date.now(),durationMs:i.durationHours*3600*1e3};return d.set(c=>{c.expeditions.push(l)}),f.emit("toast:show",{message:"Hero dispatched on expedition!",type:"info"}),!0}static claim(e){const t=d.get(),s=t.expeditions.find(h=>h.id===e);if(!s)return!1;const a=Date.now();if(a<s.startedAt+s.durationMs)return!1;const i=xt(s.templateId);if(!i)return!1;const n=t.heroes[s.heroId],o=n?1+(n.stars-1)*.1:1,l=Math.floor(i.rewards.crystals*o),c=Math.floor(i.rewards.essence*o),m=I.calculateMetrics(t,a),g=Math.floor(i.rewards.goldEquivalentMinutes*60*m.passiveGoldPerSec*o);return d.set(h=>{h.crystals+=l,h.essence+=c,h.gold+=g,h.stats.lifetimeGold+=g,h.expeditions=h.expeditions.filter(y=>y.id!==e)}),f.emit("toast:show",{message:`Expedition Complete! +${l} Crystals, +${c} Essence, +${g} Gold`,type:"success"}),!0}}class Ns{constructor(){p(this,"el");p(this,"unsubscribe");p(this,"timer");p(this,"lastKey","");this.el=document.createElement("div"),this.el.className="screen-container",this.el.style.padding="16px",this.unsubscribe=d.subscribe(()=>this.update()),this.timer=window.setInterval(()=>{this.updateTimers()},1e3)}getElement(){return this.render(),this.el}destroy(){this.unsubscribe(),clearInterval(this.timer)}update(){const e=d.get(),t=JSON.stringify(e.expeditions);t!==this.lastKey&&(this.lastKey=t,this.render())}render(){const e=d.get();this.el.innerHTML=`
      <h1 style="margin-bottom: 24px; color: var(--color-cyan); text-align: center;">🗺️ ${u("nav.expeditions")}</h1>
      
      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg); margin-bottom: 24px;">
        <h2 style="margin-bottom: 16px; font-size: 16px;">Active Expeditions</h2>
        ${e.expeditions.length===0?'<div class="empty-state">No heroes are currently on an expedition.</div>':`<div style="display: flex; flex-direction: column; gap: 12px;">
             ${e.expeditions.map(t=>this.renderActive(t)).join("")}
           </div>`}
      </div>

      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg);">
        <h2 style="margin-bottom: 16px; font-size: 16px;">Available Missions</h2>
        <div style="display: flex; flex-direction: column; gap: 16px;">
          ${tt.map(t=>this.renderTemplate(t)).join("")}
        </div>
      </div>
    `,this.el.querySelectorAll(".claim-btn").forEach(t=>{t.addEventListener("click",s=>{const a=s.currentTarget.dataset.id;wt.claim(a),_.playClaim()})}),this.el.querySelectorAll(".dispatch-select").forEach(t=>{t.addEventListener("change",s=>{const a=s.currentTarget,i=a.dataset.template,n=a.value;n&&(wt.dispatch(i,n),a.value="")})})}updateTimers(){const e=Date.now();this.el.querySelectorAll(".exp-timer").forEach(t=>{const s=parseInt(t.dataset.start),a=parseInt(t.dataset.duration),i=s+a;if(e>=i)t.textContent="Complete!",t.parentElement.querySelector(".claim-btn")?.removeAttribute("disabled");else{const n=Math.ceil((i-e)/1e3),o=Math.floor(n/3600),l=Math.floor(n%3600/60),c=n%60;t.textContent=`${o}h ${l}m ${c}s`}})}renderActive(e){const t=tt.find(i=>i.id===e.templateId),s=ve(e.heroId);if(!t||!s)return"";const a=Date.now()>=e.startedAt+e.durationMs;return`
      <div style="background: var(--bg-surface-raised); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 12px; display: flex; justify-content: space-between; align-items: center;">
        <div style="display: flex; align-items: center; gap: 12px;">
          <div style="font-size: 24px;">${u(t.nameKey)}</div>
          <div>
            <div style="font-size: 14px; font-weight: bold;">${u(s.nameKey)}</div>
            <div class="exp-timer" data-start="${e.startedAt}" data-duration="${e.durationMs}" style="font-size: 12px; color: var(--text-cyan);">
              ${a?"Complete!":"Calculating..."}
            </div>
          </div>
        </div>
        <button class="claim-btn" data-id="${e.id}" ${a?"":"disabled"} style="background: var(--color-cyan); color: #000; padding: 8px 16px; border-radius: var(--radius-full); font-weight: bold; cursor: ${a?"pointer":"not-allowed"}; opacity: ${a?1:.5};">
          Claim
        </button>
      </div>
    `}renderTemplate(e){const t=d.get();let s='<option value="">Select Hero to Dispatch...</option>';return Object.keys(t.heroes).forEach(a=>{const i=ve(a);if(!i||t.expeditions.some(o=>o.heroId===a)||e.requiredElement&&i.element!==e.requiredElement)return;const n={common:1,rare:2,epic:3,legendary:4,mythic:5};e.requiredRarity&&(n[i.rarity]||0)<(n[e.requiredRarity]||0)||(s+=`<option value="${a}">${u(i.nameKey)} (${i.rarity})</option>`)}),`
      <div style="background: var(--bg-surface-raised); border: 1px solid var(--border-highlight); border-radius: var(--radius-md); padding: 16px;">
        <div style="display: flex; justify-content: space-between; margin-bottom: 12px;">
          <h3 style="font-size: 16px;">${u(e.nameKey)}</h3>
          <span style="color: var(--text-muted); font-size: 12px;">⏱️ ${e.durationHours} Hours</span>
        </div>
        
        <div style="display: flex; gap: 8px; font-size: 12px; color: var(--text-gold); margin-bottom: 12px;">
          <span>Rewards:</span>
          <span>💎 ${e.rewards.crystals}</span>
          <span>🧪 ${e.rewards.essence}</span>
          <span>💰 ~${e.rewards.goldEquivalentMinutes}m gold</span>
        </div>

        <div style="font-size: 11px; color: var(--text-dim); margin-bottom: 12px;">
          Requires: ${e.requiredElement?e.requiredElement.toUpperCase():"Any Element"} | ${e.requiredRarity?e.requiredRarity.toUpperCase():"Any Rarity"}
        </div>

        <select class="dispatch-select" data-template="${e.id}" style="width: 100%; padding: 8px; background: var(--bg-core); color: var(--text-main); border: 1px solid var(--border-subtle); border-radius: var(--radius-sm);">
          ${s}
        </select>
      </div>
    `}}class Gs{constructor(){p(this,"el");p(this,"unsubscribe");p(this,"lastKey","");this.el=document.createElement("div"),this.el.className="screen-container",this.el.style.padding="16px",this.unsubscribe=d.subscribe(()=>this.update())}getElement(){return this.render(),this.el}destroy(){this.unsubscribe()}update(){const e=d.get(),t=`${e.loginStreak}_${e.loginRewardClaimed}_${JSON.stringify(e.dailyQuests)}`;t!==this.lastKey&&(this.lastKey=t,this.render())}render(){const e=d.get(),t=(e.loginStreak-1)%30+1;let s="";for(let n=1;n<=30;n++){const o=n<t,l=n===t;let c=50+n%30*10;n===7&&(c+=500),n===14&&(c+=1500),n===30&&(c+=5e3);const m=n===7||n===14||n===30;let g="var(--border-subtle)";l&&(g="var(--color-cyan)"),m&&(g="var(--color-gold)"),s+=`
        <div style="
          background: ${o?"rgba(0,0,0,0.5)":"var(--bg-surface-raised)"}; 
          border: 1px solid ${g}; 
          border-radius: var(--radius-sm); 
          padding: 8px 4px; 
          text-align: center;
          position: relative;
          opacity: ${o?.4:1};
        ">
          <div style="font-size: 10px; color: var(--text-muted); margin-bottom: 4px;">Day ${n}</div>
          <div style="font-size: 12px; font-weight: bold; color: ${m?"var(--color-gold)":"var(--text-main)"};">
            💎 ${c}
          </div>
          ${o?'<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); font-size: 24px; color: var(--color-emerald);">✓</div>':""}
        </div>
      `}const a=e.dailyQuests.map(n=>{const o=Pe(n.templateId);if(!o)return"";const l=n.progress>=o.target,c=Math.min(100,Math.floor(n.progress/o.target*100));return`
        <div style="background: var(--bg-surface-raised); border: 1px solid ${n.claimed?"var(--border-subtle)":l?"var(--color-emerald)":"var(--border-subtle)"}; border-radius: var(--radius-md); padding: 12px; margin-bottom: 8px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
            <div>
              <div style="font-size: 14px; font-weight: bold; color: ${n.claimed?"var(--text-muted)":"var(--text-main)"};">${u(o.descriptionKey)}</div>
              <div style="font-size: 12px; color: var(--text-gold);">💎 ${o.rewardCrystals}</div>
            </div>
            <button class="claim-quest-btn" data-id="${n.id}" ${!l||n.claimed?"disabled":""} style="background: ${n.claimed?"transparent":"var(--color-emerald)"}; color: ${n.claimed?"var(--text-muted)":"#000"}; padding: 6px 12px; border-radius: var(--radius-full); font-weight: bold;">
              ${n.claimed?"Claimed":"Claim"}
            </button>
          </div>
          
          <!-- Progress bar -->
          <div style="height: 6px; background: var(--bg-core); border-radius: 3px; overflow: hidden; position: relative;">
            <div style="position: absolute; top: 0; left: 0; height: 100%; width: ${c}%; background: ${l?"var(--color-emerald)":"var(--color-cyan)"};"></div>
          </div>
          <div style="text-align: right; font-size: 10px; color: var(--text-muted); margin-top: 4px;">
            ${n.progress} / ${o.target}
          </div>
        </div>
      `}).join("");this.el.innerHTML=`
      <h1 style="margin-bottom: 24px; color: var(--text-cyan); text-align: center;">📅 ${u("nav.dailies")}</h1>
      
      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg); margin-bottom: 24px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
          <h2 style="font-size: 16px;">Login Calendar (Day ${t})</h2>
          <button id="claimLoginBtn" ${e.loginRewardClaimed?"disabled":""} style="background: ${e.loginRewardClaimed?"var(--bg-core)":"var(--color-cyan)"}; color: ${e.loginRewardClaimed?"var(--text-muted)":"#000"}; padding: 6px 16px; border-radius: var(--radius-full); font-weight: bold;">
            ${e.loginRewardClaimed?"Claimed Today":"Claim Reward"}
          </button>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(5, 1fr); gap: 6px; max-height: 200px; overflow-y: auto; padding-right: 4px;">
          ${s}
        </div>
      </div>

      <div style="background: var(--bg-card); padding: 16px; border-radius: var(--radius-lg);">
        <h2 style="margin-bottom: 16px; font-size: 16px;">Daily Quests</h2>
        ${a}
      </div>
    `;const i=this.el.querySelector("#claimLoginBtn");i&&i.addEventListener("click",()=>{De.claimLoginReward()&&_.playClaim()}),this.el.querySelectorAll(".claim-quest-btn").forEach(n=>{n.addEventListener("click",o=>{const l=o.currentTarget.dataset.id;De.claimQuest(l)&&_.playClaim()})})}}class Fs{constructor(){p(this,"screens",new Map);p(this,"screenViewport",null);p(this,"particleCanvas",null);p(this,"devOverlay",null)}async bootstrap(){console.log("[Anime Infinite Ascension] Bootstrapping..."),typeof window<"u"&&(window.events=f,window.store=d),await V.init();const e=V.getLanguage();st.setLanguage(e);const t=Et.loadLocal(),s=await V.loadCloudSave(),a=s&&s.lastSeenAt>(t?.lastSeenAt||0)?s:t;a&&d.replace(a),H.spawnCurrentEncounter(),U.resetToFloor(d.get().towerFloor);const i=document.getElementById("app");i.innerHTML="";const n=document.createElement("canvas");n.className="background-canvas",i.appendChild(n),this.particleCanvas=new _s(n);const o=document.createElement("div");o.id="floatingNumbersLayer",o.style.cssText="position:absolute; top:0; left:0; width:100%; height:100%; overflow:hidden; pointer-events:none; z-index:90;",i.appendChild(o),E.init(o);const l=document.createElement("div");l.id="modalLayer",l.style.cssText="position:absolute; top:0; left:0; width:100%; height:100%; z-index:200; display:none; align-items:center; justify-content:center;",i.appendChild(l),C.init(l),C.register(Ss),C.register(Es),C.register(Ms),C.register(As),C.register(Ts),C.register(Is),C.register(qs);const c=document.createElement("div");c.id="toastLayer",c.style.cssText="position:fixed; top:70px; right:16px; z-index:300; display:flex; flex-direction:column; align-items:flex-end; pointer-events:none;",i.appendChild(c),Lt.init(c);const m=new ys;i.appendChild(m.getElement()),this.screenViewport=document.createElement("main"),this.screenViewport.className="app-viewport",i.appendChild(this.screenViewport);const g=new vs;i.appendChild(g.getElement()),this.devOverlay=new ws,i.appendChild(this.devOverlay.getElement());const h=new Rs(this.particleCanvas),y=new $s,v=new Bs,w=new Ps,S=new Ds,$=new Ls,M=new zs,A=new Hs,q=new Ns,j=new Gs;this.screens.set("home",h.getElement()),this.screens.set("battle",h.getElement()),this.screens.set("ascension",y.getElement()),this.screens.set("tower",v.getElement()),this.screens.set("heroes",w.getElement()),this.screens.set("summon",S.getElement()),this.screens.set("souls",$.getElement()),this.screens.set("quests",M.getElement()),this.screens.set("relics",A.getElement()),this.screens.set("expeditions",q.getElement()),this.screens.set("dailies",j.getElement()),f.on("screen:change",({screenId:T})=>{this.switchScreen(T)}),this.switchScreen("home");const P=It.calculateOfflineGains(d.get());P&&setTimeout(()=>{f.emit("modal:open",{modalId:"offline_reward",data:{gains:P}})},500),De.checkDailyReset();let L=0,X=0,ce=0;je.addCallback((T,_e)=>{const ke=d.get(),Z=I.calculateMetrics(ke,_e),W=Z.passivePowerPerSec*T,ue=Z.passiveGoldPerSec*T;(W>0||ue>0)&&d.set(N=>{N.power+=W,N.gold+=ue,N.stats.lifetimePower+=W,N.stats.lifetimeGold+=ue,N.stats.playtimeSeconds+=T});const me=de.getEquippedEffectValue(ke,"auto_training");if(me>0){const N=Z.clickPower*me*T,Se=Z.clickGold*me*T;d.set(F=>{F.power+=N,F.gold+=Se,F.stats.lifetimePower+=N,F.stats.lifetimeGold+=Se})}$t.updateCombo(T),X+=T,X>=1&&(X=0,Te.update(_e)),ce+=T,ce>=60&&(ce=0,De.checkDailyReset()),H.update(T),U.update(T),this.particleCanvas&&this.particleCanvas.update(),this.devOverlay&&this.devOverlay.updateFps(),L+=T,L>=1&&(L=0,Ne.checkAchievements())}),je.start(),V.notifyGameReady(),V.notifyGameplayStart(),console.log("[Anime Infinite Ascension] Game initialized & ready."),f.emit("game_start",{saveVersion:a?.version||1});const B=()=>{d.get().settings.musicEnabled&&_.startAmbientBgm(),document.body.removeEventListener("pointerdown",B),document.body.removeEventListener("keydown",B)};document.body.addEventListener("pointerdown",B),document.body.addEventListener("keydown",B)}switchScreen(e){if(!this.screenViewport)return;const t=this.screens.get(e);t&&(this.screenViewport.innerHTML="",this.screenViewport.appendChild(t))}}const Os=new Fs;window.addEventListener("DOMContentLoaded",()=>{Os.bootstrap().catch(r=>console.error("[Fatal Bootstrap Error]:",r))});
